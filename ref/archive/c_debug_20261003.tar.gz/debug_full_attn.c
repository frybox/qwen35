// Debug full attention layer implementation
// Compare with PyTorch reference values
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

// Apply RoPE to Q and K
void apply_rope_test(float *q, float *k, int head_dim, int nheads, int nkvheads, int pos) {
    for (int h = 0; h < nheads; h++) {
        for (int i = 0; i < head_dim; i += 2) {
            float freq = 1.0f / powf(10000.0f, (float)i / head_dim);
            float val = pos * freq;
            float cos_val = cosf(val);
            float sin_val = sinf(val);
            
            float q0 = q[h * head_dim + i];
            float q1 = q[h * head_dim + i + 1];
            q[h * head_dim + i] = q0 * cos_val - q1 * sin_val;
            q[h * head_dim + i + 1] = q0 * sin_val + q1 * cos_val;
        }
    }
    
    for (int h = 0; h < nkvheads; h++) {
        for (int i = 0; i < head_dim; i += 2) {
            float freq = 1.0f / powf(10000.0f, (float)i / head_dim);
            float val = pos * freq;
            float cos_val = cosf(val);
            float sin_val = sinf(val);
            
            float k0 = k[h * head_dim + i];
            float k1 = k[h * head_dim + i + 1];
            k[h * head_dim + i] = k0 * cos_val - k1 * sin_val;
            k[h * head_dim + i + 1] = k0 * sin_val + k1 * cos_val;
        }
    }
}

void softmax(float *x, int n) {
    float max_val = x[0];
    for (int i = 1; i < n; i++) if (x[i] > max_val) max_val = x[i];
    float sum = 0;
    for (int i = 0; i < n; i++) { x[i] = expf(x[i] - max_val); sum += x[i]; }
    for (int i = 0; i < n; i++) x[i] /= sum;
}

int main() {
    printf("=== Full Attention Layer Debug ===\n\n");
    
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) { printf("Failed to open model\n"); return 1; }
    
    // Load layer 3 weights (first full attention layer)
    int layer = 3;
    
    char name[256];
    sprintf(name, "model.language_model.layers.%d.input_layernorm.weight", layer);
    float *ln1 = load_tensor(sf, name, 1024);
    
    sprintf(name, "model.language_model.layers.%d.self_attn.q_proj.weight", layer);
    float *fa_q = load_tensor(sf, name, 4096 * 1024);
    
    sprintf(name, "model.language_model.layers.%d.self_attn.k_proj.weight", layer);
    float *fa_k = load_tensor(sf, name, 512 * 1024);
    
    sprintf(name, "model.language_model.layers.%d.self_attn.v_proj.weight", layer);
    float *fa_v = load_tensor(sf, name, 512 * 1024);
    
    sprintf(name, "model.language_model.layers.%d.self_attn.q_norm.weight", layer);
    float *fa_qn = load_tensor(sf, name, 256);
    
    sprintf(name, "model.language_model.layers.%d.self_attn.k_norm.weight", layer);
    float *fa_kn = load_tensor(sf, name, 256);
    
    sprintf(name, "model.language_model.layers.%d.self_attn.o_proj.weight", layer);
    float *fa_o = load_tensor(sf, name, 1024 * 2048);
    
    // Load embedding for token
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    
    printf("Weights loaded for layer %d (full attention)\n\n", layer);
    
    // Test with a simple input
    int test_token = 248045;  // <|im_start|>
    float x[1024];
    memcpy(x, embed + test_token * 1024, sizeof(x));
    
    printf("Input token: %d\n", test_token);
    printf("x [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
    
    // Apply norm
    float x_norm[1024];
    rmsnorm(x_norm, x, ln1, 1024);
    printf("\nAfter ln1 norm:\n");
    printf("x_norm [0:4]: %.4f, %.4f, %.4f, %.4f\n", x_norm[0], x_norm[1], x_norm[2], x_norm[3]);
    
    // Check norm of x_norm
    float norm = 0;
    for (int i = 0; i < 1024; i++) norm += x_norm[i] * x_norm[i];
    printf("x_norm L2: %.4f\n", sqrtf(norm));
    
    // Q projection with gate
    float q_gate[4096];
    matmul(q_gate, fa_q, x_norm, 1024, 4096);
    printf("\nQ+Gate projection:\n");
    printf("q_gate [0:4]: %.4f, %.4f, %.4f, %.4f\n", q_gate[0], q_gate[1], q_gate[2], q_gate[3]);
    printf("gate [0:4]: %.4f, %.4f, %.4f, %.4f\n", q_gate[2048], q_gate[2049], q_gate[2050], q_gate[2051]);
    
    // Split Q and gate
    float q[2048];
    float gate[2048];
    memcpy(q, q_gate, 2048 * sizeof(float));
    memcpy(gate, q_gate + 2048, 2048 * sizeof(float));
    
    // Q norm (per head)
    printf("\nQ norm per head:\n");
    for (int h = 0; h < 8; h++) {
        float q_norm = 0;
        for (int i = 0; i < 256; i++) q_norm += q[h*256 + i] * q[h*256 + i];
        printf("  Head %d, before norm: L2=%.4f\n", h, sqrtf(q_norm));
        
        // Apply norm
        rmsnorm(q + h*256, q + h*256, fa_qn, 256);
        
        q_norm = 0;
        for (int i = 0; i < 256; i++) q_norm += q[h*256 + i] * q[h*256 + i];
        printf("  Head %d, after norm: L2=%.4f\n", h, sqrtf(q_norm));
    }
    
    // K projection
    float k[512];
    matmul(k, fa_k, x_norm, 1024, 512);
    
    printf("\nK projection:\n");
    printf("k [0:4]: %.4f, %.4f, %.4f, %.4f\n", k[0], k[1], k[2], k[3]);
    
    // K norm
    for (int h = 0; h < 2; h++) {
        rmsnorm(k + h*256, k + h*256, fa_kn, 256);
    }
    
    // V projection
    float v[512];
    matmul(v, fa_v, x_norm, 1024, 512);
    printf("\nV projection:\n");
    printf("v [0:4]: %.4f, %.4f, %.4f, %.4f\n", v[0], v[1], v[2], v[3]);
    
    // Apply RoPE at position 0
    printf("\nApplying RoPE at position 0:\n");
    apply_rope_test(q, k, 256, 8, 2, 0);
    printf("After RoPE, q [0:4]: %.4f, %.4f, %.4f, %.4f\n", q[0], q[1], q[2], q[3]);
    printf("After RoPE, k [0:4]: %.4f, %.4f, %.4f, %.4f\n", k[0], k[1], k[2], k[3]);
    
    // Compute attention scores for single position (pos=0)
    printf("\nAttention scores at pos=0:\n");
    for (int h = 0; h < 8; h++) {
        float *qh = q + h * 256;
        int kvh = h / 4;  // GQA: 8 heads -> 2 KV heads
        float *kh = k + kvh * 256;
        
        float score = 0;
        for (int i = 0; i < 256; i++) score += qh[i] * kh[i];
        score /= sqrtf(256.0f);
        printf("  Head %d (kvh=%d): score=%.4f\n", h, kvh, score);
    }
    
    // Test with multiple positions
    printf("\n=== Testing with 3 positions ===\n");
    
    // Process 3 tokens
    int tokens[] = {248045, 846, 198};
    float k_cache[3 * 512];
    float v_cache[3 * 512];
    
    for (int pos = 0; pos < 3; pos++) {
        int tok = tokens[pos];
        memcpy(x, embed + tok * 1024, sizeof(x));
        rmsnorm(x_norm, x, ln1, 1024);
        
        // Re-project Q, K, V
        matmul(q_gate, fa_q, x_norm, 1024, 4096);
        memcpy(q, q_gate, 2048 * sizeof(float));
        memcpy(gate, q_gate + 2048, 2048 * sizeof(float));
        
        // Q norm
        for (int h = 0; h < 8; h++) {
            rmsnorm(q + h*256, q + h*256, fa_qn, 256);
        }
        
        // K projection and norm
        matmul(k, fa_k, x_norm, 1024, 512);
        for (int h = 0; h < 2; h++) {
            rmsnorm(k + h*256, k + h*256, fa_kn, 256);
        }
        
        // V projection
        matmul(v, fa_v, x_norm, 1024, 512);
        
        // Apply RoPE
        apply_rope_test(q, k, 256, 8, 2, pos);
        
        // Cache K, V
        memcpy(k_cache + pos * 512, k, 512 * sizeof(float));
        memcpy(v_cache + pos * 512, v, 512 * sizeof(float));
        
        printf("\nPosition %d (token %d):\n", pos, tok);
        printf("  q [0:4]: %.4f, %.4f, %.4f, %.4f\n", q[0], q[1], q[2], q[3]);
        printf("  k [0:4]: %.4f, %.4f, %.4f, %.4f\n", k[0], k[1], k[2], k[3]);
        printf("  gate [0:4]: %.4f, %.4f, %.4f, %.4f\n", gate[0], gate[1], gate[2], gate[3]);
    }
    
    // Compute full attention at pos=2
    printf("\n=== Full attention computation at pos=2 ===\n");
    int pos = 2;
    float attn_out[2048] = {0};
    
    for (int h = 0; h < 8; h++) {
        float *qh = q + h * 256;
        int kvh = h / 4;
        float att[3];
        
        printf("\nHead %d:\n", h);
        
        // Compute attention scores
        for (int t = 0; t <= pos; t++) {
            float *kt = k_cache + t * 512 + kvh * 256;
            float score = 0;
            for (int i = 0; i < 256; i++) score += qh[i] * kt[i];
            att[t] = score / sqrtf(256.0f);
            printf("  att[%d] = %.4f\n", t, att[t]);
        }
        
        // Softmax
        softmax(att, pos + 1);
        printf("  After softmax: %.4f, %.4f, %.4f\n", att[0], att[1], att[2]);
        
        // Weighted sum of V
        float *out = attn_out + h * 256;
        for (int t = 0; t <= pos; t++) {
            float *vt = v_cache + t * 512 + kvh * 256;
            for (int i = 0; i < 256; i++) {
                out[i] += att[t] * vt[i];
            }
        }
        
        printf("  out [0:4]: %.4f, %.4f, %.4f, %.4f\n", out[0], out[1], out[2], out[3]);
    }
    
    // Apply gate
    printf("\n=== Applying gate ===\n");
    for (int i = 0; i < 2048; i++) {
        float g = 1.0f / (1.0f + expf(-gate[i]));
        attn_out[i] *= g;
    }
    printf("After gate, attn_out [0:4]: %.4f, %.4f, %.4f, %.4f\n", 
           attn_out[0], attn_out[1], attn_out[2], attn_out[3]);
    
    // Output projection
    float final_out[1024];
    matmul(final_out, fa_o, attn_out, 2048, 1024);
    printf("\nAfter o_proj, final_out [0:4]: %.4f, %.4f, %.4f, %.4f\n",
           final_out[0], final_out[1], final_out[2], final_out[3]);
    
    // Check final output norm
    norm = 0;
    for (int i = 0; i < 1024; i++) norm += final_out[i] * final_out[i];
    printf("final_out L2: %.4f\n", sqrtf(norm));
    
    safetensors_close(sf);
    return 0;
}