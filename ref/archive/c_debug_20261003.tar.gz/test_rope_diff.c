// Test RoPE theta difference
#include <stdio.h>
#include <math.h>

void apply_rope_wrong(float *q, int head_dim, int pos) {
    float theta = 10000000.0f;  // WRONG (qwen35_engine.c)
    int rotary_dim = head_dim / 4;
    for (int i = 0; i < rotary_dim; i += 2) {
        float freq = 1.0f / powf(theta, (float)(2*i) / rotary_dim);
        float val = pos * freq;
        float cr = cosf(val), ci = sinf(val);
        float v0 = q[i], v1 = q[i + 1];
        q[i] = v0*cr - v1*ci;
        q[i + 1] = v0*ci + v1*cr;
    }
}

void apply_rope_correct(float *q, int head_dim, int pos) {
    float theta = 1000000.0f;  // CORRECT (debug_generation.c)
    int rotary_dim = head_dim / 4;
    for (int i = 0; i < rotary_dim; i += 2) {
        float freq = 1.0f / powf(theta, (float)(2*i) / rotary_dim);
        float val = pos * freq;
        float cr = cosf(val), ci = sinf(val);
        float v0 = q[i], v1 = q[i + 1];
        q[i] = v0*cr - v1*ci;
        q[i + 1] = v0*ci + v1*cr;
    }
}

int main() {
    float q1[256], q2[256];
    for (int i = 0; i < 256; i++) {
        q1[i] = q2[i] = 0.1f * i;
    }
    
    printf("Testing RoPE theta difference:\n");
    printf("  qwen35_engine.c: theta = 10000000.0f\n");
    printf("  debug_generation.c: theta = 1000000.0f\n\n");
    
    for (int pos = 0; pos <= 20; pos++) {
        // Reset
        for (int i = 0; i < 256; i++) {
            q1[i] = q2[i] = 0.1f * i;
        }
        
        apply_rope_wrong(q1, 256, pos);
        apply_rope_correct(q2, 256, pos);
        
        // Compare first few values
        float diff0 = fabsf(q1[0] - q2[0]);
        float diff1 = fabsf(q1[1] - q2[1]);
        float max_diff = 0;
        for (int i = 0; i < 64; i++) {
            float d = fabsf(q1[i] - q2[i]);
            if (d > max_diff) max_diff = d;
        }
        
        printf("pos=%2d: q1[0]=%.6f q2[0]=%.6f diff=%.6f | max_diff=%.6f\n", 
               pos, q1[0], q2[0], diff0, max_diff);
    }
    
    return 0;
}