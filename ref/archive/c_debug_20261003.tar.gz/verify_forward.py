#!/usr/bin/env python3
"""
Verify forward pass step-by-step comparing Python vs C engine.
Focus on token 248045 (<|im_start|>)
"""
import numpy as np
import json
import struct

def load_tensor(path, name):
    """Load a tensor from safetensors file"""
    with open(path, 'rb') as f:
        header_size = struct.unpack('<Q', f.read(8))[0]
        header = f.read(header_size).decode('utf-8')
        meta = json.loads(header)
        
        if name not in meta:
            return None
        info = meta[name]
        start, end = info['data_offsets']
        f.seek(8 + header_size + start)
        data = f.read(end - start)
        
        if info['dtype'] == 'BF16':
            bf16 = np.frombuffer(data, dtype=np.uint16)
            fp32 = (bf16.astype(np.uint32) << 16).view(np.float32)
            return fp32.reshape(info['shape'])
        elif info['dtype'] == 'F32':
            return np.frombuffer(data, dtype=np.float32).reshape(info['shape'])
        else:
            return None

def rmsnorm(x, w, eps=1e-6):
    """RMSNorm: x * (1/sqrt(mean(x^2) + eps)) * w"""
    variance = np.mean(x ** 2)
    x_normed = x * np.reciprocal(np.sqrt(variance + eps))
    return w * x_normed

def silu(x):
    """SiLU activation: x * sigmoid(x)"""
    return x * (1.0 / (1.0 + np.exp(-x)))

# Load weights
path = '/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors'

print("=== Loading weights ===")
embed = load_tensor(path, 'model.language_model.embed_tokens.weight')
print(f"embed_tokens shape: {embed.shape}")

ln0 = load_tensor(path, 'model.language_model.layers.0.input_layernorm.weight')
print(f"layer0 input_layernorm shape: {ln0.shape}")

gdn_qkv = load_tensor(path, 'model.language_model.layers.0.linear_attn.in_proj_qkv.weight')
print(f"layer0 gdn_qkv shape: {gdn_qkv.shape}")

gdn_z = load_tensor(path, 'model.language_model.layers.0.linear_attn.in_proj_z.weight')
print(f"layer0 gdn_z shape: {gdn_z.shape}")

gdn_a = load_tensor(path, 'model.language_model.layers.0.linear_attn.in_proj_a.weight')
print(f"layer0 gdn_a shape: {gdn_a.shape}")

gdn_b = load_tensor(path, 'model.language_model.layers.0.linear_attn.in_proj_b.weight')
print(f"layer0 gdn_b shape: {gdn_b.shape}")

gdn_A_log = load_tensor(path, 'model.language_model.layers.0.linear_attn.A_log')
print(f"layer0 A_log shape: {gdn_A_log.shape}")

gdn_dt = load_tensor(path, 'model.language_model.layers.0.linear_attn.dt_bias')
print(f"layer0 dt_bias shape: {gdn_dt.shape}")

gdn_conv = load_tensor(path, 'model.language_model.layers.0.linear_attn.conv1d.weight')
print(f"layer0 conv1d shape: {gdn_conv.shape}")

gdn_norm = load_tensor(path, 'model.language_model.layers.0.linear_attn.norm.weight')
print(f"layer0 gdn_norm shape: {gdn_norm.shape}")

gdn_out = load_tensor(path, 'model.language_model.layers.0.linear_attn.out_proj.weight')
print(f"layer0 gdn_out shape: {gdn_out.shape}")

ln2 = load_tensor(path, 'model.language_model.layers.0.post_attention_layernorm.weight')
print(f"layer0 post_attention_layernorm shape: {ln2.shape}")

# Step 1: Embedding lookup
print("\n=== Step 1: Embedding Lookup ===")
token_id = 248045
x = embed[token_id].copy()
print(f"Token {token_id} embedding:")
print(f"  Shape: {x.shape}")
print(f"  Norm: {np.linalg.norm(x):.6f}")
print(f"  First 8: {x[:8]}")
print(f"  Last 8: {x[-8:]}")
print(f"  Mean: {np.mean(x):.6f}, Std: {np.std(x):.6f}")

# Step 2: Layer 0 input layernorm
print("\n=== Step 2: Layer 0 Input LayerNorm ===")
x1 = rmsnorm(x, ln0)
print(f"After layernorm:")
print(f"  Shape: {x1.shape}")
print(f"  Norm: {np.linalg.norm(x1):.6f}")
print(f"  First 8: {x1[:8]}")
print(f"  Last 8: {x1[-8:]}")
print(f"  Mean: {np.mean(x1):.6f}, Std: {np.std(x1):.6f}")

# Verify layernorm is correct
print("\n  Verify layernorm formula:")
variance = np.mean(x ** 2)
rms = np.sqrt(variance + 1e-6)
print(f"    Variance: {variance:.6f}")
print(f"    RMS: {rms:.6f}")
print(f"    1/RMS: {1/rms:.6f}")

# Step 3: QKV projection
print("\n=== Step 3: GDN QKV Projection ===")
# Weight shape: [6144, 1024], x shape: [1024]
# Output: qkv = W @ x, shape [6144]
# Layout: first 2048 are Q, next 2048 are K, last 2048 are V
# Each of Q/K/V has 16 heads, each head has 128 dims
qkv = gdn_qkv @ x1
print(f"QKV projection:")
print(f"  Shape: {qkv.shape}")
print(f"  Norm: {np.linalg.norm(qkv):.6f}")
print(f"  Mean: {np.mean(qkv):.6f}, Std: {np.std(qkv):.6f}")

# Split into Q, K, V
q = qkv[:2048]
k = qkv[2048:4096]
v = qkv[4096:]
print(f"\nQ section (first 2048):")
print(f"  Norm: {np.linalg.norm(q):.6f}")
print(f"  First 8: {q[:8]}")
print(f"  Mean: {np.mean(q):.6f}, Std: {np.std(q):.6f}")

print(f"\nK section (2048-4096):")
print(f"  Norm: {np.linalg.norm(k):.6f}")
print(f"  First 8: {k[:8]}")
print(f"  Mean: {np.mean(k):.6f}, Std: {np.std(k):.6f}")

print(f"\nV section (4096-6144):")
print(f"  Norm: {np.linalg.norm(v):.6f}")
print(f"  First 8: {v[:8]}")
print(f"  Mean: {np.mean(v):.6f}, Std: {np.std(v):.6f}")

# Step 4: Conv1D (for position 0, this just initializes)
print("\n=== Step 4: Conv1D (position=0) ===")
# Conv1d weight shape: [6144, 4]
# For position 0, conv_state is all zeros initially
# Conv is: out = sum(conv_w * conv_state), but state is zero at pos 0
# After conv: qkv[ch] = sum(conv_w[ch,:] * conv_state[ch,:])
# Since conv_state is initialized to zeros, the output after conv would be 0
# But wait - in C code, at pos=0, it shifts zeros in and then uses qkv directly
# Let me check the C code more carefully...

# From C code (lines 320-328):
# cs[3] = qkv[ch];  // store current value
# sum = cs[0]*cw[0] + cs[1]*cw[1] + cs[2]*cw[2] + cs[3]*cw[3]
# Since cs was all zeros, sum = qkv[ch] * cw[3]
# So we need to multiply by conv_w[:, 3]

# Actually let's compute it
conv_state = np.zeros((6144, 4), dtype=np.float32)
for ch in range(6144):
    conv_state[ch, 0] = conv_state[ch, 1]
    conv_state[ch, 1] = conv_state[ch, 2]
    conv_state[ch, 2] = conv_state[ch, 3]
    conv_state[ch, 3] = qkv[ch]

# Now apply conv
qkv_conv = np.zeros(6144, dtype=np.float32)
for ch in range(6144):
    qkv_conv[ch] = np.sum(conv_state[ch] * gdn_conv[ch])

print(f"After Conv1D (position=0, initial state zeros):")
print(f"  Shape: {qkv_conv.shape}")
print(f"  Norm: {np.linalg.norm(qkv_conv):.6f}")
print(f"  First 8: {qkv_conv[:8]}")
print(f"  Mean: {np.mean(qkv_conv):.6f}, Std: {np.std(qkv_conv):.6f}")

# Check conv weight layout
print(f"\nConv1D weight layout check:")
print(f"  Conv weight shape: {gdn_conv.shape}")
print(f"  Conv weight[0] (first channel): {gdn_conv[0]}")
print(f"  Conv weight[1] (second channel): {gdn_conv[1]}")

# Step 5: Z projection
print("\n=== Step 5: Z Projection ===")
z = gdn_z @ x1
print(f"Z projection:")
print(f"  Shape: {z.shape}")  # Should be [2048] = 16 heads * 128 vdim
print(f"  Norm: {np.linalg.norm(z):.6f}")
print(f"  First 8: {z[:8]}")
print(f"  Mean: {np.mean(z):.6f}, Std: {np.std(z):.6f}")

# Step 6: A and B projections
print("\n=== Step 6: A and B Projections ===")
a = gdn_a @ x1  # shape [16]
b = gdn_b @ x1  # shape [16]
print(f"A projection: shape {a.shape}, values: {a}")
print(f"B projection: shape {b.shape}, values: {b}")

# Apply sigmoid to b
b_sigmoid = 1.0 / (1.0 + np.exp(-b))
print(f"B after sigmoid: {b_sigmoid}")

# Step 7: GDN state update (for position 0)
print("\n=== Step 7: GDN State Update (position=0) ===")
nv = 16  # gdn_vheads
kd = 128  # gdn_kdim
vd = 128  # gdn_vdim

# Initial state is zeros
state = np.zeros((nv, kd, vd), dtype=np.float32)

# Process each head
for h in range(nv):
    q_h = qkv_conv[h*kd:(h+1)*kd]
    k_h = qkv_conv[nv*kd + h*kd:nv*kd + (h+1)*kd]
    v_h = qkv_conv[2*nv*kd + h*kd:2*nv*kd + (h+1)*kd]
    z_h = z[h*vd:(h+1)*vd]
    
    # Normalize Q and K
    q_norm = np.linalg.norm(q_h)
    k_norm = np.linalg.norm(k_h)
    q_h_normed = q_h / np.sqrt(q_norm**2 + 1e-6)
    k_h_normed = k_h / np.sqrt(k_norm**2 + 1e-6)
    
    # Scale Q
    q_h_scaled = q_h_normed / np.sqrt(kd)
    
    # Decay parameters
    A = gdn_A_log[h]
    dt = gdn_dt[h]
    alpha = a[h]
    beta = b_sigmoid[h]
    
    # Compute gamma
    sp = np.log(1.0 + np.exp(alpha + dt))
    g = -np.exp(A) * sp
    gamma = np.exp(g)
    
    if h == 0:
        print(f"\n  Head 0 details:")
        print(f"    Q norm before norm: {q_norm:.6f}")
        print(f"    K norm before norm: {k_norm:.6f}")
        print(f"    A_log: {A:.6f}, exp(A_log): {np.exp(A):.6f}")
        print(f"    dt: {dt:.6f}")
        print(f"    alpha: {alpha:.6f}")
        print(f"    alpha + dt: {alpha + dt:.6f}")
        print(f"    softplus: {sp:.6f}")
        print(f"    g: {g:.6f}")
        print(f"    gamma: {gamma:.6f}")
        print(f"    beta: {beta:.6f}")
        print(f"    First 4 Q values (after norm+scale): {q_h_scaled[:4]}")
        print(f"    First 4 K values (after norm): {k_h_normed[:4]}")
        print(f"    First 4 V values: {v_h[:4]}")
        print(f"    First 4 Z values: {z_h[:4]}")
    
    # State update
    # state *= gamma
    state[h] *= gamma
    
    # kv_mem = state @ k
    kv_mem = np.sum(state[h] * k_h_normed[:, np.newaxis], axis=0)
    
    # delta = (v - kv_mem) * beta
    delta = (v_h - kv_mem) * beta
    
    # state += k * delta
    state[h] += k_h_normed[:, np.newaxis] * delta[np.newaxis, :]
    
    # Output: q @ state
    out_h = np.sum(state[h] * q_h_scaled[:, np.newaxis], axis=0)
    
    # Apply output norm and SiLU
    out_norm = np.linalg.norm(out_h)
    out_h_normed = out_h / np.sqrt(out_norm**2 / vd + 1e-6)
    out_h_final = gdn_norm[h*vd:(h+1)*vd] * out_h_normed * silu(z_h)
    
    if h == 0:
        print(f"    kv_mem[:4]: {kv_mem[:4]}")
        print(f"    delta[:4]: {delta[:4]}")
        print(f"    Output before norm: {out_h[:4]}")
        print(f"    Output after norm: {out_h_normed[:4]}")
        print(f"    Final output (with silu(z)): {out_h_final[:4]}")

# Step 8: Check final logits
print("\n=== Step 8: Final Logits (after all layers) ===")
final_norm = load_tensor(path, 'model.language_model.norm.weight')
if final_norm is None:
    print("Warning: final norm not found, using ones")
    final_norm = np.ones(1024, dtype=np.float32)

# For quick check, let's compute logits from the original embedding
# (This won't match full forward, but can verify the final projection)
print("Note: Full forward requires all 24 layers")
print("Computing simplified logits from embedding * final_norm @ embed_tokens.T")

# Apply final norm to original embedding (simplified)
normed = rmsnorm(x, final_norm)
logits = embed @ normed
print(f"Logits shape: {logits.shape}")
print(f"Logits[0:10]: {logits[:10]}")

# Top predictions
top5_idx = np.argsort(logits)[-5:][::-1]
print(f"\nTop 5 predictions:")
for i, idx in enumerate(top5_idx):
    print(f"  #{i+1}: token_id={idx}, logit={logits[idx]:.4f}")

# Check expected tokens
print(f"\nLogits for expected tokens:")
print(f"  logits[846] (user): {logits[846]:.4f}")
print(f"  logits[198] (newline): {logits[198]:.4f}")
print(f"  logits[248045] (<|im_start|>): {logits[248045]:.4f}")

print("\n=== Summary ===")
print("Key values for comparison with C engine:")
print(f"  Embedding norm: {np.linalg.norm(x):.6f}")
print(f"  Layernorm output norm: {np.linalg.norm(x1):.6f}")
print(f"  QKV norm (before conv): {np.linalg.norm(qkv):.6f}")
print(f"  QKV norm (after conv): {np.linalg.norm(qkv_conv):.6f}")
print(f"  Q first 4: {q[:4]}")
print(f"  K first 4: {k[:4]}")
print(f"  V first 4: {v[:4]}")