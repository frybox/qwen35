#!/usr/bin/env python3
"""Direct byte comparison to find C engine loading issue."""
import numpy as np
import struct
import json

# Load directly from safetensors
path = '/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors'
token_id = 248045

with open(path, 'rb') as f:
    # Read header
    header_size = struct.unpack('<Q', f.read(8))[0]
    header = f.read(header_size).decode('utf-8')
    meta = json.loads(header)
    
    # Get embedding tensor info
    embed_info = meta['model.language_model.embed_tokens.weight']
    start, end = embed_info['data_offsets']
    shape = embed_info['shape']
    
    print(f"Embedding shape: {shape}")
    print(f"Embedding dtype: {embed_info['dtype']}")
    print(f"Data offsets: {start} - {end}")
    
    # Read raw bytes for token 248045
    row_size = shape[1]  # 1024 elements per token
    bytes_per_elem = 2   # BF16
    
    data_start = 8 + header_size + start
    token_offset = token_id * row_size * bytes_per_elem
    
    f.seek(data_start + token_offset)
    raw_bytes = f.read(row_size * bytes_per_elem)
    
    print(f"\nRaw bytes for token {token_id}:")
    print(f"First 16 bytes (hex): {raw_bytes[:16].hex()}")
    
    # Convert BF16 to FP32 (same as C engine)
    bf16 = np.frombuffer(raw_bytes, dtype=np.uint16)
    print(f"\nBF16 values (first 4): {bf16[:4]}")
    print(f"BF16 hex: {[hex(x) for x in bf16[:4]]}")
    
    # Method 1: Shift left 16 bits (same as C)
    fp32_method1 = (bf16.astype(np.uint32) << 16).view(np.float32)
    print(f"\nMethod 1 (shift left 16): {fp32_method1[:10]}")
    
    # Check C engine values
    c_first4 = [0.0066, 0.0081, -0.0011, 0.0001]
    print(f"\nC engine reports: {c_first4}")
    
    # Try to reverse engineer what C engine read
    # If C got 0.0066, what BF16 value would that be?
    def fp32_to_bf16_approx(val):
        """Convert FP32 to BF16 approximation."""
        bits = struct.unpack('<I', struct.pack('<f', val))[0]
        bf16_bits = bits >> 16
        return bf16_bits
    
    print("\nReverse engineering C engine values:")
    for i, v in enumerate(c_first4):
        expected_bf16 = fp32_to_bf16_approx(v)
        actual_bf16 = bf16[i]
        print(f"  [{i}] C={v}, expected BF16=0x{expected_bf16:04x}, actual BF16=0x{actual_bf16:04x}, diff={actual_bf16 - expected_bf16}")
    
    # Check if there's an offset issue
    print("\n=== Checking for offset/row issues ===")
    # Try reading token 0
    f.seek(data_start)
    raw_token0 = f.read(row_size * bytes_per_elem)
    bf16_token0 = np.frombuffer(raw_token0, dtype=np.uint16)
    fp32_token0 = (bf16_token0.astype(np.uint32) << 16).view(np.float32)
    print(f"Token 0 first 4: {fp32_token0[:4]}")
    
    # Try reading with row-major vs column-major assumption
    # Maybe embedding is transposed?
    print("\n=== Checking if embedding is transposed ===")
    # If transposed, element 0 would be at offset 0, element 1 at offset vocab_size*2
    f.seek(data_start + 1 * shape[0] * 2)  # column 1
    raw_col1 = f.read(4)  # just 2 bytes = 1 element
    bf16_col1 = np.frombuffer(raw_col1, dtype=np.uint16)
    fp32_col1 = (bf16_col1.astype(np.uint32) << 16).view(np.float32)
    print(f"Column-major element 0: {fp32_col1[0]:.6f}")
    
    # Verify: what Python thinks token 0 should be
    print(f"Row-major token 0 first element: {fp32_token0[0]:.6f}")

# Summary
print("\n" + "="*60)
print("CONCLUSION")
print("="*60)
print(f"Python (correct) token {token_id} first 4: {fp32_method1[:4]}")
print(f"C engine reports first 4: {c_first4}")
print(f"\nDiff at element 0: {abs(fp32_method1[0] - c_first4[0]):.6f}")
print("\nThe values are DIFFERENT - need to investigate C engine loading code.")