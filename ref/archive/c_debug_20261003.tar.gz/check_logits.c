#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

extern float *load_tensor_f32(SafetensorsFile *sf, const char *name, int expected_size);

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) { printf("Failed to open\n"); return 1; }
    
    // Load just embedding
    float *embed = load_tensor_f32(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    float *norm = load_tensor_f32(sf, "model.language_model.norm.weight", 1024);
    
    // Token 248045 embedding
    float *tok = embed + 248045 * 1024;
    
    // RMSNorm (final norm)
    float ss = 0;
    for (int i = 0; i < 1024; i++) ss += tok[i] * tok[i];
    ss = 1.0f / sqrtf(ss / 1024 + 1e-6f);
    float *normed = malloc(1024 * sizeof(float));
    for (int i = 0; i < 1024; i++) normed[i] = norm[i] * ss * tok[i];
    
    // Compute logits for specific tokens
    float logit_846 = 0, logit_234967 = 0, logit_198 = 0;
    for (int i = 0; i < 1024; i++) {
        logit_846 += embed[846 * 1024 + i] * normed[i];
        logit_234967 += embed[234967 * 1024 + i] * normed[i];
        logit_198 += embed[198 * 1024 + i] * normed[i];
    }
    
    printf("Logit for token 846 (\"user\"): %.4f\n", logit_846);
    printf("Logit for token 234967: %.4f\n", logit_234967);
    printf("Logit for token 198 (\"\\n\"): %.4f\n", logit_198);
    
    safetensors_close(sf);
    free(normed);
    return 0;
}
