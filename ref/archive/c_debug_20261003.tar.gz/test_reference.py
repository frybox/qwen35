# Minimal reference test using numpy only
import numpy as np
import json
import struct

def load_tensor(path, name):
    with open(path, 'rb') as f:
        header_size = struct.unpack('<Q', f.read(8))[0]
        header = f.read(header_size).decode('utf-8')
        meta = json.loads(header)
        
        if name not in meta:
            return None
        info = meta[name]
        start, end = info['data_offsets']
        f.seek(8 + header_size + start)
        data = f.read(end - start)
        
        if info['dtype'] == 'BF16':
            bf16 = np.frombuffer(data, dtype=np.uint16)
            fp32 = (bf16.astype(np.uint32) << 16).view(np.float32)
            return fp32.reshape(info['shape'])
        elif info['dtype'] == 'F32':
            return np.frombuffer(data, dtype=np.float32).reshape(info['shape'])
        else:
            return None

path = '/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors'

# Test embedding lookup
embed = load_tensor(path, 'model.language_model.embed_tokens.weight')
print(f"Embedding shape: {embed.shape}")

# Get embedding for token 198 (newline)
tok_198 = embed[198]
print(f"Embedding for token 198: norm = {np.linalg.norm(tok_198):.4f}")

# Get embedding for token 248045 (<|im_start|>)
tok_start = embed[248045]
print(f"Embedding for token 248045: norm = {np.linalg.norm(tok_start):.4f}")

# Test RMSNorm
def rmsnorm(x, w, eps=1e-6):
    variance = np.mean(x ** 2)
    x_normed = x * np.reciprocal(np.sqrt(variance + eps))
    return w * x_normed

# Load final norm
final_norm = load_tensor(path, 'model.language_model.norm.weight')
print(f"Final norm shape: {final_norm.shape}")
print(f"Final norm mean: {np.mean(final_norm):.4f}")

# Test: apply RMSNorm to embedding
normed = rmsnorm(tok_198, final_norm)
print(f"Normed embedding norm: {np.linalg.norm(normed):.4f}")

# Test logits computation (embed @ normed)
logits = embed @ normed
print(f"Logits shape: {logits.shape}")
print(f"Logits[198]: {logits[198]:.4f}")
print(f"Top 5 logits: {np.argsort(logits)[-5:][::-1]}")
print(f"Top 5 values: {logits[np.argsort(logits)[-5:][::-1]]}")
