// Test GDN behavior at position 0 with zero state
#include <stdio.h>
#include <math.h>

int main() {
    // Simulate GDN at pos 0
    // State is initially zero
    float state[128][128] = {0};  // [kd, vd] = [128, 128]
    
    // At pos 0, state is zero, so:
    // kv_mem = state @ k = 0
    // delta = (v - kv_mem) * beta = v * beta
    // state += outer(k, delta)
    // out = state @ q
    
    // So at pos 0:
    // - State is zero
    // - After first token: state = outer(k, v * beta)
    // - Output = (outer(k, v * beta) @ q) = v * beta * (k . q)
    
    // This is similar to a single-token attention where Q attends to itself
    
    printf("GDN at pos 0:\n");
    printf("  State starts as zero\n");
    printf("  After processing: state = outer(k, v * beta)\n");
    printf("  Output = state @ q = v * beta * (k . q)\n");
    printf("\nThis is a weighted version of v, scaled by beta and (k.q)\n");
    
    // Let's check if this is the expected behavior
    // In standard attention, the first token would attend only to itself:
    // att = softmax(Q @ K.T / sqrt(d)) = softmax([score]) = [1.0]
    // output = 1.0 * V = V
    
    // In GDN:
    // output = v * beta * (k . q)
    
    // These are different! The GDN output is scaled by beta and (k.q)
    
    printf("\nIn standard attention at pos 0:\n");
    printf("  Output = V (no scaling)\n");
    printf("\nIn GDN at pos 0:\n");
    printf("  Output = V * beta * (k.q)\n");
    printf("\nIf beta is small or (k.q) is not 1, the output will be different!\n");
    
    return 0;
}
