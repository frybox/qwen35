// Debug full generation with detailed layer tracking
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

#define NLAYERS 24
#define DIM 1024
#define FFNDIM 3584
#define NHEADS 8
#define NKVHEADS 2
#define HEAD_DIM 256
#define GDN_VHEADS 16
#define GDN_KDIM 128
#define GDN_VDIM 128

int layer_types[24] = {0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1};

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float silu(float x) { return x / (1.0f + expf(-x)); }

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    if (!m) return NULL;
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

void softmax(float *x, int n) {
    float maxv = x[0];
    for (int i = 1; i < n; i++) if (x[i] > maxv) maxv = x[i];
    float sum = 0;
    for (int i = 0; i < n; i++) { x[i] = expf(x[i] - maxv); sum += x[i]; }
    for (int i = 0; i < n; i++) x[i] /= sum;
}

// RoPE - CORRECTED VERSION
void apply_rope(float *q, float *k, int head_dim, int nq, int nkv, int pos) {
    // Qwen3.5: rope_theta = 10000000 (from config.json)
    float theta = 10000000.0f;
    int rotary_dim = head_dim / 4;  // 64
    
    for (int h = 0; h < nq; h++) {
        for (int i = 0; i < rotary_dim; i += 2) {
            float freq = 1.0f / powf(theta, (float)(2*i) / rotary_dim);
            float val = pos * freq;
            float cr = cosf(val), ci = sinf(val);
            float v0 = q[h*head_dim + i], v1 = q[h*head_dim + i + 1];
            q[h*head_dim + i] = v0*cr - v1*ci;
            q[h*head_dim + i + 1] = v0*ci + v1*cr;
        }
    }
    for (int h = 0; h < nkv; h++) {
        for (int i = 0; i < rotary_dim; i += 2) {
            float freq = 1.0f / powf(theta, (float)(2*i) / rotary_dim);
            float val = pos * freq;
            float cr = cosf(val), ci = sinf(val);
            float v0 = k[h*head_dim + i], v1 = k[h*head_dim + i + 1];
            k[h*head_dim + i] = v0*cr - v1*ci;
            k[h*head_dim + i + 1] = v0*ci + v1*cr;
        }
    }
}

int main() {
    printf("=== Full Generation Debug ===\n\n");
    
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) { printf("Failed to open model\n"); return 1; }
    
    // Load embeddings and final norm
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * DIM);
    float *final_norm = load_tensor(sf, "model.language_model.norm.weight", DIM);
    
    // Load all layer weights
    float *ln1[NLAYERS], *ln2[NLAYERS], *gate[NLAYERS], *up[NLAYERS], *down[NLAYERS];
    float *gdn_qkv[NLAYERS], *gdn_z[NLAYERS], *gdn_a[NLAYERS], *gdn_b[NLAYERS];
    float *gdn_A[NLAYERS], *gdn_dt[NLAYERS], *gdn_norm[NLAYERS], *gdn_out[NLAYERS], *gdn_conv[NLAYERS];
    float *fa_q[NLAYERS], *fa_k[NLAYERS], *fa_v[NLAYERS], *fa_o[NLAYERS], *fa_qn[NLAYERS], *fa_kn[NLAYERS];
    
    char name[256];
    for (int l = 0; l < NLAYERS; l++) {
        sprintf(name, "model.language_model.layers.%d.input_layernorm.weight", l);
        ln1[l] = load_tensor(sf, name, DIM);
        
        sprintf(name, "model.language_model.layers.%d.post_attention_layernorm.weight", l);
        ln2[l] = load_tensor(sf, name, DIM);
        
        sprintf(name, "model.language_model.layers.%d.mlp.gate_proj.weight", l);
        gate[l] = load_tensor(sf, name, FFNDIM * DIM);
        
        sprintf(name, "model.language_model.layers.%d.mlp.up_proj.weight", l);
        up[l] = load_tensor(sf, name, FFNDIM * DIM);
        
        sprintf(name, "model.language_model.layers.%d.mlp.down_proj.weight", l);
        down[l] = load_tensor(sf, name, DIM * FFNDIM);
        
        if (layer_types[l] == 0) {
            // GDN layer
            sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_qkv.weight", l);
            gdn_qkv[l] = load_tensor(sf, name, 6144 * DIM);
            sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_z.weight", l);
            gdn_z[l] = load_tensor(sf, name, 2048 * DIM);
            sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_a.weight", l);
            gdn_a[l] = load_tensor(sf, name, GDN_VHEADS * DIM);
            sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_b.weight", l);
            gdn_b[l] = load_tensor(sf, name, GDN_VHEADS * DIM);
            sprintf(name, "model.language_model.layers.%d.linear_attn.A_log", l);
            gdn_A[l] = load_tensor(sf, name, GDN_VHEADS);
            sprintf(name, "model.language_model.layers.%d.linear_attn.dt_bias", l);
            gdn_dt[l] = load_tensor(sf, name, GDN_VHEADS);
            sprintf(name, "model.language_model.layers.%d.linear_attn.norm.weight", l);
            gdn_norm[l] = load_tensor(sf, name, GDN_KDIM);
            sprintf(name, "model.language_model.layers.%d.linear_attn.out_proj.weight", l);
            gdn_out[l] = load_tensor(sf, name, DIM * (GDN_VHEADS * GDN_VDIM));
            sprintf(name, "model.language_model.layers.%d.linear_attn.conv1d.weight", l);
            gdn_conv[l] = load_tensor(sf, name, 6144 * 4);
        } else {
            // Full attention layer
            sprintf(name, "model.language_model.layers.%d.self_attn.q_proj.weight", l);
            fa_q[l] = load_tensor(sf, name, 4096 * DIM);
            sprintf(name, "model.language_model.layers.%d.self_attn.k_proj.weight", l);
            fa_k[l] = load_tensor(sf, name, 512 * DIM);
            sprintf(name, "model.language_model.layers.%d.self_attn.v_proj.weight", l);
            fa_v[l] = load_tensor(sf, name, 512 * DIM);
            sprintf(name, "model.language_model.layers.%d.self_attn.o_proj.weight", l);
            fa_o[l] = load_tensor(sf, name, DIM * 2048);
            sprintf(name, "model.language_model.layers.%d.self_attn.q_norm.weight", l);
            fa_qn[l] = load_tensor(sf, name, HEAD_DIM);
            sprintf(name, "model.language_model.layers.%d.self_attn.k_norm.weight", l);
            fa_kn[l] = load_tensor(sf, name, HEAD_DIM);
        }
    }
    
    printf("All weights loaded\n");
    
    // State buffers
    float x[DIM], x_norm[DIM], qkv[6144], z[2048], a[16], b[16];
    
    // Allocate large arrays on heap (too large for stack)
    float (*gdn_state)[16][128*128] = malloc(NLAYERS * 16 * 128 * 128 * sizeof(float));
    memset(gdn_state, 0, NLAYERS * 16 * 128 * 128 * sizeof(float));
    
    float (*conv_state)[6144*4] = malloc(NLAYERS * 6144 * 4 * sizeof(float));
    memset(conv_state, 0, NLAYERS * 6144 * 4 * sizeof(float));
    
    float (*kcache)[4096][512] = malloc(NLAYERS * 4096 * 512 * sizeof(float));
    float (*vcache)[4096][512] = malloc(NLAYERS * 4096 * 512 * sizeof(float));
    memset(kcache, 0, NLAYERS * 4096 * 512 * sizeof(float));
    memset(vcache, 0, NLAYERS * 4096 * 512 * sizeof(float));
    
    float gdn_out_buf[2048], attn_out[1024];
    float mlp_gate_buf[FFNDIM], mlp_up_buf[FFNDIM], mlp_final[DIM];
    
    // Process prompt tokens
    int tokens[] = {248045, 846, 198, 58, 1319, 34233, 248046, 198, 248045, 74455, 198};
    int n_tokens = 11;
    
    for (int pos = 0; pos < n_tokens; pos++) {
        int tok = tokens[pos];
        memcpy(x, embed + tok * DIM, sizeof(x));
        
        if (pos == 0 || pos == n_tokens - 1) {
            printf("\n=== Pos %d, Token %d ===\n", pos, tok);
            printf("x [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
        }
        
        // Forward through all layers
        for (int l = 0; l < NLAYERS; l++) {
            rmsnorm(x_norm, x, ln1[l], DIM);
            
            if (layer_types[l] == 0) {
                // GDN layer
                matmul(qkv, gdn_qkv[l], x_norm, DIM, 6144);
                
                // Conv1D
                for (int i = 0; i < 6144; i++) {
                    float *cs = conv_state[l] + i * 4;
                    float *cw = gdn_conv[l] + i * 4;
                    cs[0] = cs[1]; cs[1] = cs[2]; cs[2] = cs[3]; cs[3] = qkv[i];
                    float sum = 0;
                    for (int k = 0; k < 4; k++) sum += cs[k] * cw[k];
                    qkv[i] = sum;
                }
                
                matmul(z, gdn_z[l], x_norm, DIM, 2048);
                matmul(a, gdn_a[l], x_norm, DIM, 16);
                matmul(b, gdn_b[l], x_norm, DIM, 16);
                
                for (int h = 0; h < 16; h++) {
                    float *q = qkv + h * 128;
                    float *k = qkv + 2048 + h * 128;
                    float *v = qkv + 4096 + h * 128;
                    float *zh = z + h * 128;
                    float *sh = gdn_state[l][h];
                    float *out = gdn_out_buf + h * 128;
                    
                    // L2 norm Q, K
                    float qn = 0, kn = 0;
                    for (int i = 0; i < 128; i++) { qn += q[i]*q[i]; kn += k[i]*k[i]; }
                    qn = 1.0f / sqrtf(qn + 1e-6f);
                    kn = 1.0f / sqrtf(kn + 1e-6f);
                    for (int i = 0; i < 128; i++) { q[i] *= qn; k[i] *= kn; }
                    
                    // Scale Q
                    for (int i = 0; i < 128; i++) q[i] /= sqrtf(128.0f);
                    
                    // Decay and beta
                    float beta = 1.0f / (1.0f + expf(-b[h]));
                    float sp = logf(1.0f + expf(a[h] + gdn_dt[l][h]));
                    float g = -expf(gdn_A[l][h]) * sp;
                    float gamma = expf(g);
                    
                    // Decay state
                    for (int i = 0; i < 128 * 128; i++) sh[i] *= gamma;
                    
                    // kv_mem
                    float kv_mem[128] = {0};
                    for (int j = 0; j < 128; j++) {
                        for (int i = 0; i < 128; i++) kv_mem[j] += sh[i*128 + j] * k[i];
                    }
                    
                    // delta
                    float delta[128];
                    for (int j = 0; j < 128; j++) delta[j] = (v[j] - kv_mem[j]) * beta;
                    
                    // Update state
                    for (int i = 0; i < 128; i++) {
                        for (int j = 0; j < 128; j++) sh[i*128 + j] += k[i] * delta[j];
                    }
                    
                    // Output
                    for (int j = 0; j < 128; j++) {
                        float sum = 0;
                        for (int i = 0; i < 128; i++) sum += sh[i*128 + j] * q[i];
                        out[j] = sum;
                    }
                    
                    // Gated norm
                    float ss = 0;
                    for (int j = 0; j < 128; j++) ss += out[j] * out[j];
                    ss = 1.0f / sqrtf(ss / 128 + 1e-6f);
                    for (int j = 0; j < 128; j++) out[j] = gdn_norm[l][j] * ss * out[j] * silu(zh[j]);
                }
                
                // Out projection
                matmul(attn_out, gdn_out[l], gdn_out_buf, 2048, DIM);
                
            } else {
                // Full attention layer
                float q_gate[4096], q[2048], gate[2048], k[512], v[512];
                
                matmul(q_gate, fa_q[l], x_norm, DIM, 4096);
                memcpy(q, q_gate, 2048 * sizeof(float));
                memcpy(gate, q_gate + 2048, 2048 * sizeof(float));
                
                // Q norm
                for (int h = 0; h < NHEADS; h++) {
                    rmsnorm(q + h*HEAD_DIM, q + h*HEAD_DIM, fa_qn[l], HEAD_DIM);
                }
                
                // K projection and norm
                matmul(k, fa_k[l], x_norm, DIM, 512);
                for (int h = 0; h < NKVHEADS; h++) {
                    rmsnorm(k + h*HEAD_DIM, k + h*HEAD_DIM, fa_kn[l], HEAD_DIM);
                }
                
                // V projection
                matmul(v, fa_v[l], x_norm, DIM, 512);
                
                // Apply RoPE
                apply_rope(q, k, HEAD_DIM, NHEADS, NKVHEADS, pos);
                
                // Cache K, V
                memcpy(&kcache[l][pos][0], k, 512 * sizeof(float));
                memcpy(&vcache[l][pos][0], v, 512 * sizeof(float));
                
                // Attention
                float att[4096];
                int gqa = NHEADS / NKVHEADS;
                
                for (int h = 0; h < NHEADS; h++) {
                    float *qh = q + h * HEAD_DIM;
                    int kvh = h / gqa;
                    
                    for (int t = 0; t <= pos; t++) {
                        float *kt = &kcache[l][t][kvh * HEAD_DIM];
                        float score = 0;
                        for (int i = 0; i < HEAD_DIM; i++) score += qh[i] * kt[i];
                        att[t] = score / sqrtf((float)HEAD_DIM);
                    }
                    softmax(att, pos + 1);
                    
                    float *out = gdn_out_buf + h * HEAD_DIM;
                    memset(out, 0, HEAD_DIM * sizeof(float));
                    for (int t = 0; t <= pos; t++) {
                        float *vt = &vcache[l][t][kvh * HEAD_DIM];
                        for (int i = 0; i < HEAD_DIM; i++) {
                            out[i] += att[t] * vt[i];
                        }
                    }
                }
                
                // Apply gate
                for (int i = 0; i < 2048; i++) {
                    float g = 1.0f / (1.0f + expf(-gate[i]));
                    gdn_out_buf[i] *= g;
                }
                
                // Output projection
                matmul(attn_out, fa_o[l], gdn_out_buf, 2048, DIM);
            }
            
            // Residual
            for (int i = 0; i < DIM; i++) x[i] += attn_out[i];
            
            // MLP
            rmsnorm(x_norm, x, ln2[l], DIM);
            matmul(mlp_gate_buf, gate[l], x_norm, DIM, FFNDIM);
            matmul(mlp_up_buf, up[l], x_norm, DIM, FFNDIM);
            
            for (int i = 0; i < FFNDIM; i++) mlp_gate_buf[i] = silu(mlp_gate_buf[i]) * mlp_up_buf[i];
            
            matmul(mlp_final, down[l], mlp_gate_buf, FFNDIM, DIM);
            
            // Residual
            for (int i = 0; i < DIM; i++) x[i] += mlp_final[i];
        }
        
        if (pos == 0 || pos == n_tokens - 1) {
            printf("After all layers, x [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
        }
    }
    
    // Final norm and logits
    printf("\n=== Final output ===\n");
    rmsnorm(x, x, final_norm, DIM);
    printf("After final norm, x [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
    
    // Top logits
    float top_vals[10] = {-1e9};
    int top_ids[10] = {0};
    
    for (int i = 0; i < 248320; i++) {
        float dot = 0;
        for (int j = 0; j < DIM; j++) dot += embed[i * DIM + j] * x[j];
        
        for (int k = 0; k < 10; k++) {
            if (dot > top_vals[k]) {
                for (int m = 9; m > k; m--) {
                    top_vals[m] = top_vals[m-1];
                    top_ids[m] = top_ids[m-1];
                }
                top_vals[k] = dot;
                top_ids[k] = i;
                break;
            }
        }
    }
    
    printf("\nTop 10 tokens:\n");
    for (int i = 0; i < 10; i++) {
        printf("  token %d: logit=%.4f\n", top_ids[i], top_vals[i]);
    }
    
    safetensors_close(sf);
    return 0;
}
