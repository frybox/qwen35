/*
 * Minimal test for Qwen3.5 C engine forward pass
 * Tests: model loading, single forward, logits output
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#include "safetensors.h"
#include "tokenizer.h"

// Config
typedef struct {
    int dim;           // 1024
    int ffndim;        // 3584
    int nlayers;       // 24
    int nheads;        // 8
    int nkvheads;      // 2
    int head_dim;      // 256
    int nvocab;        // 248320
    int nctx;          // 4096
    int gdn_vheads;    // 16
    int gdn_kdim;      // 128
    int gdn_vdim;      // 128
    int layer_types[24];
} Config;

// Weights
typedef struct {
    float *embed_tokens;
    float *embed_norm;
    float *ln1[24];
    float *ln2[24];
    float *gdn_qkv[24];
    float *gdn_z[24];
    float *gdn_a[24];
    float *gdn_b[24];
    float *gdn_A[24];
    float *gdn_dt[24];
    float *gdn_conv[24];
    float *gdn_norm[24];
    float *gdn_out[24];
    float *fa_q[24];
    float *fa_k[24];
    float *fa_v[24];
    float *fa_o[24];
    float *fa_qn[24];
    float *fa_kn[24];
    float *gate[24];
    float *up[24];
    float *down[24];
} Weights;

// State
typedef struct {
    float *x, *x1, *x2;
    float *h, *h1;
    float *logits;
    float *kcache, *vcache;
    float *q, *attn;
    float *gdn_state;
    float *conv_state;
} State;

typedef struct {
    Config c;
    Weights w;
    State s;
    SafetensorsFile *sf;
} Transformer;

static void die(const char *msg) { fprintf(stderr, "Error: %s\n", msg); exit(1); }
void *xmalloc(size_t n) { void *p = calloc(n, 1); if (!p) die("malloc failed"); return p; }

void init_config(Config *c) {
    c->dim = 1024;
    c->ffndim = 3584;
    c->nlayers = 24;
    c->nheads = 8;
    c->nkvheads = 2;
    c->head_dim = 256;
    c->nvocab = 248320;
    c->nctx = 4096;
    c->gdn_vheads = 16;
    c->gdn_kdim = 128;
    c->gdn_vdim = 128;
    for (int i = 0; i < 24; i++) c->layer_types[i] = (i % 4 == 3) ? 1 : 0;
}

float *load_tensor_f32(SafetensorsFile *sf, const char *name, int64_t expected_elems) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) { fprintf(stderr, "Warning: tensor '%s' not found\n", name); return NULL; }
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    if (safetensors_load_tensor_as_f32(sf, meta, data) != 0) {
        fprintf(stderr, "Error: failed to load tensor '%s'\n", name);
        free(data);
        return NULL;
    }
    return data;
}

void load_weights(Transformer *t, const char *path) {
    t->sf = safetensors_open(path);
    if (!t->sf) die("failed to open safetensors file");
    
    Config *c = &t->c;
    char name[256];
    
    printf("Loading weights...\n");
    
    t->w.embed_tokens = load_tensor_f32(t->sf, "model.language_model.embed_tokens.weight", c->nvocab * c->dim);
    if (!t->w.embed_tokens) die("failed to load embed_tokens");
    
    TensorMeta *final_norm = safetensors_get_tensor(t->sf, "model.language_model.norm.weight");
    if (final_norm) {
        t->w.embed_norm = load_tensor_f32(t->sf, "model.language_model.norm.weight", c->dim);
    } else {
        t->w.embed_norm = xmalloc(c->dim * sizeof(float));
        for (int i = 0; i < c->dim; i++) t->w.embed_norm[i] = 1.0f;
    }
    
    for (int l = 0; l < c->nlayers; l++) {
        snprintf(name, sizeof(name), "model.language_model.layers.%d.input_layernorm.weight", l);
        t->w.ln1[l] = load_tensor_f32(t->sf, name, c->dim);
        
        snprintf(name, sizeof(name), "model.language_model.layers.%d.post_attention_layernorm.weight", l);
        t->w.ln2[l] = load_tensor_f32(t->sf, name, c->dim);
        
        if (c->layer_types[l] == 0) {
            snprintf(name, sizeof(name), "model.language_model.layers.%d.linear_attn.in_proj_qkv.weight", l);
            t->w.gdn_qkv[l] = load_tensor_f32(t->sf, name, 6144 * c->dim);
            snprintf(name, sizeof(name), "model.language_model.layers.%d.linear_attn.in_proj_z.weight", l);
            t->w.gdn_z[l] = load_tensor_f32(t->sf, name, 2048 * c->dim);
            snprintf(name, sizeof(name), "model.language_model.layers.%d.linear_attn.in_proj_a.weight", l);
            t->w.gdn_a[l] = load_tensor_f32(t->sf, name, c->gdn_vheads * c->dim);
            snprintf(name, sizeof(name), "model.language_model.layers.%d.linear_attn.in_proj_b.weight", l);
            t->w.gdn_b[l] = load_tensor_f32(t->sf, name, c->gdn_vheads * c->dim);
            snprintf(name, sizeof(name), "model.language_model.layers.%d.linear_attn.A_log", l);
            t->w.gdn_A[l] = load_tensor_f32(t->sf, name, c->gdn_vheads);
            snprintf(name, sizeof(name), "model.language_model.layers.%d.linear_attn.dt_bias", l);
            t->w.gdn_dt[l] = load_tensor_f32(t->sf, name, c->gdn_vheads);
            snprintf(name, sizeof(name), "model.language_model.layers.%d.linear_attn.conv1d.weight", l);
            t->w.gdn_conv[l] = load_tensor_f32(t->sf, name, 6144 * 4);
            snprintf(name, sizeof(name), "model.language_model.layers.%d.linear_attn.norm.weight", l);
            t->w.gdn_norm[l] = load_tensor_f32(t->sf, name, c->gdn_kdim);
            snprintf(name, sizeof(name), "model.language_model.layers.%d.linear_attn.out_proj.weight", l);
            t->w.gdn_out[l] = load_tensor_f32(t->sf, name, c->dim * (c->gdn_vheads * c->gdn_vdim));
        } else {
            snprintf(name, sizeof(name), "model.language_model.layers.%d.self_attn.q_proj.weight", l);
            t->w.fa_q[l] = load_tensor_f32(t->sf, name, 4096 * c->dim);
            int kvdim = c->head_dim * c->nkvheads;
            snprintf(name, sizeof(name), "model.language_model.layers.%d.self_attn.k_proj.weight", l);
            t->w.fa_k[l] = load_tensor_f32(t->sf, name, kvdim * c->dim);
            snprintf(name, sizeof(name), "model.language_model.layers.%d.self_attn.v_proj.weight", l);
            t->w.fa_v[l] = load_tensor_f32(t->sf, name, kvdim * c->dim);
            snprintf(name, sizeof(name), "model.language_model.layers.%d.self_attn.o_proj.weight", l);
            t->w.fa_o[l] = load_tensor_f32(t->sf, name, c->dim * (c->nheads * c->head_dim));
            snprintf(name, sizeof(name), "model.language_model.layers.%d.self_attn.q_norm.weight", l);
            t->w.fa_qn[l] = load_tensor_f32(t->sf, name, c->head_dim);
            snprintf(name, sizeof(name), "model.language_model.layers.%d.self_attn.k_norm.weight", l);
            t->w.fa_kn[l] = load_tensor_f32(t->sf, name, c->head_dim);
        }
        
        snprintf(name, sizeof(name), "model.language_model.layers.%d.mlp.gate_proj.weight", l);
        t->w.gate[l] = load_tensor_f32(t->sf, name, c->ffndim * c->dim);
        snprintf(name, sizeof(name), "model.language_model.layers.%d.mlp.up_proj.weight", l);
        t->w.up[l] = load_tensor_f32(t->sf, name, c->ffndim * c->dim);
        snprintf(name, sizeof(name), "model.language_model.layers.%d.mlp.down_proj.weight", l);
        t->w.down[l] = load_tensor_f32(t->sf, name, c->dim * c->ffndim);
    }
    printf("Weights loaded.\n");
}

void malloc_state(State *s, Config *c) {
    int head_dim = c->head_dim;
    int kvdim = head_dim * c->nkvheads;
    int ngdn = 0;
    for (int i = 0; i < c->nlayers; i++) if (c->layer_types[i] == 0) ngdn++;
    
    s->x = xmalloc(c->dim * sizeof(float));
    s->x1 = xmalloc(c->dim * sizeof(float));
    s->x2 = xmalloc(c->dim * sizeof(float));
    s->h = xmalloc(c->ffndim * sizeof(float));
    s->h1 = xmalloc(c->ffndim * sizeof(float));
    s->logits = xmalloc(c->nvocab * sizeof(float));
    s->kcache = xmalloc(c->nlayers * c->nctx * kvdim * sizeof(float));
    s->vcache = xmalloc(c->nlayers * c->nctx * kvdim * sizeof(float));
    s->q = xmalloc(c->nheads * head_dim * sizeof(float));
    s->attn = xmalloc(c->nheads * c->nctx * sizeof(float));
    s->gdn_state = xmalloc(ngdn * c->gdn_vheads * c->gdn_kdim * c->gdn_vdim * sizeof(float));
    s->conv_state = xmalloc(ngdn * 6144 * 4 * sizeof(float));
}

// Math operations
void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = (1.0f + w[i]) * ss * x[i];  // Qwen3.5 RMSNorm: 1 + weight
}

void softmax(float *x, int n) {
    float maxv = x[0];
    for (int i = 1; i < n; i++) if (x[i] > maxv) maxv = x[i];
    float sum = 0;
    for (int i = 0; i < n; i++) { x[i] = expf(x[i] - maxv); sum += x[i]; }
    for (int i = 0; i < n; i++) x[i] /= sum;
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float silu(float x) { return x / (1.0f + expf(-x)); }

void apply_rope(float *q, float *k, int head_dim, int nq, int nkv, int pos) {
    int rotary_dim = head_dim / 4;
    float theta = 10000000.0f;
    for (int h = 0; h < nq; h++) {
        for (int i = 0; i < rotary_dim; i += 2) {
            float freq = 1.0f / powf(theta, (float)(2*i) / (head_dim/4));  // rotary_dim = head_dim/4
            float val = pos * freq;
            float cr = cosf(val), ci = sinf(val);
            float v0 = q[h*head_dim + i], v1 = q[h*head_dim + i + 1];
            q[h*head_dim + i] = v0*cr - v1*ci;
            q[h*head_dim + i + 1] = v0*ci + v1*cr;
        }
    }
    for (int h = 0; h < nkv; h++) {
        for (int i = 0; i < rotary_dim; i += 2) {
            float freq = 1.0f / powf(theta, (float)(2*i) / (head_dim/4));  // rotary_dim = head_dim/4
            float val = pos * freq;
            float cr = cosf(val), ci = sinf(val);
            float v0 = k[h*head_dim + i], v1 = k[h*head_dim + i + 1];
            k[h*head_dim + i] = v0*cr - v1*ci;
            k[h*head_dim + i + 1] = v0*ci + v1*cr;
        }
    }
}

void forward_full_attn(Transformer *t, int layer, int pos) {
    Config *c = &t->c;
    State *s = &t->s;
    Weights *w = &t->w;
    int dim = c->dim;
    int head_dim = c->head_dim;
    int kvdim = head_dim * c->nkvheads;
    int gqa = c->nheads / c->nkvheads;
    
    rmsnorm(s->x1, s->x, w->ln1[layer], dim);
    float *q_gate = s->h1;
    matmul(q_gate, w->fa_q[layer], s->x1, dim, dim * 4);
    int qsize = c->nheads * head_dim;
    float *q = s->q;
    float *gate = q_gate + qsize;
    memcpy(q, q_gate, qsize * sizeof(float));
    for (int h = 0; h < c->nheads; h++) {
        rmsnorm(s->x2 + h*head_dim, q + h*head_dim, w->fa_qn[layer], head_dim);
    }
    memcpy(q, s->x2, qsize * sizeof(float));
    float *k = s->x2;
    matmul(k, w->fa_k[layer], s->x1, dim, kvdim);
    for (int h = 0; h < c->nkvheads; h++) {
        rmsnorm(k + h*head_dim, k + h*head_dim, w->fa_kn[layer], head_dim);
    }
    float *v = s->h;
    matmul(v, w->fa_v[layer], s->x1, dim, kvdim);
    apply_rope(q, k, head_dim, c->nheads, c->nkvheads, pos);
    size_t loff = (size_t)layer * c->nctx * kvdim;
    memcpy(s->kcache + loff + pos*kvdim, k, kvdim * sizeof(float));
    memcpy(s->vcache + loff + pos*kvdim, v, kvdim * sizeof(float));
    for (int h = 0; h < c->nheads; h++) {
        float *qh = q + h*head_dim;
        float *att = s->attn + h*c->nctx;
        int kvh = h / gqa;
        for (int t = 0; t <= pos; t++) {
            float *kt = s->kcache + loff + t*kvdim + kvh*head_dim;
            float score = 0;
            for (int i = 0; i < head_dim; i++) score += qh[i] * kt[i];
            att[t] = score / sqrtf((float)head_dim);
        }
        softmax(att, pos + 1);
        float *out = s->x1 + h*head_dim;
        memset(out, 0, head_dim * sizeof(float));
        for (int t = 0; t <= pos; t++) {
            float *vt = s->vcache + loff + t*kvdim + kvh*head_dim;
            for (int i = 0; i < head_dim; i++) out[i] += att[t] * vt[i];
        }
    }
    for (int i = 0; i < dim; i++) s->x1[i] = s->x1[i] * (1.0f / (1.0f + expf(-gate[i])));
    matmul(s->x2, w->fa_o[layer], s->x1, c->nheads * head_dim, dim);
    for (int i = 0; i < dim; i++) s->x[i] += s->x2[i];
}

void forward_linear_attn(Transformer *t, int layer, int pos) {
    Config *c = &t->c;
    State *s = &t->s;
    Weights *w = &t->w;
    int dim = c->dim;
    int nv = c->gdn_vheads;
    int kd = c->gdn_kdim;
    int vd = c->gdn_vdim;
    
    rmsnorm(s->x1, s->x, w->ln1[layer], dim);
    float *qkv = s->h;
    matmul(qkv, w->gdn_qkv[layer], s->x1, dim, 6144);
    int gdn_idx = 0;
    for (int i = 0; i < layer; i++) if (c->layer_types[i] == 0) gdn_idx++;
    float *conv_s = s->conv_state + gdn_idx * 6144 * 4;
    float *conv_w = w->gdn_conv[layer];
    for (int ch = 0; ch < 6144; ch++) {
        float *cs = conv_s + ch * 4;
        float *cw = conv_w + ch * 4;
        cs[0] = cs[1]; cs[1] = cs[2]; cs[2] = cs[3];
        cs[3] = qkv[ch];
        float sum = 0;
        for (int k = 0; k < 4; k++) sum += cs[k] * cw[k];
        qkv[ch] = sum;
    }
    float *z = s->h1;
    matmul(z, w->gdn_z[layer], s->x1, dim, nv * vd);
    float *ab = s->x2;
    matmul(ab, w->gdn_a[layer], s->x1, dim, nv);
    matmul(ab + nv, w->gdn_b[layer], s->x1, dim, nv);
    for (int i = nv; i < 2*nv; i++) ab[i] = 1.0f / (1.0f + expf(-ab[i]));
    float *A = w->gdn_A[layer];
    float *dt = w->gdn_dt[layer];
    float *state = s->gdn_state + gdn_idx * nv * kd * vd;
    for (int h = 0; h < nv; h++) {
        float *q = qkv + h * kd;
        float *k = qkv + nv * kd + h * kd;
        float *v = qkv + 2 * nv * kd + h * kd;
        float *zh = z + h * vd;
        float *sh = state + h * kd * vd;
        float q_norm = 0, k_norm = 0;
        for (int i = 0; i < kd; i++) { q_norm += q[i]*q[i]; k_norm += k[i]*k[i]; }
        q_norm = 1.0f / sqrtf(q_norm + 1e-6f);
        k_norm = 1.0f / sqrtf(k_norm + 1e-6f);
        for (int i = 0; i < kd; i++) { q[i] *= q_norm; k[i] *= k_norm; }
        float scale = 1.0f / sqrtf((float)kd);
        for (int i = 0; i < kd; i++) q[i] *= scale;
        float a = ab[h];
        float b = ab[nv + h];
        float sp = logf(1.0f + expf(a + dt[h]));  // FIX: use a + dt_bias
        float g = -expf(A[h]) * sp;
        float gamma = expf(g);
        float beta = b;
        for (int i = 0; i < kd * vd; i++) sh[i] *= gamma;
        float kv_mem[128];
        for (int j = 0; j < vd; j++) {
            float sum = 0;
            for (int i = 0; i < kd; i++) sum += sh[i*vd + j] * k[i];
            kv_mem[j] = sum;
        }
        float delta[128];
        for (int j = 0; j < vd; j++) delta[j] = (v[j] - kv_mem[j]) * beta;
        for (int i = 0; i < kd; i++) {
            for (int j = 0; j < vd; j++) sh[i*vd + j] += k[i] * delta[j];
        }
        float *out = s->x1 + h * vd;
        for (int j = 0; j < vd; j++) {
            float sum = 0;
            for (int i = 0; i < kd; i++) sum += sh[i*vd + j] * q[i];
            out[j] = sum;
        }
        float ss = 0;
        for (int j = 0; j < vd; j++) ss += out[j] * out[j];
        ss = 1.0f / sqrtf(ss / vd + 1e-6f);
        for (int j = 0; j < vd; j++) out[j] = w->gdn_norm[layer][j] * ss * out[j] * silu(zh[j]);
    }
    matmul(s->x2, w->gdn_out[layer], s->x1, nv * vd, dim);
    for (int i = 0; i < dim; i++) s->x[i] += s->x2[i];
}

void forward_mlp(Transformer *t, int layer) {
    Config *c = &t->c;
    State *s = &t->s;
    Weights *w = &t->w;
    int dim = c->dim;
    int ffndim = c->ffndim;
    rmsnorm(s->x1, s->x, w->ln2[layer], dim);
    matmul(s->h, w->gate[layer], s->x1, dim, ffndim);
    matmul(s->h1, w->up[layer], s->x1, dim, ffndim);
    for (int i = 0; i < ffndim; i++) s->h[i] = silu(s->h[i]) * s->h1[i];
    matmul(s->x1, w->down[layer], s->h, ffndim, dim);
    for (int i = 0; i < dim; i++) s->x[i] += s->x1[i];
}

float *forward(Transformer *t, int token, int pos) {
    Config *c = &t->c;
    State *s = &t->s;
    memcpy(s->x, t->w.embed_tokens + token * c->dim, c->dim * sizeof(float));
    
    // Print embedding
    printf("\n[DEBUG] After embedding copy:\n");
    printf("  x[0:10] = ");
    for (int i = 0; i < 10; i++) printf("%.6f ", s->x[i]);
    printf("\n");
    
    for (int l = 0; l < c->nlayers; l++) {
        if (c->layer_types[l] == 0) {
            forward_linear_attn(t, l, pos);
        } else {
            forward_full_attn(t, l, pos);
        }
        
        // Debug: print after layer 0
        if (l == 0) {
            printf("\n[DEBUG] After layer 0 (first attention + MLP):\n");
            printf("  x[0:10] = ");
            for (int i = 0; i < 10; i++) printf("%.6f ", s->x[i]);
            printf("\n");
        }
        
        forward_mlp(t, l);
    }
    rmsnorm(s->x, s->x, t->w.embed_norm, c->dim);
    matmul(s->logits, t->w.embed_tokens, s->x, c->dim, c->nvocab);
    return s->logits;
}

int main(int argc, char **argv) {
    const char *model_path = "/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors";
    if (argc >= 2) model_path = argv[1];
    
    printf("=== Minimal Forward Test ===\n\n");
    
    clock_t start_total = clock();
    
    Transformer tr;
    memset(&tr, 0, sizeof(Transformer));
    init_config(&tr.c);
    
    printf("Config: dim=%d, nlayers=%d, nvocab=%d\n", tr.c.dim, tr.c.nlayers, tr.c.nvocab);
    
    clock_t start_load = clock();
    load_weights(&tr, model_path);
    clock_t end_load = clock();
    printf("Weight loading time: %.2f seconds\n", (double)(end_load - start_load) / CLOCKS_PER_SEC);
    
    malloc_state(&tr.s, &tr.c);
    
    // Single token forward (BOS token or a test token)
    int test_token = 248045;  // <|im_start|> token
    
    // Print embedding values for token
    printf("\n=== Embedding for token %d ===\n", test_token);
    float *emb = tr.w.embed_tokens + test_token * tr.c.dim;
    printf("First 10 elements: ");
    for (int i = 0; i < 10; i++) printf("%.6f ", emb[i]);
    printf("\n");
    float emb_norm = 0;
    for (int i = 0; i < tr.c.dim; i++) emb_norm += emb[i] * emb[i];
    printf("Embedding norm: %.6f\n", sqrtf(emb_norm));
    
    printf("\n=== Forward pass for token %d ===\n", test_token);
    clock_t start_fwd = clock();
    float *logits = forward(&tr, test_token, 0);
    clock_t end_fwd = clock();
    printf("Forward time: %.3f seconds\n", (double)(end_fwd - start_fwd) / CLOCKS_PER_SEC);
    
    // Print first 10 logits
    printf("\nFirst 10 logits:\n");
    for (int i = 0; i < 10; i++) {
        printf("  logits[%d] = %.4f\n", i, logits[i]);
    }
    
    // Find top-5 tokens
    float top_logits[5] = {-1e9, -1e9, -1e9, -1e9, -1e9};
    int top_ids[5] = {0};
    for (int i = 0; i < tr.c.nvocab; i++) {
        for (int j = 0; j < 5; j++) {
            if (logits[i] > top_logits[j]) {
                for (int k = 4; k > j; k--) {
                    top_logits[k] = top_logits[k-1];
                    top_ids[k] = top_ids[k-1];
                }
                top_logits[j] = logits[i];
                top_ids[j] = i;
                break;
            }
        }
    }
    
    printf("\nTop-5 token predictions:\n");
    for (int i = 0; i < 5; i++) {
        printf("  #%d: token_id=%d, logit=%.4f\n", i+1, top_ids[i], top_logits[i]);
    }
    
    clock_t end_total = clock();
    printf("\nTotal time: %.2f seconds\n", (double)(end_total - start_total) / CLOCKS_PER_SEC);
    
    printf("\n=== Test Complete ===\n");
    
    safetensors_close(tr.sf);
    return 0;
}