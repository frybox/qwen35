// Test full model forward pass
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float silu(float x) { return x / (1.0f + expf(-x)); }

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

int main() {
    printf("Loading model...\n");
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    
    // Load embeddings
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    
    // Load final norm
    float *final_norm = load_tensor(sf, "model.language_model.norm.weight", 1024);
    
    printf("Weights loaded\n");
    
    // Process one token and check output
    int token = 248045;  // <|im_start|>
    
    float x[1024];
    memcpy(x, embed + token * 1024, sizeof(x));
    
    printf("\nToken %d embedding [0:4]: %.4f, %.4f, %.4f, %.4f\n", token, x[0], x[1], x[2], x[3]);
    
    // Load and process layer 0 (GDN)
    float *ln1 = load_tensor(sf, "model.language_model.layers.0.input_layernorm.weight", 1024);
    float *qkv_w = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight", 6144 * 1024);
    float *z_w = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_z.weight", 2048 * 1024);
    float *a_w = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_a.weight", 16 * 1024);
    float *b_w = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_b.weight", 16 * 1024);
    float *A_log = load_tensor(sf, "model.language_model.layers.0.linear_attn.A_log", 16);
    float *dt = load_tensor(sf, "model.language_model.layers.0.linear_attn.dt_bias", 16);
    float *norm_w = load_tensor(sf, "model.language_model.layers.0.linear_attn.norm.weight", 128);
    float *out_w = load_tensor(sf, "model.language_model.layers.0.linear_attn.out_proj.weight", 1024 * 2048);
    float *ln2 = load_tensor(sf, "model.language_model.layers.0.post_attention_layernorm.weight", 1024);
    float *gate_w = load_tensor(sf, "model.language_model.layers.0.mlp.gate_proj.weight", 3584 * 1024);
    float *up_w = load_tensor(sf, "model.language_model.layers.0.mlp.up_proj.weight", 3584 * 1024);
    float *down_w = load_tensor(sf, "model.language_model.layers.0.mlp.down_proj.weight", 1024 * 3584);
    
    printf("Layer 0 weights loaded\n");
    
    // Forward pass
    float x_norm[1024];
    rmsnorm(x_norm, x, ln1, 1024);
    
    float qkv[6144];
    matmul(qkv, qkv_w, x_norm, 1024, 6144);
    
    float z[2048];
    matmul(z, z_w, x_norm, 1024, 2048);
    
    float a[16], b[16];
    matmul(a, a_w, x_norm, 1024, 16);
    matmul(b, b_w, x_norm, 1024, 16);
    
    float state[16 * 128 * 128] = {0};
    float gdn_out[2048];
    
    for (int h = 0; h < 16; h++) {
        float *q = qkv + h * 128;
        float *k = qkv + 16 * 128 + h * 128;
        float *v = qkv + 32 * 128 + h * 128;
        float *zh = z + h * 128;
        float *sh = state + h * 128 * 128;
        float *out = gdn_out + h * 128;
        
        // L2 norm Q, K
        float qn = 0, kn = 0;
        for (int i = 0; i < 128; i++) { qn += q[i]*q[i]; kn += k[i]*k[i]; }
        qn = 1.0f / sqrtf(qn + 1e-6f);
        kn = 1.0f / sqrtf(kn + 1e-6f);
        for (int i = 0; i < 128; i++) { q[i] *= qn; k[i] *= kn; }
        
        // Scale Q
        float sc = 1.0f / sqrtf(128.0f);
        for (int i = 0; i < 128; i++) q[i] *= sc;
        
        // Decay
        float beta = 1.0f / (1.0f + expf(-b[h]));
        float sp = logf(1.0f + expf(a[h] + dt[h]));
        float g = -expf(A_log[h]) * sp;
        float gamma = expf(g);
        
        // First token: state is zero, so kv_mem = 0
        // delta = v * beta
        // state = k @ (v * beta)
        // out = state @ q = (k @ v * beta) @ q
        
        float delta[128];
        for (int j = 0; j < 128; j++) delta[j] = v[j] * beta;
        
        // Update state: state += k.unsqueeze(-1) * delta.unsqueeze(-2)
        for (int i = 0; i < 128; i++) {
            for (int j = 0; j < 128; j++) sh[i*128 + j] = k[i] * delta[j];
        }
        
        // Output
        for (int j = 0; j < 128; j++) {
            float sum = 0;
            for (int i = 0; i < 128; i++) sum += sh[i*128 + j] * q[i];
            out[j] = sum;
        }
        
        // Gated norm
        float ss = 0;
        for (int j = 0; j < 128; j++) ss += out[j] * out[j];
        ss = 1.0f / sqrtf(ss / 128 + 1e-6f);
        for (int j = 0; j < 128; j++) out[j] = norm_w[j] * ss * out[j] * silu(zh[j]);
    }
    
    // Out projection
    float attn_out[1024];
    matmul(attn_out, out_w, gdn_out, 2048, 1024);
    
    // Residual
    for (int i = 0; i < 1024; i++) x[i] += attn_out[i];
    
    // MLP
    float x_mlp[1024];
    rmsnorm(x_mlp, x, ln2, 1024);
    
    float gate[3584], up[3584];
    matmul(gate, gate_w, x_mlp, 1024, 3584);
    matmul(up, up_w, x_mlp, 1024, 3584);
    
    for (int i = 0; i < 3584; i++) gate[i] = silu(gate[i]) * up[i];
    
    float mlp_out[1024];
    matmul(mlp_out, down_w, gate, 3584, 1024);
    
    for (int i = 0; i < 1024; i++) x[i] += mlp_out[i];
    
    printf("After layer 0 [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
    
    // Final norm
    float final_x[1024];
    rmsnorm(final_x, x, final_norm, 1024);
    
    printf("After final norm [0:4]: %.4f, %.4f, %.4f, %.4f\n", final_x[0], final_x[1], final_x[2], final_x[3]);
    
    // Sample logits
    printf("\nSample logits (from embed_tokens):\n");
    for (int t = 0; t < 5; t++) {
        float sum = 0;
        for (int i = 0; i < 1024; i++) sum += embed[t * 1024 + i] * final_x[i];
        printf("  Token %d: logit=%.4f\n", t, sum);
    }
    
    // Check if output is different from embedding
    printf("\nCosine similarity between output and token 248045 embedding:\n");
    float dot = 0, norm_x = 0, norm_e = 0;
    for (int i = 0; i < 1024; i++) {
        dot += final_x[i] * embed[248045 * 1024 + i];
        norm_x += final_x[i] * final_x[i];
        norm_e += embed[248045 * 1024 + i] * embed[248045 * 1024 + i];
    }
    printf("  Cosine sim: %.4f\n", dot / (sqrtf(norm_x) * sqrtf(norm_e)));
    
    safetensors_close(sf);
    return 0;
}