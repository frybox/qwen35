/*
 * Debug forward pass - output intermediate values for Python comparison
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { void *p = calloc(n, 1); if (!p) { fprintf(stderr, "malloc failed\n"); exit(1); } return p; }

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) { fprintf(stderr, "Tensor '%s' not found\n", name); return NULL; }
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    if (safetensors_load_tensor_as_f32(sf, meta, data) != 0) {
        fprintf(stderr, "Failed to load '%s'\n", name);
        free(data);
        return NULL;
    }
    return data;
}

int main() {
    const char *path = "/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors";
    SafetensorsFile *sf = safetensors_open(path);
    if (!sf) { fprintf(stderr, "Failed to open model\n"); return 1; }

    printf("=== Loading tensors ===\n");
    
    // Load embedding
    float *embed = load_tensor_f32(sf, "model.language_model.embed_tokens.weight");
    printf("embed_tokens loaded\n");
    
    // Load layer 0 weights
    float *ln0 = load_tensor_f32(sf, "model.language_model.layers.0.input_layernorm.weight");
    printf("layer0 input_layernorm loaded\n");
    
    float *gdn_qkv = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight");
    printf("layer0 gdn_qkv loaded\n");
    
    float *gdn_A = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.A_log");
    float *gdn_dt = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.dt_bias");
    float *gdn_conv = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.conv1d.weight");
    printf("layer0 GDN params loaded\n");
    
    // Token 248045 embedding
    int token = 248045;
    int dim = 1024;
    float *x = embed + token * dim;
    
    printf("\n=== Step 1: Embedding for token %d ===\n", token);
    printf("x[0:10]:");
    for (int i = 0; i < 10; i++) printf(" %.6f", x[i]);
    printf("\n");
    float norm = 0;
    for (int i = 0; i < dim; i++) norm += x[i] * x[i];
    printf("L2 norm: %.6f\n", sqrtf(norm));
    printf("Mean: %.6f, Std: %.6f\n", 
           norm/dim, 
           sqrtf(norm/dim - (norm/dim)*(norm/dim)));
    
    // LayerNorm
    float *x1 = xmalloc(dim * sizeof(float));
    rmsnorm(x1, x, ln0, dim);
    
    printf("\n=== Step 2: After LayerNorm ===\n");
    printf("x1[0:10]:");
    for (int i = 0; i < 10; i++) printf(" %.6f", x1[i]);
    printf("\n");
    norm = 0;
    for (int i = 0; i < dim; i++) norm += x1[i] * x1[i];
    printf("L2 norm: %.6f\n", sqrtf(norm));
    
    // QKV projection
    float *qkv = xmalloc(6144 * sizeof(float));
    for (int i = 0; i < 6144; i++) {
        float sum = 0;
        for (int j = 0; j < dim; j++) {
            sum += gdn_qkv[i * dim + j] * x1[j];
        }
        qkv[i] = sum;
    }
    
    printf("\n=== Step 3: QKV Projection (before conv) ===\n");
    printf("QKV[0:10]:");
    for (int i = 0; i < 10; i++) printf(" %.6f", qkv[i]);
    printf("\n");
    
    // Split Q, K, V
    float *Q = qkv;
    float *K = qkv + 2048;
    float *V = qkv + 4096;
    
    printf("\nQ[0:5]:");
    for (int i = 0; i < 5; i++) printf(" %.6f", Q[i]);
    printf("\nK[0:5]:");
    for (int i = 0; i < 5; i++) printf(" %.6f", K[i]);
    printf("\nV[0:5]:");
    for (int i = 0; i < 5; i++) printf(" %.6f", V[i]);
    printf("\n");
    
    // Conv1D at position 0
    float conv_state[6144][4] = {0};
    for (int ch = 0; ch < 6144; ch++) {
        conv_state[ch][0] = conv_state[ch][1];
        conv_state[ch][1] = conv_state[ch][2];
        conv_state[ch][2] = conv_state[ch][3];
        conv_state[ch][3] = qkv[ch];
    }
    
    for (int ch = 0; ch < 6144; ch++) {
        float sum = 0;
        for (int k = 0; k < 4; k++) {
            sum += conv_state[ch][k] * gdn_conv[ch * 4 + k];
        }
        qkv[ch] = sum;
    }
    
    printf("\n=== Step 4: After Conv1D ===\n");
    printf("QKV_conv[0:10]:");
    for (int i = 0; i < 10; i++) printf(" %.6f", qkv[i]);
    printf("\n");
    printf("Q_conv[0:5]:");
    for (int i = 0; i < 5; i++) printf(" %.6f", Q[i]);
    printf("\n");
    
    // GDN parameters
    printf("\n=== GDN Parameters ===\n");
    printf("A_log[0:4]:");
    for (int i = 0; i < 4; i++) printf(" %.6f", gdn_A[i]);
    printf("\ndt_bias[0:4]:");
    for (int i = 0; i < 4; i++) printf(" %.6f", gdn_dt[i]);
    printf("\nexp(A_log)[0:4]:");
    for (int i = 0; i < 4; i++) printf(" %.6f", expf(gdn_A[i]));
    printf("\n");
    
    // Compute gamma for first head (assuming a=0)
    printf("\n=== Decay computation (a=0) ===\n");
    for (int h = 0; h < 4; h++) {
        float A = gdn_A[h];
        float dt = gdn_dt[h];
        float a = 0.0f;
        float sp = logf(1.0f + expf(a + dt));
        float g = -expf(A) * sp;
        float gamma = expf(g);
        printf("Head %d: A=%.4f, dt=%.4f, sp=%.4f, g=%.4f, gamma=%.6f\n", 
               h, A, dt, sp, g, gamma);
    }
    
    printf("\n=== Alternative: a - dt_bias ===\n");
    for (int h = 0; h < 4; h++) {
        float A = gdn_A[h];
        float dt = gdn_dt[h];
        float a = 0.0f;
        float sp = logf(1.0f + expf(a - dt));
        float g = -expf(A) * sp;
        float gamma = expf(g);
        printf("Head %d: A=%.4f, dt=%.4f, sp=%.4f, g=%.4f, gamma=%.6f\n", 
               h, A, dt, sp, g, gamma);
    }
    
    safetensors_close(sf);
    free(x1);
    free(qkv);
    return 0;
}