#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Minimal safetensors reader
typedef struct {
    FILE *f;
    long data_offset;
    char *header;
} SafetensorsFile;

float *load_f32(SafetensorsFile *sf, const char *name, int n) {
    // Simple implementation - search header for name
    float *out = malloc(n * sizeof(float));
    // This is a placeholder - actual loading would need the header
    return out;
}

int main() {
    printf("Checking A_log values:\n");
    printf("A_log stores log(A), where A ~ Uniform(0.01, 16)\n");
    printf("So A_log values should be in range [log(0.01), log(16)] = [-4.6, 2.8]\n");
    printf("And exp(A_log) = A, which should be in range [0.01, 16]\n\n");
    
    // Test: if A_log = log(8) = 2.08
    float A_log = 2.08f;
    float A = expf(A_log);
    printf("Example: A_log = %.2f, exp(A_log) = %.4f\n", A_log, A);
    
    // In the current code:
    // g = -exp(A_log) * softplus(a + dt_bias)
    // gamma = exp(g)
    
    // If exp(A_log) = 8, and softplus(...) ≈ 1
    // Then g = -8, gamma = exp(-8) ≈ 0.0003 (very strong decay)
    
    // But if A_log is already the decay parameter (wrong interpretation):
    // g = -exp(A_log) = -exp(2.08) = -8
    // gamma = exp(-8) ≈ 0.0003
    
    printf("\nFor decay, gamma should be close to 1 (weak decay for short sequences)\n");
    printf("If gamma ≈ 0.0003, state decays too fast!\n");
    
    return 0;
}
