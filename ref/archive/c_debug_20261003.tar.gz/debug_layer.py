# Debug script to compare layer outputs with PyTorch reference
import torch
import numpy as np
import json
import struct

# Load model weights from safetensors
def load_safetensors(path):
    with open(path, 'rb') as f:
        header_size = struct.unpack('<Q', f.read(8))[0]
        header = f.read(header_size).decode('utf-8')
        meta = json.loads(header)
        
        tensors = {}
        for name, info in meta.items():
            if name == '__metadata__':
                continue
            start, end = info['data_offsets']
            f.seek(8 + header_size + start)
            data = f.read(end - start)
            
            if info['dtype'] == 'BF16':
                bf16 = np.frombuffer(data, dtype=np.uint16)
                fp32 = (bf16.astype(np.uint32) << 16).view(np.float32)
                arr = fp32.reshape(info['shape'])
            elif info['dtype'] == 'F32':
                arr = np.frombuffer(data, dtype=np.float32).reshape(info['shape'])
            else:
                continue
            tensors[name] = torch.from_numpy(arr.copy())
        return tensors

print("Loading weights...")
weights = load_safetensors('/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors')

# Check some GDN weights
print("\n=== GDN Layer 0 Weights ===")
A_log = weights['model.language_model.layers.0.linear_attn.A_log']
print(f"A_log: {A_log[:4]}")
print(f"A_log exp: {torch.exp(A_log[:4])}")

dt_bias = weights['model.language_model.layers.0.linear_attn.dt_bias']
print(f"dt_bias: {dt_bias[:4]}")

# Check QKV weight statistics
qkv = weights['model.language_model.layers.0.linear_attn.in_proj_qkv.weight']
print(f"\nQKV shape: {qkv.shape}")

# Check if sequential layout is correct by computing norms
q_section = qkv[:2048, :]
k_section = qkv[2048:4096, :]
v_section = qkv[4096:, :]

print(f"Q section norm: {torch.norm(q_section):.4f}")
print(f"K section norm: {torch.norm(k_section):.4f}")
print(f"V section norm: {torch.norm(v_section):.4f}")

# Compare with interleaved interpretation
q_interleaved = []
k_interleaved = []
v_interleaved = []
for h in range(16):
    q_interleaved.append(qkv[h*384:h*384+128, :])
    k_interleaved.append(qkv[h*384+128:h*384+256, :])
    v_interleaved.append(qkv[h*384+256:h*384+384, :])

q_inter = torch.cat(q_interleaved, dim=0)
k_inter = torch.cat(k_interleaved, dim=0)
v_inter = torch.cat(v_interleaved, dim=0)

print(f"\nInterleaved interpretation:")
print(f"Q_inter norm: {torch.norm(q_inter):.4f}")
print(f"K_inter norm: {torch.norm(k_inter):.4f}")
print(f"V_inter norm: {torch.norm(v_inter):.4f}")

# Check if the two interpretations are the same
print(f"\nAre they the same?")
print(f"Q same: {torch.allclose(q_section, q_inter)}")
print(f"K same: {torch.allclose(k_section, k_inter)}")
print(f"V same: {torch.allclose(v_section, v_inter)}")

# Check the embedding table
embed = weights['model.language_model.embed_tokens.weight']
print(f"\n=== Embedding ===")
print(f"Embed shape: {embed.shape}")
print(f"Embedding for token 198 (newline): {embed[198, :8]}")
print(f"Embedding for token 248045 (<|im_start|>): {embed[248045, :8]}")

# Check final norm
norm = weights.get('model.language_model.norm.weight', None)
if norm is None:
    # Try to find it
    for name in weights:
        if 'norm.weight' in name and 'layers' not in name:
            print(f"Found norm: {name}")
            norm = weights[name]
            break
if norm is not None:
    print(f"Final norm shape: {norm.shape}")
    print(f"Final norm first few: {norm[:8]}")
