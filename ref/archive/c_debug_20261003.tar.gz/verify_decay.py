import numpy as np
import json
import struct

def load_tensor(path, name):
    with open(path, 'rb') as f:
        header_size = struct.unpack('<Q', f.read(8))[0]
        header = f.read(header_size).decode('utf-8')
        meta = json.loads(header)
        
        info = meta[name]
        start, end = info['data_offsets']
        f.seek(8 + header_size + start)
        data = f.read(end - start)
        
        if info['dtype'] == 'BF16':
            bf16 = np.frombuffer(data, dtype=np.uint16)
            fp32 = (bf16.astype(np.uint32) << 16).view(np.float32)
            return fp32.reshape(info['shape'])
        elif info['dtype'] == 'F32':
            return np.frombuffer(data, dtype=np.float32).reshape(info['shape'])
        else:
            raise ValueError(f"Unknown dtype: {info['dtype']}")

path = '/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors'

# Load GDN parameters for layer 0
A_log = load_tensor(path, 'model.language_model.layers.0.linear_attn.A_log')
dt_bias = load_tensor(path, 'model.language_model.layers.0.linear_attn.dt_bias')

print("=== GDN Layer 0 Parameters ===")
print(f"A_log dtype: F32, shape: {A_log.shape}")
print(f"A_log: {A_log}")
print(f"dt_bias dtype: BF16, shape: {dt_bias.shape}")
print(f"dt_bias: {dt_bias}")
print()

# Test both formulas
print("=== Formula 1: softplus(a + dt_bias) ===")
a_values = np.array([0.0, 0.5, -0.5, 1.0, -1.0])  # Example a values
for a in a_values:
    gammas = []
    for h in range(16):
        sp = np.log(1 + np.exp(a + dt_bias[h]))
        g = -np.exp(A_log[h]) * sp
        gamma = np.exp(g)
        gammas.append(gamma)
    print(f"a = {a:5.1f}: mean gamma = {np.mean(gammas):.4f}, min = {np.min(gammas):.4f}, max = {np.max(gammas):.4f}")

print()
print("=== Formula 2: softplus(a - dt_bias) ===")
for a in a_values:
    gammas = []
    for h in range(16):
        sp = np.log(1 + np.exp(a - dt_bias[h]))
        g = -np.exp(A_log[h]) * sp
        gamma = np.exp(g)
        gammas.append(gamma)
    print(f"a = {a:5.1f}: mean gamma = {np.mean(gammas):.4f}, min = {np.min(gammas):.4f}, max = {np.max(gammas):.4f}")

print()
print("=== What if dt_bias is the 'delta' directly (not softplused)? ===")
print("Formula 3: gamma = exp(-exp(A_log) * dt_bias)")
for a in a_values:
    gammas = []
    for h in range(16):
        # Use dt_bias directly as the time step
        g = -np.exp(A_log[h]) * dt_bias[h]
        gamma = np.exp(g)
        gammas.append(gamma)
    print(f"mean gamma = {np.mean(gammas):.4f}, min = {np.min(gammas):.4f}, max = {np.max(gammas):.4f}")
