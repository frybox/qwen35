// Debug Q norm loading and application
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>

// Simulate rmsnorm
void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

int main() {
    // Test rmsnorm behavior
    int n = 256;
    float *x = malloc(n * sizeof(float));
    float *w = malloc(n * sizeof(float));
    float *o = malloc(n * sizeof(float));
    
    // Initialize x with some values (simulating Q projection output)
    for (int i = 0; i < n; i++) {
        x[i] = 0.5f;  // All same value for simplicity
    }
    
    // Initialize w with weight values like q_norm
    for (int i = 0; i < n; i++) {
        w[i] = 0.45f;  // Approximate mean of q_norm
    }
    
    // Compute norm before
    float norm_before = 0;
    for (int i = 0; i < n; i++) norm_before += x[i] * x[i];
    printf("Input norm: %.4f\n", sqrtf(norm_before));
    
    // Apply rmsnorm
    rmsnorm(o, x, w, n);
    
    // Compute norm after
    float norm_after = 0;
    for (int i = 0; i < n; i++) norm_after += o[i] * o[i];
    printf("Output norm: %.4f\n", sqrtf(norm_after));
    
    // Check values
    printf("Input first 4: [%.4f, %.4f, %.4f, %.4f]\n", x[0], x[1], x[2], x[3]);
    printf("Output first 4: [%.4f, %.4f, %.4f, %.4f]\n", o[0], o[1], o[2], o[3]);
    
    printf("\nRMSNorm scale factor: %.4f\n", 1.0f / sqrtf(norm_before / n + 1e-6f));
    printf("Expected output norm: %.4f\n", 0.45f * sqrtf(n));  // w * sqrt(n) after normalization
    
    free(x);
    free(w);
    free(o);
    
    return 0;
}
