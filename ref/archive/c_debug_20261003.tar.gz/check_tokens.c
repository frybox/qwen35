#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "safetensors.h"
#include "tokenizer.h"

int main() {
    BPETokenizer tok;
    tokenizer_init(&tok);
    tokenizer_load_vocab(&tok, "/mnt/Qwen3.5-0.8B/vocab.json");
    
    // Check specific tokens
    char buf[256];
    int t1 = 248045;
    tokenizer_decode(&tok, &t1, 1, buf, sizeof(buf));
    printf("Token %d: '%s'\n", t1, buf);
    
    int t2 = 846;
    tokenizer_decode(&tok, &t2, 1, buf, sizeof(buf));
    printf("Token %d: '%s'\n", t2, buf);
    
    int t3 = 74455;
    tokenizer_decode(&tok, &t3, 1, buf, sizeof(buf));
    printf("Token %d: '%s'\n", t3, buf);
    
    int t4 = 198;
    tokenizer_decode(&tok, &t4, 1, buf, sizeof(buf));
    printf("Token %d: '%s'\n", t4, buf);
    
    int t5 = 16;
    tokenizer_decode(&tok, &t5, 1, buf, sizeof(buf));
    printf("Token %d: '%s'\n", t5, buf);
    
    int t6 = 17;
    tokenizer_decode(&tok, &t6, 1, buf, sizeof(buf));
    printf("Token %d: '%s'\n", t6, buf);
    
    tokenizer_free(&tok);
    return 0;
}
