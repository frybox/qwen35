#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) { printf("Failed to open\n"); return 1; }
    
    // Load embedding
    float *embed = malloc(248320 * 1024 * sizeof(float));
    safetensors_load_tensor_as_f32(sf,
        safetensors_get_tensor(sf, "model.language_model.embed_tokens.weight"),
        embed);
    
    // Load final norm
    float *norm_w = malloc(1024 * sizeof(float));
    safetensors_load_tensor_as_f32(sf,
        safetensors_get_tensor(sf, "model.language_model.norm.weight"),
        norm_w);
    
    // Simulate a hidden state (after all layers, before norm)
    float hidden[1024];
    for (int i = 0; i < 1024; i++) hidden[i] = 0.01f * (i % 100 - 50);  // Values around 0
    
    // Apply norm
    float normed[1024];
    rmsnorm(normed, hidden, norm_w, 1024);
    
    // Check norm result
    float norm = 0;
    for (int i = 0; i < 1024; i++) norm += normed[i] * normed[i];
    printf("After norm, L2: %.4f\n", sqrtf(norm));
    printf("normed[0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n",
           normed[0], normed[1], normed[2], normed[3], normed[4]);
    
    // Compute logits for a few tokens
    float logits[5];
    int test_tokens[] = {198, 220, 471, 1, 417};
    for (int t = 0; t < 5; t++) {
        int tid = test_tokens[t];
        float *emb = embed + tid * 1024;
        float dot = 0;
        for (int i = 0; i < 1024; i++) {
            dot += emb[i] * normed[i];
        }
        logits[t] = dot;
        printf("Token %d: logit = %.4f\n", tid, dot);
    }
    
    // Check embedding norms
    printf("\nEmbedding norms:\n");
    for (int t = 0; t < 5; t++) {
        int tid = test_tokens[t];
        float *emb = embed + tid * 1024;
        float norm = 0;
        for (int i = 0; i < 1024; i++) norm += emb[i] * emb[i];
        printf("Token %d: L2 = %.4f\n", tid, sqrtf(norm));
    }
    
    safetensors_close(sf);
    return 0;
}
