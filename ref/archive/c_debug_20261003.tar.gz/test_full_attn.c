// Test: Only full attention layer (layer 3)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float silu(float x) { return x / (1.0f + expf(-x)); }

void softmax(float *x, int n) {
    float max = x[0];
    for (int i = 1; i < n; i++) if (x[i] > max) max = x[i];
    float sum = 0;
    for (int i = 0; i < n; i++) { x[i] = expf(x[i] - max); sum += x[i]; }
    for (int i = 0; i < n; i++) x[i] /= sum;
}

void apply_rope(float *q, float *k, int head_dim, int nq, int nkv, int pos) {
    int rotary_dim = head_dim / 4;
    float theta = 10000000.0f;
    
    for (int h = 0; h < nq; h++) {
        for (int i = 0; i < rotary_dim; i += 2) {
            float freq = 1.0f / powf(theta, (float)(2*i) / rotary_dim);
            float val = pos * freq;
            float cr = cosf(val), ci = sinf(val);
            float v0 = q[h*head_dim + i], v1 = q[h*head_dim + i + 1];
            q[h*head_dim + i] = v0*cr - v1*ci;
            q[h*head_dim + i + 1] = v0*ci + v1*cr;
        }
    }
    for (int h = 0; h < nkv; h++) {
        for (int i = 0; i < rotary_dim; i += 2) {
            float freq = 1.0f / powf(theta, (float)(2*i) / rotary_dim);
            float val = pos * freq;
            float cr = cosf(val), ci = sinf(val);
            float v0 = k[h*head_dim + i], v1 = k[h*head_dim + i + 1];
            k[h*head_dim + i] = v0*cr - v1*ci;
            k[h*head_dim + i + 1] = v0*ci + v1*cr;
        }
    }
}

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    if (!m) { fprintf(stderr, "Tensor not found: %s\n", name); return NULL; }
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

int main() {
    printf("Loading model...\n");
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    float *final_norm = load_tensor(sf, "model.language_model.norm.weight", 1024);
    
    printf("Testing full attention layer (layer 3)...\n");
    
    int head_dim = 256;
    int nheads = 8;
    int nkvheads = 2;
    int kvdim = nkvheads * head_dim;  // 512
    int gqa = nheads / nkvheads;  // 4
    int nctx = 64;  // Smaller context for testing
    
    // KV cache
    float *kcache = calloc(nctx * kvdim, sizeof(float));
    float *vcache = calloc(nctx * kvdim, sizeof(float));
    
    // Load layer 3 weights
    float *ln1 = load_tensor(sf, "model.language_model.layers.3.input_layernorm.weight", 1024);
    float *q_w = load_tensor(sf, "model.language_model.layers.3.self_attn.q_proj.weight", 4096 * 1024);
    float *k_w = load_tensor(sf, "model.language_model.layers.3.self_attn.k_proj.weight", kvdim * 1024);
    float *v_w = load_tensor(sf, "model.language_model.layers.3.self_attn.v_proj.weight", kvdim * 1024);
    float *o_w = load_tensor(sf, "model.language_model.layers.3.self_attn.o_proj.weight", 1024 * 2048);
    float *qn = load_tensor(sf, "model.language_model.layers.3.self_attn.q_norm.weight", head_dim);
    float *kn = load_tensor(sf, "model.language_model.layers.3.self_attn.k_norm.weight", head_dim);
    float *ln2 = load_tensor(sf, "model.language_model.layers.3.post_attention_layernorm.weight", 1024);
    float *gate_w = load_tensor(sf, "model.language_model.layers.3.mlp.gate_proj.weight", 3584 * 1024);
    float *up_w = load_tensor(sf, "model.language_model.layers.3.mlp.up_proj.weight", 3584 * 1024);
    float *down_w = load_tensor(sf, "model.language_model.layers.3.mlp.down_proj.weight", 1024 * 3584);
    
    int tokens[] = {248045, 846, 198};
    int n_tokens = 3;
    
    for (int t = 0; t < n_tokens; t++) {
        int token = tokens[t];
        int pos = t;
        printf("\n=== Token %d (id=%d) at pos %d ===\n", t, token, pos);
        
        float x[1024];
        memcpy(x, embed + token * 1024, sizeof(x));
        
        // Norm
        float x_norm[1024];
        rmsnorm(x_norm, x, ln1, 1024);
        
        // Q projection (includes gate)
        float *q_gate = malloc(4096 * sizeof(float));
        matmul(q_gate, q_w, x_norm, 1024, 4096);
        
        float *q = malloc(2048 * sizeof(float));
        float *gate = malloc(2048 * sizeof(float));
        memcpy(q, q_gate, 2048 * sizeof(float));
        memcpy(gate, q_gate + 2048, 2048 * sizeof(float));
        
        // Q norm
        for (int h = 0; h < nheads; h++) {
            rmsnorm(q + h*head_dim, q + h*head_dim, qn, head_dim);
        }
        
        // K projection
        float *k = malloc(kvdim * sizeof(float));
        matmul(k, k_w, x_norm, 1024, kvdim);
        
        // K norm
        for (int h = 0; h < nkvheads; h++) {
            rmsnorm(k + h*head_dim, k + h*head_dim, kn, head_dim);
        }
        
        // V projection
        float *v = malloc(kvdim * sizeof(float));
        matmul(v, v_w, x_norm, 1024, kvdim);
        
        // RoPE
        apply_rope(q, k, head_dim, nheads, nkvheads, pos);
        
        // Cache KV
        memcpy(kcache + pos*kvdim, k, kvdim * sizeof(float));
        memcpy(vcache + pos*kvdim, v, kvdim * sizeof(float));
        
        // Attention
        float *attn_out = calloc(2048, sizeof(float));
        for (int h = 0; h < nheads; h++) {
            float *att = malloc(nctx * sizeof(float));
            int kvh = h / gqa;
            
            for (int tt = 0; tt <= pos; tt++) {
                float score = 0;
                for (int i = 0; i < head_dim; i++) {
                    score += q[h*head_dim + i] * kcache[tt*kvdim + kvh*head_dim + i];
                }
                att[tt] = score / sqrtf((float)head_dim);
            }
            softmax(att, pos + 1);
            
            for (int tt = 0; tt <= pos; tt++) {
                for (int i = 0; i < head_dim; i++) {
                    attn_out[h*head_dim + i] += att[tt] * vcache[tt*kvdim + kvh*head_dim + i];
                }
            }
            free(att);
        }
        
        // Apply gate
        for (int i = 0; i < 2048; i++) {
            attn_out[i] *= 1.0f / (1.0f + expf(-gate[i]));
        }
        
        // Output projection
        float o[1024];
        matmul(o, o_w, attn_out, 2048, 1024);
        
        // Residual
        for (int i = 0; i < 1024; i++) x[i] += o[i];
        
        // MLP
        float x_mlp[1024];
        rmsnorm(x_mlp, x, ln2, 1024);
        
        float gate_out[3584], up[3584];
        matmul(gate_out, gate_w, x_mlp, 1024, 3584);
        matmul(up, up_w, x_mlp, 1024, 3584);
        
        for (int i = 0; i < 3584; i++) gate_out[i] = silu(gate_out[i]) * up[i];
        
        float mlp_out[1024];
        matmul(mlp_out, down_w, gate_out, 3584, 1024);
        
        for (int i = 0; i < 1024; i++) x[i] += mlp_out[i];
        
        printf("  Output [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
        
        free(q_gate); free(q); free(gate); free(k); free(v); free(attn_out);
    }
    
    printf("\nDone\n");
    safetensors_close(sf);
    free(kcache); free(vcache);
    return 0;
}