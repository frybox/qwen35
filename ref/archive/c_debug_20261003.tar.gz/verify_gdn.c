#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Test GDN state update formula
int main() {
    // Simplified GDN test
    int kd = 128, vd = 128;
    
    // State S[kd, vd], initialized to 0
    float *S = calloc(kd * vd, sizeof(float));
    
    // Input: k, v, q for position 0
    float k[128], v[128], q[128];
    
    // Initialize with random-ish values
    for (int i = 0; i < 128; i++) {
        k[i] = 0.1f * (i % 10);
        v[i] = 0.1f * (i % 7);
        q[i] = 0.1f * (i % 5);
    }
    
    // L2 normalize k and q (as in the code)
    float kn = 0, qn = 0;
    for (int i = 0; i < kd; i++) { kn += k[i]*k[i]; qn += q[i]*q[i]; }
    kn = 1.0f / sqrtf(kn + 1e-6f);
    qn = 1.0f / sqrtf(qn + 1e-6f);
    for (int i = 0; i < kd; i++) { k[i] *= kn; q[i] *= qn; }
    
    // Scale q by 1/sqrt(kd)
    float scale = 1.0f / sqrtf((float)kd);
    for (int i = 0; i < kd; i++) q[i] *= scale;
    
    // At position 0:
    // gamma = exp(-exp(A_log) * softplus(a + dt_bias))
    // For simplicity, assume gamma = 0.5, beta = 0.5
    float gamma = 0.5f;
    float beta = 0.5f;
    
    printf("=== GDN Step 0 ===\n");
    printf("gamma = %.4f, beta = %.4f\n", gamma, beta);
    
    // Decay state (S is already 0, so no effect)
    for (int i = 0; i < kd * vd; i++) S[i] *= gamma;
    
    // kv_mem = S @ k = 0 (since S is 0)
    float kv_mem[128] = {0};
    
    // delta = (v - kv_mem) * beta = v * beta
    float delta[128];
    for (int j = 0; j < vd; j++) delta[j] = (v[j] - kv_mem[j]) * beta;
    
    // S += outer(k, delta)
    for (int i = 0; i < kd; i++) {
        for (int j = 0; j < vd; j++) {
            S[i*vd + j] += k[i] * delta[j];
        }
    }
    
    // out = S @ q
    float out[128] = {0};
    for (int j = 0; j < vd; j++) {
        for (int i = 0; i < kd; i++) {
            out[j] += S[i*vd + j] * q[i];
        }
    }
    
    // Check output
    float out_norm = 0;
    for (int i = 0; i < vd; i++) out_norm += out[i]*out[i];
    printf("Output norm: %.4f\n", sqrtf(out_norm));
    printf("Output[0:4]: [%.4f, %.4f, %.4f, %.4f]\n", out[0], out[1], out[2], out[3]);
    
    // What should the output be?
    // out = S @ q where S = outer(k, v * beta)
    // out = outer(k, v * beta) @ q = (k @ q) * v * beta
    float kq = 0;
    for (int i = 0; i < kd; i++) kq += k[i] * q[i];
    printf("\nExpected output: (k.q) * v * beta\n");
    printf("k.q = %.4f\n", kq);
    printf("Expected out[0] = %.4f * %.4f * %.4f = %.4f\n", kq, v[0], beta, kq * v[0] * beta);
    printf("Actual out[0] = %.4f\n", out[0]);
    
    free(S);
    return 0;
}
