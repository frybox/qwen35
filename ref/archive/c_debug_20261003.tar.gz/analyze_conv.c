/*
 * Analyze Conv1D implementation - check weight layout and causality
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { void *p = calloc(n, 1); if (!p) { fprintf(stderr, "malloc failed\n"); exit(1); } return p; }

float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) return NULL;
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}

int main() {
    const char *path = "/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors";
    SafetensorsFile *sf = safetensors_open(path);
    
    float *embed = load_tensor_f32(sf, "model.language_model.embed_tokens.weight");
    float *ln0 = load_tensor_f32(sf, "model.language_model.layers.0.input_layernorm.weight");
    float *gdn_qkv = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight");
    float *gdn_conv = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.conv1d.weight");
    
    // Token 248045 embedding
    int dim = 1024;
    float *x = embed + 248045 * dim;
    
    // RMSNorm
    float *x1 = xmalloc(dim * sizeof(float));
    float ss = 0;
    for (int i = 0; i < dim; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / dim + 1e-6f);
    for (int i = 0; i < dim; i++) x1[i] = ln0[i] * ss * x[i];
    
    // QKV projection
    float *qkv = xmalloc(6144 * sizeof(float));
    for (int i = 0; i < 6144; i++) {
        float sum = 0;
        for (int j = 0; j < dim; j++) sum += gdn_qkv[i * dim + j] * x1[j];
        qkv[i] = sum;
    }
    
    printf("=== Before Conv1D ===\n");
    printf("QKV[0:5]: %.6f, %.6f, %.6f, %.6f, %.6f\n", qkv[0], qkv[1], qkv[2], qkv[3], qkv[4]);
    printf("QKV norm: %.6f\n", sqrtf(qkv[0]*qkv[0] + qkv[1]*qkv[1] + qkv[2]*qkv[2]));
    
    // Current C implementation (wrong?)
    printf("\n=== Current C implementation (using w[3]) ===\n");
    printf("Conv weight for channel 0: [%.6f, %.6f, %.6f, %.6f]\n",
           gdn_conv[0], gdn_conv[1], gdn_conv[2], gdn_conv[3]);
    float out_wrong = qkv[0] * gdn_conv[3];  // w[3] * qkv
    printf("out[0] = qkv[0] * w[3] = %.6f * %.6f = %.6f\n", qkv[0], gdn_conv[3], out_wrong);
    
    // Correct causal conv implementation
    printf("\n=== Correct causal conv (using w[0]) ===\n");
    printf("For causal conv: out[t] = sum_k(w[k] * x[t-k])\n");
    printf("At t=0 with padding: out[0] = w[0]*x[0] + w[1]*0 + w[2]*0 + w[3]*0 = w[0]*x[0]\n");
    float out_correct = qkv[0] * gdn_conv[0];
    printf("out[0] = qkv[0] * w[0] = %.6f * %.6f = %.6f\n", qkv[0], gdn_conv[0], out_correct);
    
    // Check if w[0] has larger magnitude than w[3]
    printf("\n=== Weight magnitude comparison ===\n");
    float w0_sum = 0, w3_sum = 0;
    for (int ch = 0; ch < 6144; ch++) {
        w0_sum += fabsf(gdn_conv[ch * 4 + 0]);
        w3_sum += fabsf(gdn_conv[ch * 4 + 3]);
    }
    printf("Mean |w[0]|: %.6f\n", w0_sum / 6144);
    printf("Mean |w[3]|: %.6f\n", w3_sum / 6144);
    
    // Check the actual weight distribution
    printf("\n=== Conv weight statistics ===\n");
    float mean[4] = {0}, std[4] = {0};
    for (int k = 0; k < 4; k++) {
        for (int ch = 0; ch < 6144; ch++) {
            mean[k] += gdn_conv[ch * 4 + k];
        }
        mean[k] /= 6144;
        for (int ch = 0; ch < 6144; ch++) {
            float diff = gdn_conv[ch * 4 + k] - mean[k];
            std[k] += diff * diff;
        }
        std[k] = sqrtf(std[k] / 6144);
        printf("w[%d]: mean=%.6f, std=%.6f\n", k, mean[k], std[k]);
    }
    
    // What if the layout is transposed?
    printf("\n=== What if layout is [4, 6144]? ===\n");
    printf("Then conv weight would be stored as w[k][ch]\n");
    printf("w[0][0:5]: %.6f, %.6f, %.6f, %.6f, %.6f\n",
           gdn_conv[0], gdn_conv[1], gdn_conv[2], gdn_conv[3], gdn_conv[4]);
    printf("This is the same as the current layout for the first few elements.\n");
    printf("Let's check at offset 6144:\n");
    printf("gdn_conv[6144:6149]: %.6f, %.6f, %.6f, %.6f, %.6f\n",
           gdn_conv[6144], gdn_conv[6145], gdn_conv[6146], gdn_conv[6147], gdn_conv[6148]);
    
    // Check with transposed interpretation
    // If layout is [4, 6144], then w[0][ch] is at offset 0*6144+ch = ch
    // w[1][ch] is at offset 1*6144+ch = 6144+ch
    // etc.
    // So the current code gdn_conv[ch*4+k] would give w[k][ch/4] + something wrong
    // Let's compute with transposed layout
    printf("\n=== Conv with transposed layout [4, 6144] ===\n");
    float out_transposed = 0;
    // At position 0, state = [0, 0, 0, qkv[0]]
    // out = state[0]*w[0][0] + state[1]*w[1][0] + state[2]*w[2][0] + state[3]*w[3][0]
    // But wait, state values are [0, 0, 0, qkv[0]], so:
    // out = 0*w[0][0] + 0*w[1][0] + 0*w[2][0] + qkv[0]*w[3][0]
    // = qkv[0] * gdn_conv[3*6144 + 0] = qkv[0] * gdn_conv[18432]
    printf("w[3][0] (at offset 18432): %.6f\n", gdn_conv[18432]);
    out_transposed = qkv[0] * gdn_conv[18432];
    printf("out[0] = %.6f\n", out_transposed);
    
    // This still gives wrong weight access. Let's think differently.
    // PyTorch Conv1d with kernel_size=4 and groups=6144:
    // weight shape: [out_channels, in_channels_per_group, kernel_size] = [6144, 1, 4]
    // But stored in safetensors as [6144, 4] after squeezing
    
    // The real question: which weight corresponds to position 0?
    // In causal conv with left padding:
    // out[t] = w[0]*x[t] + w[1]*x[t-1] + w[2]*x[t-2] + w[3]*x[t-3]
    // At t=0: out[0] = w[0]*x[0] (since x[-1], x[-2], x[-3] are 0)
    // So w[0] should be the main weight at position 0
    
    printf("\n=== Testing all 4 weights at position 0 ===\n");
    printf("If we use w[0]: out[0] = %.6f\n", qkv[0] * gdn_conv[0]);
    printf("If we use w[1]: out[0] = %.6f\n", qkv[0] * gdn_conv[1]);
    printf("If we use w[2]: out[0] = %.6f\n", qkv[0] * gdn_conv[2]);
    printf("If we use w[3]: out[0] = %.6f\n", qkv[0] * gdn_conv[3]);
    
    // The problem is that all weights are small!
    // Let's check if there's something wrong with the weight loading
    
    printf("\n=== Full Conv1D simulation ===\n");
    float conv_state[6144][4] = {0};
    float *qkv_after_conv = xmalloc(6144 * sizeof(float));
    
    // Position 0
    for (int ch = 0; ch < 6144; ch++) {
        // Shift state (wrong order?)
        conv_state[ch][0] = conv_state[ch][1];
        conv_state[ch][1] = conv_state[ch][2];
        conv_state[ch][2] = conv_state[ch][3];
        conv_state[ch][3] = qkv[ch];
        
        // Apply conv
        float sum = 0;
        for (int k = 0; k < 4; k++) {
            sum += conv_state[ch][k] * gdn_conv[ch * 4 + k];
        }
        qkv_after_conv[ch] = sum;
    }
    
    printf("After Conv1D at position 0:\n");
    printf("QKV[0:5]: %.6f, %.6f, %.6f, %.6f, %.6f\n",
           qkv_after_conv[0], qkv_after_conv[1], qkv_after_conv[2],
           qkv_after_conv[3], qkv_after_conv[4]);
    
    // This matches the C output! So the implementation is consistent with C code.
    // The question is: is the C code correct?
    
    safetensors_close(sf);
    return 0;
}