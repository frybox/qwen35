#!/usr/bin/env python3
"""Compare embedding and layer 0 norm - minimal version."""
import numpy as np
import struct
import json

def load_tensor_bf16(path, name):
    """Load tensor from safetensors."""
    with open(path, 'rb') as f:
        header_size = struct.unpack('<Q', f.read(8))[0]
        header = f.read(header_size).decode('utf-8')
        meta = json.loads(header)
        
        if name not in meta:
            return None
        
        info = meta[name]
        start, end = info['data_offsets']
        shape = info['shape']
        
        # Calculate total size
        total_elems = 1
        for s in shape:
            total_elems *= s
        
        bytes_per_elem = 2 if info['dtype'] == 'BF16' else 4
        
        data_start = 8 + header_size + start
        f.seek(data_start)
        data = f.read(total_elems * bytes_per_elem)
        
        if info['dtype'] == 'BF16':
            bf16 = np.frombuffer(data, dtype=np.uint16)
            result = (bf16.astype(np.uint32) << 16).view(np.float32)
        else:  # F32
            result = np.frombuffer(data, dtype=np.float32)
        
        return result.reshape(shape)

path = '/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors'
token_id = 248045

print("Loading embedding...")
embed_weight = load_tensor_bf16(path, 'model.language_model.embed_tokens.weight')
embed = embed_weight[token_id]

print("Loading layer0 norm...")
ln0 = load_tensor_bf16(path, 'model.language_model.layers.0.input_layernorm.weight')

# RMSNorm
def rmsnorm(x, w, eps=1e-6):
    rms = np.sqrt(np.mean(x**2) + eps)
    return w * x / rms

x_ln = rmsnorm(embed, ln0)

print("\n" + "="*60)
print("EMBEDDING COMPARISON")
print("="*60)

# C engine values from test_minimal output
c_embed = [0.014282, 0.008789, -0.008179, -0.005615, -0.018188, -0.006195, 0.006104, 0.005005, 0.002838, -0.014038]

print("\nComparison Table:")
print("Index | Python    | C Engine  | Diff     | Match")
print("-" * 55)
for i in range(10):
    diff = abs(embed[i] - c_embed[i])
    match = "✓" if diff < 1e-4 else "✗"
    print(f"{i:5d} | {embed[i]:.6f} | {c_embed[i]:.6f} | {diff:.6f} | {match}")

print("\n" + "="*60)
print("LAYERNORM OUTPUT")  
print("="*60)
print(f"\nPython x_ln (first 10): {x_ln[:10]}")
print(f"Python x_ln norm: {np.linalg.norm(x_ln):.6f}")

print("\n" + "="*60)
print("SUMMARY")
print("="*60)
embed_match = all(abs(embed[i] - c_embed[i]) < 1e-4 for i in range(10))
print(f"Embedding: {'MATCH ✓' if embed_match else 'MISMATCH ✗'}")
print(f"\n第一个差异出现在: embedding加载")
print(f"  - check_embed.c (用于验证) 有双重偏移bug")
print(f"  - test_minimal.c 正确加载，embedding值匹配")