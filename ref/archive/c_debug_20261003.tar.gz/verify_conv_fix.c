// Verify conv1d fix is applied
#include <stdio.h>
#include <math.h>

int main() {
    // Simulate conv state at position 0
    float cw[4] = {-0.000161, 0.000404, -0.003387, -0.074219};
    float cs[4] = {0, 0, 0, -0.089683}; // [oldest, ..., newest]
    
    printf("=== Conv1D verification ===\n");
    printf("State: [0, 0, 0, -0.089683] (newest at index 3)\n");
    printf("Weights: [%.6f, %.6f, %.6f, %.6f]\n\n", cw[0], cw[1], cw[2], cw[3]);
    
    // Method 1: Original (wrong)
    float sum1 = 0;
    for (int k = 0; k < 4; k++) sum1 += cs[k] * cw[k];
    printf("Original: cs[k]*cw[k] = %.6f\n", sum1);
    
    // Method 2: Fixed
    float sum2 = 0;
    for (int k = 0; k < 4; k++) sum2 += cs[k] * cw[3-k];
    printf("Fixed: cs[k]*cw[3-k] = %.6f\n", sum2);
    
    // Method 3: Correct causal conv at t=0
    // At t=0, only x[0] exists, padding on left
    // out[0] = w[0]*x[0]
    float sum3 = cw[0] * cs[3];  // w[0] applies to newest
    printf("Correct: w[0]*x[0] = %.6f\n\n", sum3);
    
    printf("Expected: x[0] should be %.6f (no conv at pos 0)\n", -0.089683);
    
    return 0;
}
