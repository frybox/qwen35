#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "safetensors.h"

int main(int argc, char **argv) {
    const char *filepath = "/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors";
    if (argc > 1) {
        filepath = argv[1];
    }
    
    printf("=== Safetensors Parser Test ===\n\n");
    
    // Open the file
    SafetensorsFile *sf = safetensors_open(filepath);
    if (!sf) {
        fprintf(stderr, "Failed to open safetensors file: %s\n", filepath);
        return 1;
    }
    
    printf("Successfully opened: %s\n", filepath);
    printf("Metadata length: %lu bytes\n", (unsigned long)sf->metadata_len);
    printf("Data start offset: %ld\n", (long)sf->data_start);
    printf("Number of tensors: %d\n\n", sf->num_tensors);
    
    // Print all tensor names and shapes
    printf("--- All Tensors ---\n");
    safetensors_print_info(sf);
    
    // Test loading specific tensors
    printf("\n--- Tensor Loading Tests ---\n");
    
    // Test a known tensor
    const char *test_tensor = "model.language_model.layers.0.linear_attn.A_log";
    TensorMeta *t = safetensors_get_tensor(sf, test_tensor);
    
    if (t) {
        printf("\nFound tensor: %s\n", t->name);
        printf("  Dtype: ");
        switch (t->dtype) {
            case DTYPE_F32: printf("F32\n"); break;
            case DTYPE_F16: printf("F16\n"); break;
            case DTYPE_BF16: printf("BF16\n"); break;
            default: printf("Other\n"); break;
        }
        printf("  Shape: [");
        for (int i = 0; i < t->ndim; i++) {
            printf("%ld%s", (long)t->shape[i], i < t->ndim-1 ? ", " : "");
        }
        printf("]\n");
        printf("  Data offset: %ld\n", (long)t->data_offset);
        printf("  Data size: %ld bytes\n", (long)t->data_size);
        
        // Load the tensor data
        size_t elem_count = 1;
        for (int i = 0; i < t->ndim; i++) {
            elem_count *= t->shape[i];
        }
        
        float *data = malloc(elem_count * sizeof(float));
        if (safetensors_load_tensor_as_f32(sf, t, data) == 0) {
            printf("  Successfully loaded %zu elements\n", elem_count);
            printf("  First 10 values: ");
            for (size_t i = 0; i < 10 && i < elem_count; i++) {
                printf("%.6f ", data[i]);
            }
            printf("\n");
        } else {
            printf("  ERROR: Failed to load tensor data\n");
        }
        free(data);
    } else {
        printf("Tensor '%s' not found\n", test_tensor);
    }
    
    // Test loading a BF16 tensor (usually embedding or weight matrix)
    // Find the first BF16 tensor
    TensorMeta *bf16_tensor = NULL;
    for (int i = 0; i < sf->num_tensors; i++) {
        if (sf->tensors[i].dtype == DTYPE_BF16) {
            bf16_tensor = &sf->tensors[i];
            break;
        }
    }
    
    if (bf16_tensor) {
        printf("\n--- Testing BF16 Tensor ---\n");
        printf("Tensor: %s\n", bf16_tensor->name);
        printf("Shape: [");
        for (int i = 0; i < bf16_tensor->ndim; i++) {
            printf("%ld%s", (long)bf16_tensor->shape[i], i < bf16_tensor->ndim-1 ? ", " : "");
        }
        printf("]\n");
        
        size_t elem_count = 1;
        for (int i = 0; i < bf16_tensor->ndim; i++) {
            elem_count *= bf16_tensor->shape[i];
        }
        
        // Only load first few elements for large tensors
        size_t test_count = elem_count > 10 ? 10 : elem_count;
        float *data = malloc(test_count * sizeof(float));
        
        // Load full tensor then read first few
        float *full_data = malloc(elem_count * sizeof(float));
        if (safetensors_load_tensor_as_f32(sf, bf16_tensor, full_data) == 0) {
            printf("Successfully loaded BF16 tensor (%zu elements)\n", elem_count);
            printf("First %zu values: ", test_count);
            for (size_t i = 0; i < test_count; i++) {
                printf("%.6f ", full_data[i]);
            }
            printf("\n");
        } else {
            printf("ERROR: Failed to load BF16 tensor\n");
        }
        free(data);
        free(full_data);
    }
    
    safetensors_close(sf);
    
    printf("\n=== Test Complete ===\n");
    return 0;
}