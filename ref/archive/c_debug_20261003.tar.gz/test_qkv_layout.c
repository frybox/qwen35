// Test different QKV weight layouts
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Simulate two different QKV layouts and compare with PyTorch reference

int main() {
    // The weight matrix is [6144, 1024]
    // In C, we load it row-major, so W[i,j] = W[i*1024 + j]
    // matmul computes: out[i] = sum_j W[i,j] * x[j]
    
    // This means each row of W produces one element of output
    // If we have 6144 output elements, we need 6144 rows
    
    // Layout 1: Interleaved [Q0,K0,V0, Q1,K1,V1, ...]
    // Row 0-127:   Q for head 0
    // Row 128-255: K for head 0
    // Row 256-383: V for head 0
    // Row 384-511: Q for head 1
    // ...
    
    // Layout 2: Sequential [Q_all, K_all, V_all]
    // Row 0-2047:   Q for all 16 heads (128 per head)
    // Row 2048-4095: K for all 16 heads
    // Row 4096-6143: V for all 16 heads
    
    // To test, we can compare the variance of adjacent 128-blocks
    // vs the variance of the full 2048-blocks
    
    printf("Testing QKV layout hypothesis:\n\n");
    
    // From Python analysis:
    // - Variance is similar across all sections
    // - Row norms vary within each section
    // - The tensor name is "in_proj_qkv" not "in_proj_qkvz"
    //   meaning Z is separate
    
    // According to GDN formula from docs:
    // - We need Q (for query), K (for state update), V (for state update)
    // - Q queries the state, K updates the state
    
    // Let me check the PyTorch source for actual layout...
    // The config shows linear_num_key_heads = linear_num_value_heads = 16
    // and linear_key_head_dim = linear_value_head_dim = 128
    
    // From docs:
    // projection_size_qkvz = key_dim * 2 + value_dim * 2
    // But we have 6144 = 2048 * 2 + 2048? Or 2048 + 2048 + 2048?
    
    // Actually looking at the tensor shape:
    // in_proj_qkv: [6144, 1024] = [16 * 384, 1024]
    // 384 = 128 + 128 + 128 = Q_dim + K_dim + V_dim per head?
    
    // But GDN has separate Q, K, V heads...
    // Let me check: linear_num_key_heads = 16, linear_num_value_heads = 16
    // So both Q and V have 16 heads of 128 dims = 2048
    
    // Hmm, the 384 per head suggests it's:
    // 128 for K (shared between Q and V heads?)
    // 128 for something else
    // 128 for V
    
    // Actually wait - let me re-read the config:
    // linear_num_key_heads = 16
    // linear_num_value_heads = 16
    // linear_key_head_dim = 128
    // linear_value_head_dim = 128
    
    // key_dim = linear_num_key_heads * linear_key_head_dim = 2048
    // value_dim = linear_num_value_heads * linear_value_head_dim = 2048
    
    // If we have QKV as [Q, K, V], that's 2048 * 3 = 6144 ✓
    // If we have QKVK as [K, K2, V], that's 2048 + 2048 + 2048 = 6144 ✓
    
    printf("The actual layout depends on how the model was saved.\n");
    printf("Let me check the HuggingFace model definition...\n");
    
    return 0;
}
