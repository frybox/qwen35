#include <stdio.h>
#include <math.h>

int main() {
    // Values from the debug output:
    // A_log = 0.2578, dt_bias = 2.5469, a = -0.5887
    
    float A_log = 0.2578f;
    float dt_bias = 2.5469f;
    float a = -0.5887f;
    
    printf("=== GDN Decay Analysis ===\n\n");
    printf("Input values:\n");
    printf("  A_log = %.4f\n", A_log);
    printf("  dt_bias = %.4f\n", dt_bias);
    printf("  a (alpha) = %.4f\n", a);
    
    printf("\nFormulas:\n");
    printf("  softplus(x) = log(1 + exp(x))\n");
    printf("  g = -exp(A_log) * softplus(a + dt_bias)\n");
    printf("  gamma = exp(g)\n");
    
    float sp = logf(1.0f + expf(a + dt_bias));
    float g = -expf(A_log) * sp;
    float gamma = expf(g);
    
    printf("\nCalculations:\n");
    printf("  a + dt_bias = %.4f + %.4f = %.4f\n", a, dt_bias, a + dt_bias);
    printf("  softplus(%.4f) = %.4f\n", a + dt_bias, sp);
    printf("  exp(A_log) = %.4f\n", expf(A_log));
    printf("  g = -%.4f * %.4f = %.4f\n", expf(A_log), sp, g);
    printf("  gamma = exp(%.4f) = %.6f\n", g, gamma);
    
    printf("\n=== Problem ===\n");
    printf("gamma = %.6f is very small!\n", gamma);
    printf("This means 93%% of state is forgotten at each step.\n");
    printf("For a sequence of 12 tokens, state would decay to %.6f of original.\n", 
           powf(gamma, 12));
    
    printf("\n=== Alternative interpretation ===\n");
    printf("What if softplus should use a - dt_bias instead of a + dt_bias?\n");
    sp = logf(1.0f + expf(a - dt_bias));
    g = -expf(A_log) * sp;
    gamma = expf(g);
    printf("  a - dt_bias = %.4f\n", a - dt_bias);
    printf("  softplus(%.4f) = %.4f\n", a - dt_bias, sp);
    printf("  gamma = exp(g) = %.6f\n", gamma);
    
    printf("\nWhat if dt_bias has wrong sign?\n");
    // dt_bias might be negative
    dt_bias = -2.5469f;
    sp = logf(1.0f + expf(a + dt_bias));
    g = -expf(A_log) * sp;
    gamma = expf(g);
    printf("  With dt_bias = %.4f\n", dt_bias);
    printf("  a + dt_bias = %.4f\n", a + dt_bias);
    printf("  softplus(%.4f) = %.4f\n", a + dt_bias, sp);
    printf("  gamma = %.6f\n", gamma);
    
    return 0;
}
