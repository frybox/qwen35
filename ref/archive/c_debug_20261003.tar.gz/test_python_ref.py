# Test with transformers library if available
import os
os.environ['TRANSFORMERS_NO_ADVISORY_WARNINGS'] = '1'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'

try:
    import torch
    torch.set_default_device('cpu')
    
    # Check if we can load the model
    from transformers import AutoTokenizer
    
    # Just test the tokenizer
    tokenizer = AutoTokenizer.from_pretrained('/mnt/Qwen3.5-0.8B/', trust_remote_code=True)
    
    # Test prompt
    prompt = "<|im_start|>user\nOnce upon a time<|im_end|>\n<|im_start|>assistant\n"
    tokens = tokenizer.encode(prompt, return_tensors='pt')
    print(f"Prompt tokens: {tokens[0].tolist()}")
    
    # Decode specific tokens
    print(f"Token 198 decoded: '{tokenizer.decode([198])}'")
    print(f"Token 25 decoded: '{tokenizer.decode([25])}'")
    print(f"Token 562 decoded: '{tokenizer.decode([562])}'")
    print(f"Token 522 decoded: '{tokenizer.decode([522])}'")
    
except Exception as e:
    print(f"Error: {e}")
