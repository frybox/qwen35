// Minimal test: just process prompt tokens and check final logits
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float silu(float x) { return x / (1.0f + expf(-x)); }

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

int main() {
    printf("Loading...\n");
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    
    // Load embeddings
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    printf("Embeddings loaded\n");
    
    // Load layer 0 weights
    float *ln1_0 = load_tensor(sf, "model.language_model.layers.0.input_layernorm.weight", 1024);
    float *qkv_0 = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight", 6144 * 1024);
    float *z_0 = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_z.weight", 2048 * 1024);
    float *a_0 = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_a.weight", 16 * 1024);
    float *b_0 = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_b.weight", 16 * 1024);
    float *A_0 = load_tensor(sf, "model.language_model.layers.0.linear_attn.A_log", 16);
    float *dt_0 = load_tensor(sf, "model.language_model.layers.0.linear_attn.dt_bias", 16);
    float *norm_0 = load_tensor(sf, "model.language_model.layers.0.linear_attn.norm.weight", 128);
    float *out_0 = load_tensor(sf, "model.language_model.layers.0.linear_attn.out_proj.weight", 1024 * 2048);
    float *ln2_0 = load_tensor(sf, "model.language_model.layers.0.post_attention_layernorm.weight", 1024);
    float *gate_0 = load_tensor(sf, "model.language_model.layers.0.mlp.gate_proj.weight", 3584 * 1024);
    float *up_0 = load_tensor(sf, "model.language_model.layers.0.mlp.up_proj.weight", 3584 * 1024);
    float *down_0 = load_tensor(sf, "model.language_model.layers.0.mlp.down_proj.weight", 1024 * 3584);
    
    float *final_norm = load_tensor(sf, "model.language_model.norm.weight", 1024);
    
    printf("Layer 0 weights loaded\n");
    
    // Simple test: process tokens 248045, 846, 198, 9707, 1599 (first 5 prompt tokens)
    int tokens[] = {248045, 846, 198, 9707, 1599};
    int n_tokens = 5;
    
    // State for GDN
    float state[16 * 128 * 128] = {0};
    
    float x[1024];
    
    for (int t = 0; t < n_tokens; t++) {
        int tok = tokens[t];
        printf("\n=== Token %d (id=%d) ===\n", t, tok);
        
        // Embedding
        memcpy(x, embed + tok * 1024, sizeof(x));
        printf("Embedding [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
        
        // Layer 0: GDN
        float x_norm[1024];
        rmsnorm(x_norm, x, ln1_0, 1024);
        
        // QKV
        float qkv[6144];
        matmul(qkv, qkv_0, x_norm, 1024, 6144);
        
        // Z
        float z[2048];
        matmul(z, z_0, x_norm, 1024, 2048);
        
        // A, B
        float a[16], b[16];
        matmul(a, a_0, x_norm, 1024, 16);
        matmul(b, b_0, x_norm, 1024, 16);
        
        // Process heads
        float gdn_out[2048];
        for (int h = 0; h < 16; h++) {
            float *q = qkv + h * 128;
            float *k = qkv + 16 * 128 + h * 128;
            float *v = qkv + 32 * 128 + h * 128;
            float *zh = z + h * 128;
            float *sh = state + h * 128 * 128;
            float *out = gdn_out + h * 128;
            
            // L2 norm Q, K
            float qn = 0, kn = 0;
            for (int i = 0; i < 128; i++) { qn += q[i]*q[i]; kn += k[i]*k[i]; }
            qn = 1.0f / sqrtf(qn + 1e-6f);
            kn = 1.0f / sqrtf(kn + 1e-6f);
            for (int i = 0; i < 128; i++) { q[i] *= qn; k[i] *= kn; }
            
            // Scale Q
            float sc = 1.0f / sqrtf(128.0f);
            for (int i = 0; i < 128; i++) q[i] *= sc;
            
            // Decay
            float beta = 1.0f / (1.0f + expf(-b[h]));
            float sp = logf(1.0f + expf(a[h] + dt_0[h]));
            float g = -expf(A_0[h]) * sp;
            float gamma = expf(g);
            
            // Decay state
            for (int i = 0; i < 128 * 128; i++) sh[i] *= gamma;
            
            // kv_mem
            float kv_mem[128] = {0};
            for (int j = 0; j < 128; j++) {
                for (int i = 0; i < 128; i++) kv_mem[j] += sh[i*128 + j] * k[i];
            }
            
            // delta
            float delta[128];
            for (int j = 0; j < 128; j++) delta[j] = (v[j] - kv_mem[j]) * beta;
            
            // Update state
            for (int i = 0; i < 128; i++) {
                for (int j = 0; j < 128; j++) sh[i*128 + j] += k[i] * delta[j];
            }
            
            // Output
            for (int j = 0; j < 128; j++) {
                float sum = 0;
                for (int i = 0; i < 128; i++) sum += sh[i*128 + j] * q[i];
                out[j] = sum;
            }
            
            // Gated norm
            float ss = 0;
            for (int j = 0; j < 128; j++) ss += out[j] * out[j];
            ss = 1.0f / sqrtf(ss / 128 + 1e-6f);
            for (int j = 0; j < 128; j++) out[j] = norm_0[j] * ss * out[j] * silu(zh[j]);
        }
        
        // Out projection
        float attn_out[1024];
        matmul(attn_out, out_0, gdn_out, 2048, 1024);
        
        // Residual
        for (int i = 0; i < 1024; i++) x[i] += attn_out[i];
        
        // MLP
        float x_mlp[1024];
        rmsnorm(x_mlp, x, ln2_0, 1024);
        
        float gate[3584], up[3584];
        matmul(gate, gate_0, x_mlp, 1024, 3584);
        matmul(up, up_0, x_mlp, 1024, 3584);
        
        for (int i = 0; i < 3584; i++) gate[i] = silu(gate[i]) * up[i];
        
        float mlp_out[1024];
        matmul(mlp_out, down_0, gate, 3584, 1024);
        
        for (int i = 0; i < 1024; i++) x[i] += mlp_out[i];
        
        printf("After L0 [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
        
        // State norm for debugging
        float state_norm = 0;
        for (int i = 0; i < 16 * 128 * 128; i++) state_norm += state[i] * state[i];
        printf("State norm: %.4f\n", sqrtf(state_norm));
    }
    
    // Final norm and logits
    float final_x[1024];
    rmsnorm(final_x, x, final_norm, 1024);
    
    printf("\nFinal output [0:4]: %.4f, %.4f, %.4f, %.4f\n", final_x[0], final_x[1], final_x[2], final_x[3]);
    
    // Compute some logits
    printf("\nSample logits:\n");
    int test_tokens[] = {198, 271, 220, 9707, 1599};
    for (int i = 0; i < 5; i++) {
        int t = test_tokens[i];
        float sum = 0;
        for (int j = 0; j < 1024; j++) sum += embed[t * 1024 + j] * final_x[j];
        printf("  Token %d: logit=%.4f\n", t, sum);
    }
    
    safetensors_close(sf);
    return 0;
}