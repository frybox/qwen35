// Test: Only GDN layers (skip full attention)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float silu(float x) { return x / (1.0f + expf(-x)); }

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

int main() {
    printf("Loading model...\n");
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    float *final_norm = load_tensor(sf, "model.language_model.norm.weight", 1024);
    
    printf("Testing only GDN layers (0, 1, 2)...\n");
    
    // State for 3 GDN layers
    float state[3][16 * 128 * 128] = {0};
    float conv_state[3][6144 * 4] = {0};
    
    // Process first 3 tokens through 3 GDN layers
    int tokens[] = {248045, 846, 198, 271};  // Including 271 to see if it changes
    int n_tokens = 4;
    
    float x[1024];
    
    for (int t = 0; t < n_tokens; t++) {
        int token = tokens[t];
        printf("\n=== Token %d (id=%d) ===\n", t, token);
        
        memcpy(x, embed + token * 1024, sizeof(x));
        
        // Process through layers 0, 1, 2 (all GDN)
        for (int layer = 0; layer < 3; layer++) {
            char name[256];
            
            sprintf(name, "model.language_model.layers.%d.input_layernorm.weight", layer);
            float *ln1 = load_tensor(sf, name, 1024);
            
            sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_qkv.weight", layer);
            float *qkv_w = load_tensor(sf, name, 6144 * 1024);
            
            sprintf(name, "model.language_model.layers.%d.linear_attn.conv1d.weight", layer);
            float *conv_w = load_tensor(sf, name, 6144 * 4);
            
            sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_z.weight", layer);
            float *z_w = load_tensor(sf, name, 2048 * 1024);
            
            sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_a.weight", layer);
            float *a_w = load_tensor(sf, name, 16 * 1024);
            
            sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_b.weight", layer);
            float *b_w = load_tensor(sf, name, 16 * 1024);
            
            sprintf(name, "model.language_model.layers.%d.linear_attn.A_log", layer);
            float *A_log = load_tensor(sf, name, 16);
            
            sprintf(name, "model.language_model.layers.%d.linear_attn.dt_bias", layer);
            float *dt = load_tensor(sf, name, 16);
            
            sprintf(name, "model.language_model.layers.%d.linear_attn.norm.weight", layer);
            float *norm_w = load_tensor(sf, name, 128);
            
            sprintf(name, "model.language_model.layers.%d.linear_attn.out_proj.weight", layer);
            float *out_w = load_tensor(sf, name, 1024 * 2048);
            
            sprintf(name, "model.language_model.layers.%d.post_attention_layernorm.weight", layer);
            float *ln2 = load_tensor(sf, name, 1024);
            
            sprintf(name, "model.language_model.layers.%d.mlp.gate_proj.weight", layer);
            float *gate_w = load_tensor(sf, name, 3584 * 1024);
            
            sprintf(name, "model.language_model.layers.%d.mlp.up_proj.weight", layer);
            float *up_w = load_tensor(sf, name, 3584 * 1024);
            
            sprintf(name, "model.language_model.layers.%d.mlp.down_proj.weight", layer);
            float *down_w = load_tensor(sf, name, 1024 * 3584);
            
            // GDN forward
            float x_norm[1024];
            rmsnorm(x_norm, x, ln1, 1024);
            
            float qkv[6144];
            matmul(qkv, qkv_w, x_norm, 1024, 6144);
            
            // Conv1D
            for (int i = 0; i < 6144; i++) {
                float *cs = conv_state[layer] + i * 4;
                float *cw = conv_w + i * 4;
                cs[0] = cs[1]; cs[1] = cs[2]; cs[2] = cs[3]; cs[3] = qkv[i];
                float sum = 0;
                for (int k = 0; k < 4; k++) sum += cs[k] * cw[k];
                qkv[i] = sum;
            }
            
            float z[2048];
            matmul(z, z_w, x_norm, 1024, 2048);
            
            float a[16], b[16];
            matmul(a, a_w, x_norm, 1024, 16);
            matmul(b, b_w, x_norm, 1024, 16);
            
            float gdn_out[2048];
            for (int h = 0; h < 16; h++) {
                float *q = qkv + h * 128;
                float *k = qkv + 16 * 128 + h * 128;
                float *v = qkv + 32 * 128 + h * 128;
                float *zh = z + h * 128;
                float *sh = state[layer] + h * 128 * 128;
                float *out = gdn_out + h * 128;
                
                float qn = 0, kn = 0;
                for (int i = 0; i < 128; i++) { qn += q[i]*q[i]; kn += k[i]*k[i]; }
                qn = 1.0f / sqrtf(qn + 1e-6f);
                kn = 1.0f / sqrtf(kn + 1e-6f);
                for (int i = 0; i < 128; i++) { q[i] *= qn; k[i] *= kn; }
                
                float sc = 1.0f / sqrtf(128.0f);
                for (int i = 0; i < 128; i++) q[i] *= sc;
                
                float beta = 1.0f / (1.0f + expf(-b[h]));
                float sp = logf(1.0f + expf(a[h] + dt[h]));
                float g = -expf(A_log[h]) * sp;
                float gamma = expf(g);
                
                for (int i = 0; i < 128 * 128; i++) sh[i] *= gamma;
                
                float kv_mem[128] = {0};
                for (int j = 0; j < 128; j++) {
                    for (int i = 0; i < 128; i++) kv_mem[j] += sh[i*128 + j] * k[i];
                }
                
                float delta[128];
                for (int j = 0; j < 128; j++) delta[j] = (v[j] - kv_mem[j]) * beta;
                
                for (int i = 0; i < 128; i++) {
                    for (int j = 0; j < 128; j++) sh[i*128 + j] += k[i] * delta[j];
                }
                
                for (int j = 0; j < 128; j++) {
                    float sum = 0;
                    for (int i = 0; i < 128; i++) sum += sh[i*128 + j] * q[i];
                    out[j] = sum;
                }
                
                float ss = 0;
                for (int j = 0; j < 128; j++) ss += out[j] * out[j];
                ss = 1.0f / sqrtf(ss / 128 + 1e-6f);
                for (int j = 0; j < 128; j++) out[j] = norm_w[j] * ss * out[j] * silu(zh[j]);
            }
            
            float attn_out[1024];
            matmul(attn_out, out_w, gdn_out, 2048, 1024);
            for (int i = 0; i < 1024; i++) x[i] += attn_out[i];
            
            // MLP
            float x_mlp[1024];
            rmsnorm(x_mlp, x, ln2, 1024);
            
            float gate[3584], up[3584];
            matmul(gate, gate_w, x_mlp, 1024, 3584);
            matmul(up, up_w, x_mlp, 1024, 3584);
            
            for (int i = 0; i < 3584; i++) gate[i] = silu(gate[i]) * up[i];
            
            float mlp_out[1024];
            matmul(mlp_out, down_w, gate, 3584, 1024);
            
            for (int i = 0; i < 1024; i++) x[i] += mlp_out[i];
            
            free(ln1); free(qkv_w); free(conv_w); free(z_w);
            free(a_w); free(b_w); free(A_log); free(dt);
            free(norm_w); free(out_w); free(ln2);
            free(gate_w); free(up_w); free(down_w);
        }
        
        // Final norm
        float final_x[1024];
        rmsnorm(final_x, x, final_norm, 1024);
        
        printf("  Output [0:4]: %.4f, %.4f, %.4f, %.4f\n", final_x[0], final_x[1], final_x[2], final_x[3]);
        
        // Sample logits
        printf("  Top 5 logits:\n");
        float top_logits[5] = {-1e9};
        int top_ids[5] = {0};
        for (int i = 0; i < 248320; i++) {
            float sum = 0;
            for (int j = 0; j < 1024; j++) sum += embed[i * 1024 + j] * final_x[j];
            for (int j = 0; j < 5; j++) {
                if (sum > top_logits[j]) {
                    for (int k = 4; k > j; k--) {
                        top_logits[k] = top_logits[k-1];
                        top_ids[k] = top_ids[k-1];
                    }
                    top_logits[j] = sum;
                    top_ids[j] = i;
                    break;
                }
            }
        }
        for (int i = 0; i < 5; i++) {
            printf("    token %d: logit=%.4f\n", top_ids[i], top_logits[i]);
        }
    }
    
    printf("\nDone\n");
    safetensors_close(sf);
    return 0;
}