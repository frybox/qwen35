#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { return calloc(n, 1); }

float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) return NULL;
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    float *conv_w = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.conv1d.weight");
    
    // Shape: [6144, 1, 4] => stored as [6144, 4]
    printf("Testing different conv orderings:\n\n");
    
    float x = 0.1;  // input value
    float state[4] = {0, 0, 0, x};  // [oldest, ..., newest]
    
    printf("Input: x=%.4f, state=[0, 0, 0, %.4f]\n\n", x, x);
    
    // Method 1: cw[k] * cs[k] (original)
    printf("Method 1: sum(cw[k] * cs[k])\n");
    printf("  out = 0*%.4f + 0*%.4f + 0*%.4f + %.4f*%.4f = %.6f\n", 
           conv_w[0], conv_w[1], conv_w[2], conv_w[3], x, conv_w[3]*x);
    
    // Method 2: cw[3-k] * cs[k] (my fix)
    printf("\nMethod 2: sum(cw[3-k] * cs[k])\n");
    printf("  out = 0*%.4f + 0*%.4f + 0*%.4f + %.4f*%.4f = %.6f\n",
           conv_w[3], conv_w[2], conv_w[1], conv_w[0], x, conv_w[0]*x);
    
    // Method 3: If layout is [4, 6144]
    printf("\nMethod 3: If layout is [4, 6144], then w[0][ch] at offset 0\n");
    printf("  w[0][0] at offset 0: %.6f\n", conv_w[0]);
    printf("  w[3][0] at offset 3*6144: %.6f\n", conv_w[3*6144]);
    
    // Check PyTorch causal conv
    printf("\nPyTorch causal conv (Conv1D with padding):\n");
    printf("  Padding left side, so at position 0 only w[0] applies\n");
    printf("  out = w[0]*x = %.6f * %.4f = %.6f\n", conv_w[0], x, conv_w[0]*x);
    
    // Actually let me check a few positions
    printf("\n\nConv weights for channel 0 (all 4 positions):\n");
    printf("  cw[0]=%.6f, cw[1]=%.6f, cw[2]=%.6f, cw[3]=%.6f\n",
           conv_w[0], conv_w[1], conv_w[2], conv_w[3]);
    printf("\nConv weights at offset 6144:\n");
    printf("  conv_w[6144+0]=%.6f, conv_w[6144+1]=%.6f, conv_w[6144+2]=%.6f, conv_w[6144+3]=%.6f\n",
           conv_w[6144], conv_w[6145], conv_w[6146], conv_w[6147]);
    
    safetensors_close(sf);
    return 0;
}
