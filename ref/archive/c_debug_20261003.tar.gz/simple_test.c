// Very simple test: just generate a few tokens
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { return calloc(n, 1); }
float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) return NULL;
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    float *embed = load_tensor_f32(sf, "model.language_model.embed_tokens.weight");
    
    int dim = 1024;
    
    // Just compute logits for token 248045 directly
    float *x = embed + 248045 * dim;
    
    // Compute logits: logits[t] = embed[t] @ x
    float max_logit = -1e10;
    int max_token = -1;
    
    for (int t = 0; t < 1000; t++) {  // Only check first 1000 tokens
        float sum = 0;
        for (int i = 0; i < dim; i++) sum += embed[t * dim + i] * x[i];
        if (sum > max_logit) {
            max_logit = sum;
            max_token = t;
        }
    }
    
    printf("From first 1000 tokens: best token is %d with logit %.4f\n", max_token, max_logit);
    
    // Check token 846 ("user")
    float logit_846 = 0;
    for (int i = 0; i < dim; i++) logit_846 += embed[846 * dim + i] * x[i];
    printf("Token 846 (user) logit: %.4f\n", logit_846);
    
    safetensors_close(sf);
    return 0;
}
