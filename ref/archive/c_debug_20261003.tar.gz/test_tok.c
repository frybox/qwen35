#include <stdio.h>
#include <string.h>
#include "tokenizer.h"

int main() {
    BPETokenizer tokenizer;
    if (tokenizer_init(&tokenizer) != 0) {
        printf("Failed to init\n");
        return 1;
    }
    
    const char *vocab_path = "/mnt/Qwen3.5-0.8B/tokenizer.json";
    if (tokenizer_load_vocab(&tokenizer, vocab_path) != 0) {
        printf("Failed to load vocab\n");
        return 1;
    }
    
    printf("Loaded %d tokens\n", tokenizer.n_vocab);
    
    // Test decode
    const char *s = tokenizer_get_token(&tokenizer, 12162);
    printf("Token 12162: %s\n", s ? s : "NULL");
    
    s = tokenizer_get_token(&tokenizer, 5028);
    printf("Token 5028: %s\n", s ? s : "NULL");
    
    s = tokenizer_get_token(&tokenizer, 264);
    printf("Token 264: %s\n", s ? s : "NULL");
    
    s = tokenizer_get_token(&tokenizer, 854);
    printf("Token 854: %s\n", s ? s : "NULL");
    
    s = tokenizer_get_token(&tokenizer, 22961);
    printf("Token 22961: %s\n", s ? s : "NULL");
    
    return 0;
}
