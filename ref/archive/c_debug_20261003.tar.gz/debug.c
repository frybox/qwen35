// Debug script to check values
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) { printf("Failed to open\n"); return 1; }
    
    // Check embed_tokens
    TensorMeta *embed = safetensors_get_tensor(sf, "model.language_model.embed_tokens.weight");
    printf("embed_tokens shape: [");
    for (int i = 0; i < embed->ndim; i++) {
        printf("%ld%s", (long)embed->shape[i], i < embed->ndim-1 ? ", " : "");
    }
    printf("]\n");
    
    // Load first few embedding vectors
    float *data = malloc(10 * 1024 * sizeof(float));
    safetensors_load_tensor_as_f32(sf, embed, data);
    
    printf("\nFirst embedding vector (token 0):\n");
    printf("  [0:4] = %.4f, %.4f, %.4f, %.4f\n", data[0], data[1], data[2], data[3]);
    
    // Check L2 norm of first embedding
    float norm = 0;
    for (int i = 0; i < 1024; i++) norm += data[i] * data[i];
    printf("  L2 norm = %.4f\n", sqrtf(norm));
    
    // Check embedding for token 248045 (im_start)
    float *im_start = data + 248045 * 1024;
    printf("\nEmbedding for token 248045 (im_start):\n");
    printf("  [0:4] = %.4f, %.4f, %.4f, %.4f\n", im_start[0], im_start[1], im_start[2], im_start[3]);
    norm = 0;
    for (int i = 0; i < 1024; i++) norm += im_start[i] * im_start[i];
    printf("  L2 norm = %.4f\n", sqrtf(norm));
    
    safetensors_close(sf);
    return 0;
}
