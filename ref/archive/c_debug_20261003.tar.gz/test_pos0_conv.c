// Test if Conv1D should be skipped at position 0
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { return calloc(n, 1); }
float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) return NULL;
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    float *conv_w = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.conv1d.weight");
    
    // Conv weight shape: [6144, 1, 4] in PyTorch
    // In safetensors, stored as [6144, 4] (squeezed)
    
    printf("=== Conv1D weight analysis ===\n\n");
    
    // Check magnitude of each weight position
    float sum[4] = {0};
    for (int ch = 0; ch < 6144; ch++) {
        for (int k = 0; k < 4; k++) {
            sum[k] += fabsf(conv_w[ch * 4 + k]);
        }
    }
    
    printf("Mean absolute weight for each kernel position:\n");
    for (int k = 0; k < 4; k++) {
        printf("  w[%d]: %.6f\n", k, sum[k] / 6144);
    }
    
    // Check if weights are near-zero or near-identity
    printf("\nSample weights (channel 0):\n");
    printf("  [0]: %.6f, [1]: %.6f, [2]: %.6f, [3]: %.6f\n",
           conv_w[0], conv_w[1], conv_w[2], conv_w[3]);
    
    // Check if w[3] is close to 1.0 (identity)
    float w3_sum = 0;
    for (int ch = 0; ch < 6144; ch++) {
        w3_sum += conv_w[ch * 4 + 3];
    }
    printf("\nMean w[3]: %.6f (if close to 1, it's near-identity)\n", w3_sum / 6144);
    
    // Recommendation
    printf("\n=== Recommendation ===\n");
    if (fabsf(sum[3] / 6144 - 1.0f) < 0.1f) {
        printf("w[3] is close to 1.0 - Conv1D is near identity for position 0\n");
        printf("This means at pos 0: out ≈ w[3] * x[0] ≈ x[0]\n");
        printf("Original code (using w[3]) was actually closer to correct!\n");
    } else {
        printf("Conv weights don't follow identity pattern.\n");
        printf("Need to check PyTorch implementation for correct ordering.\n");
    }
    
    safetensors_close(sf);
    return 0;
}
