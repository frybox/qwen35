#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

int main() {
    // Simple test: check GDN decay factors
    float A_log[16] = {0.2578125f, -2.03125f, -2.125f, -0.56640625f, 
                       -2.609375f, -1.84375f, -2.078125f, -1.0f,
                       -2.0f, -2.25f, -2.125f, -0.5f,
                       -2.5f, -1.5f, -2.0f, -1.0f};
    float dt[16] = {0};  // dt_bias is zeros
    
    printf("GDN decay factors:\n");
    for (int h = 0; h < 16; h++) {
        float A = A_log[h];
        // softplus(x) = log(1 + exp(x))
        // For a=0, sp = log(1 + exp(0)) = log(2) ≈ 0.693
        float sp = logf(1.0f + expf(0 + dt[h]));
        // g = -exp(A_log) * sp
        float g = -expf(A) * sp;
        // gamma = exp(g)
        float gamma = expf(g);
        printf("  Head %d: A_log=%.4f, exp(A)=%.4f, sp=%.4f, g=%.4f, gamma=%.6f\n",
               h, A, expf(A), sp, g, gamma);
        if (gamma < 0 || gamma > 1) {
            printf("    WARNING: gamma out of range [0,1]!\n");
        }
    }
    
    return 0;
}
