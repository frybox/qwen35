#include <stdio.h>

int main() {
    int prompt_ids[] = {248045, 846, 198, 12162, 5028, 264, 854, 248046, 198, 248045, 74455, 198};
    int n_prompt_ids = 12;
    int n_generate = 20;
    
    printf("=== Generation loop trace ===\n\n");
    
    int token = prompt_ids[0];
    printf("Initial: token = %d (prompt_ids[0])\n", token);
    printf("forward(token=%d, pos=0)\n\n", token);
    
    for (int pos = 0; pos < n_generate; pos++) {
        printf("pos=%d:\n", pos);
        
        if (pos > 0) {
            printf("  forward(token=%d, pos=%d)\n", token, pos);
        }
        
        int next;
        if (pos < n_prompt_ids - 1) {
            next = prompt_ids[pos + 1];
            printf("  next = prompt_ids[%d] = %d (prompt)\n", pos+1, next);
        } else {
            printf("  next = sample_argmax(logits)\n");
        }
        
        token = next;
        printf("  token = %d\n\n", token);
    }
    
    return 0;
}
