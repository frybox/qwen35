// Trace generation with detailed state inspection
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

#define NLAYERS 24
#define DIM 1024
#define FFNDIM 3584
#define NHEADS 8
#define NKVHEADS 2
#define HEAD_DIM 256
#define GDN_VHEADS 16
#define GDN_KDIM 128
#define GDN_VDIM 128

int layer_types[24] = {0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1};

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float silu(float x) { return x / (1.0f + expf(-x)); }

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    if (!m) return NULL;
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

void softmax(float *x, int n) {
    float maxv = x[0];
    for (int i = 1; i < n; i++) if (x[i] > maxv) maxv = x[i];
    float sum = 0;
    for (int i = 0; i < n; i++) { x[i] = expf(x[i] - maxv); sum += x[i]; }
    for (int i = 0; i < n; i++) x[i] /= sum;
}

void apply_rope(float *q, float *k, int head_dim, int nq, int nkv, int pos) {
    float theta = 10000000.0f;
    int rotary_dim = head_dim / 4;
    
    for (int h = 0; h < nq; h++) {
        for (int i = 0; i < rotary_dim; i += 2) {
            float freq = 1.0f / powf(theta, (float)(2*i) / rotary_dim);
            float val = pos * freq;
            float cr = cosf(val), ci = sinf(val);
            float v0 = q[h*head_dim + i], v1 = q[h*head_dim + i + 1];
            q[h*head_dim + i] = v0*cr - v1*ci;
            q[h*head_dim + i + 1] = v0*ci + v1*cr;
        }
    }
    for (int h = 0; h < nkv; h++) {
        for (int i = 0; i < rotary_dim; i += 2) {
            float freq = 1.0f / powf(theta, (float)(2*i) / rotary_dim);
            float val = pos * freq;
            float cr = cosf(val), ci = sinf(val);
            float v0 = k[h*head_dim + i], v1 = k[h*head_dim + i + 1];
            k[h*head_dim + i] = v0*cr - v1*ci;
            k[h*head_dim + i + 1] = v0*ci + v1*cr;
        }
    }
}

int main() {
    printf("=== Trace Generation ===\n\n");
    
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) { printf("Failed to open model\n"); return 1; }
    
    // Load all weights (simplified: just load what we need)
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * DIM);
    float *final_norm = load_tensor(sf, "model.language_model.norm.weight", DIM);
    
    // Load layer 0 GDN weights
    float *ln1_0 = load_tensor(sf, "model.language_model.layers.0.input_layernorm.weight", DIM);
    float *gdn_qkv = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight", 6144 * DIM);
    float *gdn_A = load_tensor(sf, "model.language_model.layers.0.linear_attn.A_log", GDN_VHEADS);
    float *gdn_dt = load_tensor(sf, "model.language_model.layers.0.linear_attn.dt_bias", GDN_VHEADS);
    
    printf("GDN A_log values: ");
    for (int h = 0; h < GDN_VHEADS; h++) printf("%.4f ", gdn_A[h]);
    printf("\n");
    
    printf("GDN dt_bias values: ");
    for (int h = 0; h < GDN_VHEADS; h++) printf("%.4f ", gdn_dt[h]);
    printf("\n");
    
    // Check gamma values
    printf("\nGDN gamma values for position 0:\n");
    for (int h = 0; h < GDN_VHEADS; h++) {
        float A = gdn_A[h];
        float dt = gdn_dt[h];
        float a = 0;  // a projection will vary
        float sp = logf(1.0f + expf(a + dt));
        float g = -expf(A) * sp;
        float gamma = expf(g);
        printf("  Head %d: A_log=%.4f, exp(A)=%.4f, sp=%.4f, g=%.4f, gamma=%.6f\n", 
               h, A, expf(A), sp, g, gamma);
    }
    
    // Test single token
    float x[DIM];
    memcpy(x, embed + 248045 * DIM, sizeof(x));
    
    printf("\nToken 248045 embedding [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
    
    float x_norm[DIM];
    rmsnorm(x_norm, x, ln1_0, DIM);
    printf("After norm [0:4]: %.4f, %.4f, %.4f, %.4f\n", x_norm[0], x_norm[1], x_norm[2], x_norm[3]);
    
    float qkv[6144];
    matmul(qkv, gdn_qkv, x_norm, DIM, 6144);
    printf("QKV [0:4]: %.4f, %.4f, %.4f, %.4f\n", qkv[0], qkv[1], qkv[2], qkv[3]);
    
    // Check Q, K norms
    float q_norm = 0, k_norm = 0;
    for (int i = 0; i < GDN_KDIM; i++) {
        q_norm += qkv[i] * qkv[i];
        k_norm += qkv[2048 + i] * qkv[2048 + i];
    }
    printf("Q L2=%.4f, K L2=%.4f\n", sqrtf(q_norm), sqrtf(k_norm));
    
    safetensors_close(sf);
    return 0;
}
