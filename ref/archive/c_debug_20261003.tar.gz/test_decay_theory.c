#include <stdio.h>
#include <math.h>

float softplus(float x) { return logf(1.0f + expf(x)); }

int main() {
    // From the model: A_log values are logs of random values in [0.01, 16]
    // So exp(A_log) = A, which is the "intrinsic timescale"
    
    // The question: what should gamma be for reasonable behavior?
    // - If gamma ≈ 1, state persists (long memory)
    // - If gamma ≈ 0, state resets quickly (short memory)
    
    // For text generation, we want some balance
    // gamma ≈ 0.9-0.99 is typical for long-range dependencies
    // gamma ≈ 0.5-0.9 for medium-range
    
    printf("=== Desired gamma values ===\n");
    printf("For gamma = 0.9: g = log(0.9) = %.4f\n", logf(0.9f));
    printf("For gamma = 0.5: g = log(0.5) = %.4f\n", logf(0.5f));
    printf("For gamma = 0.1: g = log(0.1) = %.4f\n", logf(0.1f));
    
    // Current formula: g = -exp(A_log) * softplus(a + dt_bias)
    // We get g ≈ -2.7 for typical values
    // Which gives gamma ≈ 0.067
    
    // Alternative interpretations:
    printf("\n=== Alternative formulas ===\n");
    
    float A_log = 0.2578f;
    float dt_bias = 2.5469f;
    float a = -0.5887f;
    
    // Formula 1: g = -softplus(A_log + dt_bias + a)
    float g1 = -softplus(A_log + dt_bias + a);
    printf("Formula 1: g = -softplus(A_log + dt_bias + a) = %.4f, gamma = %.4f\n", g1, expf(g1));
    
    // Formula 2: g = -exp(A_log) * (dt_bias + a)
    float g2 = -expf(A_log) * (dt_bias + a);
    printf("Formula 2: g = -exp(A_log) * (dt_bias + a) = %.4f, gamma = %.4f\n", g2, expf(g2));
    
    // Formula 3: g = -dt_bias * exp(A_log + a)
    float g3 = -dt_bias * expf(A_log + a);
    printf("Formula 3: g = -dt_bias * exp(A_log + a) = %.4f, gamma = %.4f\n", g3, expf(g3));
    
    // Formula 4: g = -softplus(A_log) * (1 + dt_bias)
    float g4 = -softplus(A_log) * (1 + dt_bias);
    printf("Formula 4: g = -softplus(A_log) * (1 + dt_bias) = %.4f, gamma = %.4f\n", g4, expf(g4));
    
    // Formula 5: g = -exp(A_log) (ignore dt_bias and a)
    float g5 = -expf(A_log);
    printf("Formula 5: g = -exp(A_log) = %.4f, gamma = %.4f\n", g5, expf(g5));
    
    // What if dt_bias is the timescale and A_log is something else?
    printf("\n=== What if dt_bias is the primary timescale? ===\n");
    printf("dt_bias = %.4f, exp(-dt_bias) = %.4f\n", dt_bias, expf(-dt_bias));
    
    return 0;
}
