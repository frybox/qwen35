// Test single token forward and compare with reference
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

float silu(float x) { return x / (1.0f + expf(-x)); }

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t expected_elems) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) { fprintf(stderr, "Tensor not found: %s\n", name); return NULL; }
    float *buf = malloc(expected_elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, buf);
    return buf;
}

int main() {
    printf("Loading model...\n");
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) { printf("Failed\n"); return 1; }
    
    // Load embed for all tokens
    float *embed = malloc(248320 * 1024 * sizeof(float));
    TensorMeta *emb_meta = safetensors_get_tensor(sf, "model.language_model.embed_tokens.weight");
    safetensors_load_tensor_as_f32(sf, emb_meta, embed);
    printf("Embedding loaded\n");
    
    // Load all weights for layer 0
    float *ln1 = load_tensor(sf, "model.language_model.layers.0.input_layernorm.weight", 1024);
    float *qkv_w = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight", 6144 * 1024);
    float *z_w = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_z.weight", 2048 * 1024);
    float *a_w = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_a.weight", 16 * 1024);
    float *b_w = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_b.weight", 16 * 1024);
    float *A_log = load_tensor(sf, "model.language_model.layers.0.linear_attn.A_log", 16);
    float *dt = load_tensor(sf, "model.language_model.layers.0.linear_attn.dt_bias", 16);
    float *norm_w = load_tensor(sf, "model.language_model.layers.0.linear_attn.norm.weight", 128);
    float *out_w = load_tensor(sf, "model.language_model.layers.0.linear_attn.out_proj.weight", 1024 * 2048);
    float *gate_w = load_tensor(sf, "model.language_model.layers.0.mlp.gate_proj.weight", 3584 * 1024);
    float *up_w = load_tensor(sf, "model.language_model.layers.0.mlp.up_proj.weight", 3584 * 1024);
    float *down_w = load_tensor(sf, "model.language_model.layers.0.mlp.down_proj.weight", 1024 * 3584);
    float *ln2 = load_tensor(sf, "model.language_model.layers.0.post_attention_layernorm.weight", 1024);
    float *final_norm = load_tensor(sf, "model.language_model.norm.weight", 1024);
    
    printf("Weights loaded\n");
    
    // Test forward for token 248045 (im_start)
    float *x = embed + 248045 * 1024;
    printf("\n=== Token 248045 forward ===\n");
    printf("Input x[0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
    
    // Layer 0 forward
    float x_norm[1024];
    rmsnorm(x_norm, x, ln1, 1024);
    printf("After LN1: %.4f, %.4f, %.4f, %.4f\n", x_norm[0], x_norm[1], x_norm[2], x_norm[3]);
    
    // QKV projection
    float qkv[6144];
    matmul(qkv, qkv_w, x_norm, 1024, 6144);
    printf("QKV [0:4]: %.4f, %.4f, %.4f, %.4f\n", qkv[0], qkv[1], qkv[2], qkv[3]);
    
    // Z projection
    float z[2048];
    matmul(z, z_w, x_norm, 1024, 2048);
    
    // A and B projections
    float a[16], b[16];
    matmul(a, a_w, x_norm, 1024, 16);
    matmul(b, b_w, x_norm, 1024, 16);
    
    // Process all heads
    float gdn_out[2048];  // 16 heads * 128 dim
    float state[16 * 128 * 128] = {0};  // Initial state is zeros
    
    for (int h = 0; h < 16; h++) {
        float *q = qkv + h * 128;
        float *k = qkv + 16 * 128 + h * 128;
        float *v = qkv + 32 * 128 + h * 128;
        float *zh = z + h * 128;
        float *sh = state + h * 128 * 128;
        float *out = gdn_out + h * 128;
        
        // L2 normalize Q and K
        float q_n = 0, k_n = 0;
        for (int i = 0; i < 128; i++) { q_n += q[i]*q[i]; k_n += k[i]*k[i]; }
        q_n = 1.0f / sqrtf(q_n + 1e-6f);
        k_n = 1.0f / sqrtf(k_n + 1e-6f);
        for (int i = 0; i < 128; i++) { q[i] *= q_n; k[i] *= k_n; }
        
        // Scale Q
        float scale = 1.0f / sqrtf(128.0f);
        for (int i = 0; i < 128; i++) q[i] *= scale;
        
        // Decay and beta
        float beta = 1.0f / (1.0f + expf(-b[h]));
        float sp = logf(1.0f + expf(a[h] - dt[h]));
        float g = -expf(A_log[h]) * sp;
        float gamma = expf(g);
        
        // Decay state
        for (int i = 0; i < 128 * 128; i++) sh[i] *= gamma;
        
        // kv_mem = state @ k
        float kv_mem[128] = {0};
        for (int j = 0; j < 128; j++) {
            for (int i = 0; i < 128; i++) kv_mem[j] += sh[i*128 + j] * k[i];
        }
        
        // delta = (v - kv_mem) * beta
        float delta[128];
        for (int j = 0; j < 128; j++) delta[j] = (v[j] - kv_mem[j]) * beta;
        
        // state += k @ delta
        for (int i = 0; i < 128; i++) {
            for (int j = 0; j < 128; j++) sh[i*128 + j] += k[i] * delta[j];
        }
        
        // out = state @ q
        for (int j = 0; j < 128; j++) {
            float sum = 0;
            for (int i = 0; i < 128; i++) sum += sh[i*128 + j] * q[i];
            out[j] = sum;
        }
        
        // Gated RMSNorm
        float ss = 0;
        for (int j = 0; j < 128; j++) ss += out[j] * out[j];
        ss = 1.0f / sqrtf(ss / 128 + 1e-6f);
        for (int j = 0; j < 128; j++) out[j] = norm_w[j] * ss * out[j] * silu(zh[j]);
    }
    
    // Output projection
    float attn_out[1024];
    matmul(attn_out, out_w, gdn_out, 2048, 1024);
    printf("Attn output [0:4]: %.4f, %.4f, %.4f, %.4f\n", attn_out[0], attn_out[1], attn_out[2], attn_out[3]);
    
    // Residual
    for (int i = 0; i < 1024; i++) x[i] += attn_out[i];
    printf("After residual [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
    
    // MLP
    float x_mlp[1024];
    rmsnorm(x_mlp, x, ln2, 1024);
    
    float gate[3584], up[3584];
    matmul(gate, gate_w, x_mlp, 1024, 3584);
    matmul(up, up_w, x_mlp, 1024, 3584);
    
    for (int i = 0; i < 3584; i++) gate[i] = silu(gate[i]) * up[i];
    
    float mlp_out[1024];
    matmul(mlp_out, down_w, gate, 3584, 1024);
    
    for (int i = 0; i < 1024; i++) x[i] += mlp_out[i];
    printf("After MLP [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
    
    // Final norm
    float final_x[1024];
    rmsnorm(final_x, x, final_norm, 1024);
    printf("After final norm [0:4]: %.4f, %.4f, %.4f, %.4f\n", final_x[0], final_x[1], final_x[2], final_x[3]);
    
    // Logits (just check a few)
    float logits[5];
    for (int t = 0; t < 5; t++) {
        float sum = 0;
        for (int i = 0; i < 1024; i++) sum += embed[t * 1024 + i] * final_x[i];
        logits[t] = sum;
    }
    printf("Logits [0:4]: %.4f, %.4f, %.4f, %.4f\n", logits[0], logits[1], logits[2], logits[3]);
    
    safetensors_close(sf);
    return 0;
}