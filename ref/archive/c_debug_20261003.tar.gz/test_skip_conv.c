// Test if skipping conv at pos=0 gives better results
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { return calloc(n, 1); }
float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) return NULL;
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}
void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}
float silu(float x) { return x / (1.0f + expf(-x)); }
void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    float *embed = load_tensor_f32(sf, "model.language_model.embed_tokens.weight");
    float *ln0 = load_tensor_f32(sf, "model.language_model.layers.0.input_layernorm.weight");
    float *gdn_qkv = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight");
    float *gdn_z = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_z.weight");
    float *gdn_a = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_a.weight");
    float *gdn_b = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_b.weight");
    float *gdn_A = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.A_log");
    float *gdn_dt = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.dt_bias");
    float *gdn_norm = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.norm.weight");
    float *gdn_out = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.out_proj.weight");
    float *ln2 = load_tensor_f32(sf, "model.language_model.layers.0.post_attention_layernorm.weight");
    float *gate = load_tensor_f32(sf, "model.language_model.layers.0.mlp.gate_proj.weight");
    float *up = load_tensor_f32(sf, "model.language_model.layers.0.mlp.up_proj.weight");
    float *down = load_tensor_f32(sf, "model.language_model.layers.0.mlp.down_proj.weight");
    
    int dim = 1024, nv = 16, kd = 128, vd = 128;
    
    float *x = embed + 248045 * dim;
    float *x1 = xmalloc(dim * sizeof(float));
    rmsnorm(x1, x, ln0, dim);
    
    // QKV projection - NO CONV
    float *qkv = xmalloc(6144 * sizeof(float));
    matmul(qkv, gdn_qkv, x1, dim, 6144);
    
    printf("=== WITHOUT Conv1D ===\n");
    printf("QKV[0:4]: %.4f %.4f %.4f %.4f\n", qkv[0], qkv[1], qkv[2], qkv[3]);
    
    // Continue GDN...
    float *z = xmalloc(nv * vd * sizeof(float));
    matmul(z, gdn_z, x1, dim, nv * vd);
    
    float *ab = xmalloc(2 * nv * sizeof(float));
    matmul(ab, gdn_a, x1, dim, nv);
    matmul(ab + nv, gdn_b, x1, dim, nv);
    for (int i = nv; i < 2*nv; i++) ab[i] = 1.0f / (1.0f + expf(-ab[i]));
    
    float *out_all = xmalloc(nv * vd * sizeof(float));
    for (int h = 0; h < nv; h++) {
        float *q = qkv + h * kd;
        float *k = qkv + nv * kd + h * kd;
        float *v = qkv + 2 * nv * kd + h * kd;
        float *zh = z + h * vd;
        
        float qn = 0, kn = 0;
        for (int i = 0; i < kd; i++) { qn += q[i]*q[i]; kn += k[i]*k[i]; }
        qn = 1.0f / sqrtf(qn + 1e-6f);
        kn = 1.0f / sqrtf(kn + 1e-6f);
        for (int i = 0; i < kd; i++) { q[i] *= qn; k[i] *= kn; }
        for (int i = 0; i < kd; i++) q[i] /= sqrtf(kd);
        
        float a = ab[h], b = ab[nv + h];
        float sp = logf(1.0f + expf(a - gdn_dt[h]));
        float gamma = expf(-expf(gdn_A[h]) * sp);
        
        float state[128*128] = {0};
        for (int i = 0; i < kd * vd; i++) state[i] *= gamma;
        
        float kv_mem[128] = {0};
        for (int j = 0; j < vd; j++) {
            for (int i = 0; i < kd; i++) kv_mem[j] += state[i*vd + j] * k[i];
        }
        
        float delta[128];
        for (int j = 0; j < vd; j++) delta[j] = (v[j] - kv_mem[j]) * b;
        
        for (int i = 0; i < kd; i++) {
            for (int j = 0; j < vd; j++) state[i*vd + j] += k[i] * delta[j];
        }
        
        float *out = out_all + h * vd;
        for (int j = 0; j < vd; j++) {
            for (int i = 0; i < kd; i++) out[j] += state[i*vd + j] * q[i];
        }
        
        float ss = 0;
        for (int j = 0; j < vd; j++) ss += out[j] * out[j];
        ss = 1.0f / sqrtf(ss / vd + 1e-6f);
        for (int j = 0; j < vd; j++) out[j] = gdn_norm[j] * ss * out[j] * silu(zh[j]);
    }
    
    // Output projection
    float *x2 = xmalloc(dim * sizeof(float));
    matmul(x2, gdn_out, out_all, nv * vd, dim);
    
    // Residual
    for (int i = 0; i < dim; i++) x[i] += x2[i];
    
    // MLP
    float *h = xmalloc(3584 * sizeof(float));
    float *h1 = xmalloc(3584 * sizeof(float));
    rmsnorm(x1, x, ln2, dim);
    matmul(h, gate, x1, dim, 3584);
    matmul(h1, up, x1, dim, 3584);
    for (int i = 0; i < 3584; i++) h[i] = silu(h[i]) * h1[i];
    matmul(x1, down, h, 3584, dim);
    for (int i = 0; i < dim; i++) x[i] += x1[i];
    
    printf("After layer 0: x[0:4] = %.4f %.4f %.4f %.4f\n", x[0], x[1], x[2], x[3]);
    
    // Final norm and logits
    float *final_norm = load_tensor_f32(sf, "model.language_model.norm.weight");
    rmsnorm(x, x, final_norm, dim);
    
    float *logits = xmalloc(248320 * sizeof(float));
    matmul(logits, embed, x, dim, 248320);
    
    // Find top-5
    printf("\nTop-5 tokens:\n");
    for (int r = 0; r < 5; r++) {
        int best = 0;
        for (int i = 1; i < 248320; i++) {
            if (logits[i] > logits[best]) best = i;
        }
        printf("  #%d: token %d, logit=%.4f\n", r+1, best, logits[best]);
        logits[best] = -1e10;
    }
    
    safetensors_close(sf);
    return 0;
}
