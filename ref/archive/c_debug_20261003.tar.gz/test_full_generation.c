// End-to-end generation test with debugging
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float silu(float x) { return x / (1.0f + expf(-x)); }

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    if (!m) { printf("Failed to find tensor: %s\n", name); return NULL; }
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

// Print statistics
void print_stats(const char *name, float *arr, int n) {
    float sum = 0, min = arr[0], max = arr[0];
    for (int i = 0; i < n; i++) {
        sum += arr[i];
        if (arr[i] < min) min = arr[i];
        if (arr[i] > max) max = arr[i];
    }
    float mean = sum / n;
    float var = 0;
    for (int i = 0; i < n; i++) var += (arr[i] - mean) * (arr[i] - mean);
    printf("%s: mean=%.6f, std=%.6f, min=%.6f, max=%.6f\n", 
           name, mean, sqrtf(var/n), min, max);
}

int main() {
    printf("=== End-to-End Generation Test ===\n\n");
    
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) { printf("Failed to open model\n"); return 1; }
    
    // Load embeddings
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    float *final_norm = load_tensor(sf, "model.language_model.norm.weight", 1024);
    
    printf("Embeddings loaded\n");
    print_stats("embed[0]", embed, 1024);
    print_stats("embed[248045]", embed + 248045*1024, 1024);
    
    // Load first layer weights
    float *ln1_0 = load_tensor(sf, "model.language_model.layers.0.input_layernorm.weight", 1024);
    printf("\nln1_0: ");
    print_stats("", ln1_0, 1024);
    
    // Process first token
    int token = 248045;
    float x[1024];
    memcpy(x, embed + token * 1024, sizeof(x));
    
    printf("\n=== Token %d ===\n", token);
    print_stats("x (embedding)", x, 1024);
    
    // Apply norm
    float x_norm[1024];
    rmsnorm(x_norm, x, ln1_0, 1024);
    print_stats("x_norm", x_norm, 1024);
    
    // Check: after norm, values should be normalized
    float norm2 = 0;
    for (int i = 0; i < 1024; i++) norm2 += x_norm[i] * x_norm[i];
    printf("x_norm L2: %.4f (expected ~sqrt(1024) = 32)\n", sqrtf(norm2));
    
    // Load and apply GDN layer 0
    float *qkv_w = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight", 6144 * 1024);
    float qkv[6144];
    matmul(qkv, qkv_w, x_norm, 1024, 6144);
    print_stats("qkv", qkv, 6144);
    
    // Check Q, K, V sections
    print_stats("Q section", qkv, 2048);
    print_stats("K section", qkv + 2048, 2048);
    print_stats("V section", qkv + 4096, 2048);
    
    // Process through full model (simplified: just layer 0)
    float *gdn_z = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_z.weight", 2048 * 1024);
    float *gdn_out = load_tensor(sf, "model.language_model.layers.0.linear_attn.out_proj.weight", 1024 * 2048);
    float *gdn_norm = load_tensor(sf, "model.language_model.layers.0.linear_attn.norm.weight", 128);
    float *gdn_A = load_tensor(sf, "model.language_model.layers.0.linear_attn.A_log", 16);
    float *gdn_dt = load_tensor(sf, "model.language_model.layers.0.linear_attn.dt_bias", 16);
    float *gdn_a = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_a.weight", 16 * 1024);
    float *gdn_b = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_b.weight", 16 * 1024);
    float *gdn_conv = load_tensor(sf, "model.language_model.layers.0.linear_attn.conv1d.weight", 6144 * 4);
    
    float z[2048], a[16], b[16];
    matmul(z, gdn_z, x_norm, 1024, 2048);
    matmul(a, gdn_a, x_norm, 1024, 16);
    matmul(b, gdn_b, x_norm, 1024, 16);
    
    print_stats("z", z, 2048);
    print_stats("a", a, 16);
    print_stats("b", b, 16);
    
    // GDN processing for each head
    float state[16][128*128] = {0};
    float gdn_output[2048];
    
    for (int h = 0; h < 16; h++) {
        float *q = qkv + h * 128;
        float *k = qkv + 2048 + h * 128;
        float *v = qkv + 4096 + h * 128;
        float *zh = z + h * 128;
        float *sh = state[h];
        float *out = gdn_output + h * 128;
        
        // L2 norm Q, K
        float qn = 0, kn = 0;
        for (int i = 0; i < 128; i++) { qn += q[i]*q[i]; kn += k[i]*k[i]; }
        qn = 1.0f / sqrtf(qn + 1e-6f);
        kn = 1.0f / sqrtf(kn + 1e-6f);
        for (int i = 0; i < 128; i++) { q[i] *= qn; k[i] *= kn; }
        
        // Scale Q
        float sc = 1.0f / sqrtf(128.0f);
        for (int i = 0; i < 128; i++) q[i] *= sc;
        
        // Decay and beta
        float beta = 1.0f / (1.0f + expf(-b[h]));
        float sp = logf(1.0f + expf(a[h] + gdn_dt[h]));
        float g = -expf(gdn_A[h]) * sp;
        float gamma = expf(g);
        
        if (h == 0) {
            printf("\nGDN Head 0: A_log=%.4f, a=%.4f, b=%.4f, beta=%.4f, gamma=%.6f\n",
                   gdn_A[h], a[h], b[h], beta, gamma);
        }
        
        // Update state
        for (int i = 0; i < 128; i++) {
            for (int j = 0; j < 128; j++) sh[i*128 + j] += k[i] * v[j] * beta;
        }
        
        // Output
        for (int j = 0; j < 128; j++) {
            float sum = 0;
            for (int i = 0; i < 128; i++) sum += sh[i*128 + j] * q[i];
            out[j] = sum;
        }
        
        // Gated norm
        float ss = 0;
        for (int j = 0; j < 128; j++) ss += out[j] * out[j];
        ss = 1.0f / sqrtf(ss / 128 + 1e-6f);
        for (int j = 0; j < 128; j++) out[j] = gdn_norm[j] * ss * out[j] * silu(zh[j]);
    }
    
    print_stats("gdn_output", gdn_output, 2048);
    
    // Out projection
    float attn_out[1024];
    matmul(attn_out, gdn_out, gdn_output, 2048, 1024);
    print_stats("attn_out", attn_out, 1024);
    
    // Residual
    for (int i = 0; i < 1024; i++) x[i] += attn_out[i];
    print_stats("x after GDN", x, 1024);
    
    // Check logits after just layer 0
    printf("\n=== Logits after layer 0 (before MLP) ===\n");
    float x_final[1024];
    rmsnorm(x_final, x, final_norm, 1024);
    print_stats("x_final", x_final, 1024);
    
    // Compute top logits
    float top_vals[10] = {-1e9};
    int top_ids[10] = {0};
    
    for (int i = 0; i < 248320; i++) {
        float dot = 0;
        for (int j = 0; j < 1024; j++) dot += embed[i * 1024 + j] * x_final[j];
        
        for (int k = 0; k < 10; k++) {
            if (dot > top_vals[k]) {
                for (int m = 9; m > k; m--) {
                    top_vals[m] = top_vals[m-1];
                    top_ids[m] = top_ids[m-1];
                }
                top_vals[k] = dot;
                top_ids[k] = i;
                break;
            }
        }
    }
    
    printf("Top 10 logits:\n");
    for (int i = 0; i < 10; i++) {
        printf("  token %d: logit=%.4f\n", top_ids[i], top_vals[i]);
    }
    
    safetensors_close(sf);
    return 0;
}
