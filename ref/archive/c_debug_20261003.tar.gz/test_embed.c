#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) { printf("Failed to open\n"); return 1; }
    
    // Load embed_tokens
    float *embed = malloc(248320 * 1024 * sizeof(float));
    int n = safetensors_load_tensor_as_f32(sf, 
        safetensors_get_tensor(sf, "model.language_model.embed_tokens.weight"),
        embed);
    printf("Loaded %d embedding values\n", n);
    
    // Check a few embeddings
    printf("\nEmbedding for token 0:\n");
    float *e0 = embed;
    printf("  [0:4] = %.4f, %.4f, %.4f, %.4f\n", e0[0], e0[1], e0[2], e0[3]);
    
    printf("\nEmbedding for token 846 (user):\n");
    float *e846 = embed + 846 * 1024;
    printf("  [0:4] = %.4f, %.4f, %.4f, %.4f\n", e846[0], e846[1], e846[2], e846[3]);
    
    printf("\nEmbedding for token 248045 (im_start):\n");
    float *e248045 = embed + 248045 * 1024;
    printf("  [0:4] = %.4f, %.4f, %.4f, %.4f\n", e248045[0], e248045[1], e248045[2], e248045[3]);
    
    // Check L2 norms
    float norm0 = 0, norm846 = 0, norm248045 = 0;
    for (int i = 0; i < 1024; i++) {
        norm0 += e0[i]*e0[i];
        norm846 += e846[i]*e846[i];
        norm248045 += e248045[i]*e248045[i];
    }
    printf("\nL2 norms: 0=%.4f, 846=%.4f, 248045=%.4f\n", 
           sqrtf(norm0), sqrtf(norm846), sqrtf(norm248045));
    
    safetensors_close(sf);
    return 0;
}
