#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tokenizer.h"

int main() {
    BPETokenizer tok;
    tokenizer_init(&tok);
    tokenizer_load_vocab(&tok, "/mnt/Qwen3.5-0.8B/tokenizer.json");
    
    // Decode generated tokens
    int tokens[] = {12, 164275, 155837, 141347, 59802, 55156, 156538, 98193, 87971};
    int n = sizeof(tokens)/sizeof(tokens[0]);
    
    printf("Generated text: ");
    for (int i = 0; i < n; i++) {
        printf("[tok %d]", tokens[i]);
    }
    printf("\n\n");
    
    // Check specific tokens
    printf("Token 12 meaning: ");
    const char *s12 = tokenizer_get_token(&tok, 12);
    printf("%s\n", s12 ? s12 : "(null)");
    
    tokenizer_free(&tok);
    return 0;
}
