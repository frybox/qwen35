#include <stdio.h>
#include <math.h>

float softplus(float x) {
    return logf(1.0f + expf(x));
}

int main() {
    // From model weights
    float A_log = 0.2578f;
    float dt_bias = 2.5469f;
    float a = -0.5887f;  // alpha from projection
    
    printf("=== Decay Calculation ===\n\n");
    
    // Current implementation
    float sp1 = softplus(a + dt_bias);
    float g1 = -expf(A_log) * sp1;
    float gamma1 = expf(g1);
    printf("Current: softplus(a + dt_bias)\n");
    printf("  softplus(%.4f + %.4f) = %.4f\n", a, dt_bias, sp1);
    printf("  g = -exp(A_log) * sp = -%.4f * %.4f = %.4f\n", expf(A_log), sp1, g1);
    printf("  gamma = exp(g) = %.6f\n\n", gamma1);
    
    // Alternative: softplus(a - dt_bias)
    float sp2 = softplus(a - dt_bias);
    float g2 = -expf(A_log) * sp2;
    float gamma2 = expf(g2);
    printf("Alternative 1: softplus(a - dt_bias)\n");
    printf("  softplus(%.4f - %.4f) = %.4f\n", a, dt_bias, sp2);
    printf("  g = -exp(A_log) * sp = -%.4f * %.4f = %.4f\n", expf(A_log), sp2, g2);
    printf("  gamma = exp(g) = %.6f\n\n", gamma2);
    
    // Check dt_bias values across heads
    printf("dt_bias values across heads (from model):\n");
    float dt_values[] = {2.5469, -5.5938, -4.625, 8.375, 3.6406, -5.0312, -5.0625, -1.0781,
                         -13.0625, -5.4375, -4.8125, 6.4375, -4.9375, 7.5938, -6.0625, -3.2344};
    float A_log_values[] = {0.2578, -2.0312, -2.125, -0.5664, -2.6094, -2.25, -1.8047, -2.9844,
                           -6.5938, -0.6602, -1.7812, -0.9141, -1.6484, -1.4531, -1.8984, -2.6094};
    
    printf("Using a=0 (neutral input):\n");
    for (int i = 0; i < 16; i++) {
        float sp = softplus(0 + dt_values[i]);
        float g = -expf(A_log_values[i]) * sp;
        float gamma = expf(g);
        printf("  Head %2d: A_log=%6.2f, dt=%6.2f, gamma=%.6f\n", 
               i, A_log_values[i], dt_values[i], gamma);
    }
    
    return 0;
}
