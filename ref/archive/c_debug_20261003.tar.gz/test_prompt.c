// Test with different prompts
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    if (!m) return NULL;
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

void softmax(float *x, int n) {
    float maxv = x[0];
    for (int i = 1; i < n; i++) if (x[i] > maxv) maxv = x[i];
    float sum = 0;
    for (int i = 0; i < n; i++) { x[i] = expf(x[i] - maxv); sum += x[i]; }
    for (int i = 0; i < n; i++) x[i] /= sum;
}

float silu(float x) { return x / (1.0f + expf(-x)); }

int main() {
    printf("=== Test Different Prompts ===\n\n");
    
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    float *final_norm = load_tensor(sf, "model.language_model.norm.weight", 1024);
    
    // Load layer 0 weights for simple test
    float *ln1_0 = load_tensor(sf, "model.language_model.layers.0.input_layernorm.weight", 1024);
    float *gdn_qkv = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight", 6144 * 1024);
    
    // Test: just embedding -> logits (no layers)
    printf("Direct embedding -> logits (no layers):\n");
    int test_tokens[] = {248045, 846, 198, 16};  // <|im_start|>, user, \n, 1
    for (int i = 0; i < 4; i++) {
        int tok = test_tokens[i];
        float *emb = embed + tok * 1024;
        
        // Top 3 similar embeddings
        float top_vals[3] = {-1e9};
        int top_ids[3] = {0};
        for (int j = 0; j < 248320; j++) {
            float dot = 0;
            for (int k = 0; k < 1024; k++) dot += embed[j * 1024 + k] * emb[k];
            for (int m = 0; m < 3; m++) {
                if (dot > top_vals[m]) {
                    for (int n = 2; n > m; n--) { top_vals[n] = top_vals[n-1]; top_ids[n] = top_ids[n-1]; }
                    top_vals[m] = dot; top_ids[m] = j;
                    break;
                }
            }
        }
        printf("  Token %d: top similar = %d (%.2f), %d (%.2f), %d (%.2f)\n", 
               tok, top_ids[0], top_vals[0], top_ids[1], top_vals[1], top_ids[2], top_vals[2]);
    }
    
    // Test: what does the model think after seeing "1" token?
    printf("\nTest: token 16 (\"1\") after norm:\n");
    float x[1024];
    memcpy(x, embed + 16 * 1024, sizeof(x));
    rmsnorm(x, x, final_norm, 1024);
    
    float top_vals[5] = {-1e9};
    int top_ids[5] = {0};
    for (int j = 0; j < 248320; j++) {
        float dot = 0;
        for (int k = 0; k < 1024; k++) dot += embed[j * 1024 + k] * x[k];
        for (int m = 0; m < 5; m++) {
            if (dot > top_vals[m]) {
                for (int n = 4; n > m; n--) { top_vals[n] = top_vals[n-1]; top_ids[n] = top_ids[n-1]; }
                top_vals[m] = dot; top_ids[m] = j;
                break;
            }
        }
    }
    printf("  Top 5: ");
    for (int i = 0; i < 5; i++) printf("%d(%.2f) ", top_ids[i], top_vals[i]);
    printf("\n");
    
    safetensors_close(sf);
    return 0;
}
