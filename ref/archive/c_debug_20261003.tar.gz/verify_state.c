// Verify state accumulation by comparing step-by-step
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

#define NLAYERS 24
#define DIM 1024
#define FFNDIM 3584
#define GDN_VHEADS 16
#define GDN_KDIM 128

int layer_types[24] = {0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1};

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float silu(float x) { return x / (1.0f + expf(-x)); }

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    if (!m) return NULL;
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

int main() {
    printf("=== Verify State Accumulation ===\n\n");
    
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    
    // Load all weights for layers 0-3
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * DIM);
    float *final_norm = load_tensor(sf, "model.language_model.norm.weight", DIM);
    
    float *ln1[NLAYERS], *ln2[NLAYERS], *gate_w[NLAYERS], *up_w[NLAYERS], *down_w[NLAYERS];
    float *gdn_qkv[NLAYERS], *gdn_z[NLAYERS], *gdn_a[NLAYERS], *gdn_b[NLAYERS];
    float *gdn_A[NLAYERS], *gdn_dt[NLAYERS], *gdn_norm[NLAYERS], *gdn_out_w[NLAYERS], *gdn_conv[NLAYERS];
    
    char name[256];
    for (int l = 0; l < NLAYERS; l++) {
        sprintf(name, "model.language_model.layers.%d.input_layernorm.weight", l);
        ln1[l] = load_tensor(sf, name, DIM);
        sprintf(name, "model.language_model.layers.%d.post_attention_layernorm.weight", l);
        ln2[l] = load_tensor(sf, name, DIM);
        sprintf(name, "model.language_model.layers.%d.mlp.gate_proj.weight", l);
        gate_w[l] = load_tensor(sf, name, FFNDIM * DIM);
        sprintf(name, "model.language_model.layers.%d.mlp.up_proj.weight", l);
        up_w[l] = load_tensor(sf, name, FFNDIM * DIM);
        sprintf(name, "model.language_model.layers.%d.mlp.down_proj.weight", l);
        down_w[l] = load_tensor(sf, name, DIM * FFNDIM);
        
        if (layer_types[l] == 0) {
            sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_qkv.weight", l);
            gdn_qkv[l] = load_tensor(sf, name, 6144 * DIM);
            sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_z.weight", l);
            gdn_z[l] = load_tensor(sf, name, 2048 * DIM);
            sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_a.weight", l);
            gdn_a[l] = load_tensor(sf, name, 16 * DIM);
            sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_b.weight", l);
            gdn_b[l] = load_tensor(sf, name, 16 * DIM);
            sprintf(name, "model.language_model.layers.%d.linear_attn.A_log", l);
            gdn_A[l] = load_tensor(sf, name, 16);
            sprintf(name, "model.language_model.layers.%d.linear_attn.dt_bias", l);
            gdn_dt[l] = load_tensor(sf, name, 16);
            sprintf(name, "model.language_model.layers.%d.linear_attn.norm.weight", l);
            gdn_norm[l] = load_tensor(sf, name, 128);
            sprintf(name, "model.language_model.layers.%d.linear_attn.out_proj.weight", l);
            gdn_out_w[l] = load_tensor(sf, name, DIM * 2048);
            sprintf(name, "model.language_model.layers.%d.linear_attn.conv1d.weight", l);
            gdn_conv[l] = load_tensor(sf, name, 6144 * 4);
        }
    }
    
    printf("Weights loaded\n\n");
    
    // State buffers - allocated on heap
    float (*gdn_state)[16][128*128] = calloc(NLAYERS, 16 * 128 * 128 * sizeof(float));
    float (*conv_state)[6144*4] = calloc(NLAYERS, 6144 * 4 * sizeof(float));
    
    float x[DIM], x_norm[DIM], qkv[6144], z[2048], a[16], b[16];
    float gdn_out_buf[2048], attn_out[DIM];
    float mlp_gate[FFNDIM], mlp_up[FFNDIM], mlp_down[DIM];
    
    // Process first few tokens
    int tokens[] = {248045, 846, 198, 58, 1319, 34233, 248046, 198, 248045, 74455, 198};
    int n_tokens = 11;
    
    for (int pos = 0; pos < n_tokens; pos++) {
        int tok = tokens[pos];
        memcpy(x, embed + tok * DIM, sizeof(x));
        
        if (pos < 3 || pos >= n_tokens - 2) {
            printf("=== Pos %d, Token %d ===\n", pos, tok);
            printf("Embedding [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
        }
        
        // Forward through layers
        for (int l = 0; l < 4; l++) {  // Only first 4 layers for speed
            rmsnorm(x_norm, x, ln1[l], DIM);
            
            if (layer_types[l] == 0) {
                // GDN layer
                matmul(qkv, gdn_qkv[l], x_norm, DIM, 6144);
                
                // Conv1D
                for (int i = 0; i < 6144; i++) {
                    float *cs = conv_state[l] + i * 4;
                    float *cw = gdn_conv[l] + i * 4;
                    cs[0] = cs[1]; cs[1] = cs[2]; cs[2] = cs[3]; cs[3] = qkv[i];
                    float sum = 0;
                    for (int k = 0; k < 4; k++) sum += cs[k] * cw[k];
                    qkv[i] = sum;
                }
                
                matmul(z, gdn_z[l], x_norm, DIM, 2048);
                matmul(a, gdn_a[l], x_norm, DIM, 16);
                matmul(b, gdn_b[l], x_norm, DIM, 16);
                
                for (int h = 0; h < 16; h++) {
                    float *q = qkv + h * 128;
                    float *k = qkv + 2048 + h * 128;
                    float *v = qkv + 4096 + h * 128;
                    float *zh = z + h * 128;
                    float *sh = gdn_state[l][h];
                    float *out = gdn_out_buf + h * 128;
                    
                    float qn = 0, kn = 0;
                    for (int i = 0; i < 128; i++) { qn += q[i]*q[i]; kn += k[i]*k[i]; }
                    qn = 1.0f / sqrtf(qn + 1e-6f);
                    kn = 1.0f / sqrtf(kn + 1e-6f);
                    for (int i = 0; i < 128; i++) { q[i] *= qn; k[i] *= kn; }
                    for (int i = 0; i < 128; i++) q[i] /= sqrtf(128.0f);
                    
                    float beta = 1.0f / (1.0f + expf(-b[h]));
                    float sp = logf(1.0f + expf(a[h] + gdn_dt[l][h]));
                    float g = -expf(gdn_A[l][h]) * sp;
                    float gamma = expf(g);
                    
                    for (int i = 0; i < 128 * 128; i++) sh[i] *= gamma;
                    
                    float kv_mem[128] = {0};
                    for (int j = 0; j < 128; j++)
                        for (int i = 0; i < 128; i++) kv_mem[j] += sh[i*128 + j] * k[i];
                    
                    float delta[128];
                    for (int j = 0; j < 128; j++) delta[j] = (v[j] - kv_mem[j]) * beta;
                    
                    for (int i = 0; i < 128; i++)
                        for (int j = 0; j < 128; j++) sh[i*128 + j] += k[i] * delta[j];
                    
                    for (int j = 0; j < 128; j++) {
                        float sum = 0;
                        for (int i = 0; i < 128; i++) sum += sh[i*128 + j] * q[i];
                        out[j] = sum;
                    }
                    
                    float ss = 0;
                    for (int j = 0; j < 128; j++) ss += out[j] * out[j];
                    ss = 1.0f / sqrtf(ss / 128 + 1e-6f);
                    for (int j = 0; j < 128; j++) out[j] = gdn_norm[l][j] * ss * out[j] * silu(zh[j]);
                }
                
                matmul(attn_out, gdn_out_w[l], gdn_out_buf, 2048, DIM);
                
            } else {
                // Full attention - skip for this test
                memset(attn_out, 0, sizeof(attn_out));
            }
            
            // Residual
            for (int i = 0; i < DIM; i++) x[i] += attn_out[i];
            
            // MLP
            rmsnorm(x_norm, x, ln2[l], DIM);
            matmul(mlp_gate, gate_w[l], x_norm, DIM, FFNDIM);
            matmul(mlp_up, up_w[l], x_norm, DIM, FFNDIM);
            for (int i = 0; i < FFNDIM; i++) mlp_gate[i] = silu(mlp_gate[i]) * mlp_up[i];
            matmul(mlp_down, down_w[l], mlp_gate, FFNDIM, DIM);
            for (int i = 0; i < DIM; i++) x[i] += mlp_down[i];
            
            if (pos < 3 && l < 2) {
                printf("  Layer %d: x[0:4] = %.4f, %.4f, %.4f, %.4f\n", l, x[0], x[1], x[2], x[3]);
            }
        }
    }
    
    // Final norm and logits
    rmsnorm(x, x, final_norm, DIM);
    printf("\nFinal output [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
    
    // Top logits
    float top_vals[5] = {-1e9};
    int top_ids[5] = {0};
    for (int i = 0; i < 248320; i++) {
        float dot = 0;
        for (int j = 0; j < DIM; j++) dot += embed[i * DIM + j] * x[j];
        for (int k = 0; k < 5; k++) {
            if (dot > top_vals[k]) {
                for (int m = 4; m > k; m--) { top_vals[m] = top_vals[m-1]; top_ids[m] = top_ids[m-1]; }
                top_vals[k] = dot; top_ids[k] = i;
                break;
            }
        }
    }
    
    printf("\nTop 5 tokens:\n");
    for (int i = 0; i < 5; i++) printf("  token %d: logit=%.4f\n", top_ids[i], top_vals[i]);
    
    safetensors_close(sf);
    return 0;
}
