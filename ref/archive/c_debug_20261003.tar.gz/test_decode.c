#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tokenizer.h"

int main() {
    Tokenizer tok;
    if (tokenizer_init(&tok, "/mnt/Qwen3.5-0.8B/tokenizer.json") != 0) {
        fprintf(stderr, "Failed to load tokenizer\n");
        return 1;
    }
    
    // Test decode some tokens
    int tokens[] = {199040, 75579, 90336, 159570, 248045, 1, 2, 3, 100, 1000};
    for (int i = 0; i < sizeof(tokens)/sizeof(int); i++) {
        const char *s = tokenizer_decode(&tok, tokens[i]);
        printf("Token %d: \"%s\"\n", tokens[i], s ? s : "(null)");
    }
    
    return 0;
}
