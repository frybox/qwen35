// Test single GDN layer forward
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

float *load_tensor_f32_local(SafetensorsFile *sf, const char *name, int64_t expected_elems) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) { fprintf(stderr, "Tensor not found: %s\n", name); return NULL; }
    float *buf = malloc(expected_elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, buf);
    return buf;
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

float silu(float x) { return x / (1.0f + expf(-x)); }

int main() {
    printf("Loading model...\n");
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) { printf("Failed\n"); return 1; }
    
    // Load embed for token 248045
    float *embed = malloc(248320 * 1024 * sizeof(float));
    TensorMeta *emb_meta = safetensors_get_tensor(sf, "model.language_model.embed_tokens.weight");
    safetensors_load_tensor_as_f32(sf, emb_meta, embed);
    printf("Embedding loaded\n");
    
    // Get input x = embedding for token 248045
    float *x = embed + 248045 * 1024;
    printf("Input x[0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
    
    // Load layer 0 weights
    float *ln1 = load_tensor_f32_local(sf, "model.language_model.layers.0.input_layernorm.weight", 1024);
    float *qkv_w = load_tensor_f32_local(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight", 6144 * 1024);
    float *z_w = load_tensor_f32_local(sf, "model.language_model.layers.0.linear_attn.in_proj_z.weight", 2048 * 1024);
    float *a_w = load_tensor_f32_local(sf, "model.language_model.layers.0.linear_attn.in_proj_a.weight", 16 * 1024);
    float *b_w = load_tensor_f32_local(sf, "model.language_model.layers.0.linear_attn.in_proj_b.weight", 16 * 1024);
    float *A_log = load_tensor_f32_local(sf, "model.language_model.layers.0.linear_attn.A_log", 16);
    float *dt = load_tensor_f32_local(sf, "model.language_model.layers.0.linear_attn.dt_bias", 16);
    float *norm_w = load_tensor_f32_local(sf, "model.language_model.layers.0.linear_attn.norm.weight", 128);
    float *out_w = load_tensor_f32_local(sf, "model.language_model.layers.0.linear_attn.out_proj.weight", 1024 * 2048);
    
    printf("Layer 0 weights loaded\n");
    
    // Apply RMSNorm
    float x_norm[1024];
    rmsnorm(x_norm, x, ln1, 1024);
    printf("After RMSNorm: %.4f, %.4f, %.4f, %.4f\n", x_norm[0], x_norm[1], x_norm[2], x_norm[3]);
    
    // QKV projection
    float qkv[6144];
    matmul(qkv, qkv_w, x_norm, 1024, 6144);
    printf("QKV [0:4]: %.4f, %.4f, %.4f, %.4f\n", qkv[0], qkv[1], qkv[2], qkv[3]);
    printf("QKV range: %.4f to %.4f\n", 
           0.0f + 0.0f, 0.0f + 0.0f);  // Need to compute min/max
    
    float min_v = 1e9, max_v = -1e9;
    for (int i = 0; i < 6144; i++) {
        if (qkv[i] < min_v) min_v = qkv[i];
        if (qkv[i] > max_v) max_v = qkv[i];
    }
    printf("QKV range: %.4f to %.4f\n", min_v, max_v);
    
    // Z projection
    float z[2048];
    matmul(z, z_w, x_norm, 1024, 2048);
    printf("Z [0:4]: %.4f, %.4f, %.4f, %.4f\n", z[0], z[1], z[2], z[3]);
    
    // A and B projections
    float a[16], b[16];
    matmul(a, a_w, x_norm, 1024, 16);
    matmul(b, b_w, x_norm, 1024, 16);
    
    printf("A (raw) [0:4]: %.4f, %.4f, %.4f, %.4f\n", a[0], a[1], a[2], a[3]);
    printf("B (raw) [0:4]: %.4f, %.4f, %.4f, %.4f\n", b[0], b[1], b[2], b[3]);
    
    // Process first head
    int h = 0;
    float *q = qkv + h * 128;
    float *k = qkv + 16 * 128 + h * 128;  // offset 2048
    float *v = qkv + 32 * 128 + h * 128;  // offset 4096
    float *zh = z + h * 128;
    
    printf("\nHead 0:\n");
    printf("Q [0:4]: %.4f, %.4f, %.4f, %.4f\n", q[0], q[1], q[2], q[3]);
    printf("K [0:4]: %.4f, %.4f, %.4f, %.4f\n", k[0], k[1], k[2], k[3]);
    printf("V [0:4]: %.4f, %.4f, %.4f, %.4f\n", v[0], v[1], v[2], v[3]);
    
    // Normalize Q and K
    float q_norm = 0, k_norm = 0;
    for (int i = 0; i < 128; i++) { q_norm += q[i]*q[i]; k_norm += k[i]*k[i]; }
    q_norm = 1.0f / sqrtf(q_norm + 1e-6f);
    k_norm = 1.0f / sqrtf(k_norm + 1e-6f);
    for (int i = 0; i < 128; i++) { q[i] *= q_norm; k[i] *= k_norm; }
    printf("Q norm: %.4f, K norm: %.4f\n", q_norm, k_norm);
    
    // Scale Q
    float scale = 1.0f / sqrtf(128.0f);
    for (int i = 0; i < 128; i++) q[i] *= scale;
    
    // Decay and beta
    float beta = 1.0f / (1.0f + expf(-b[h]));
    float sp = logf(1.0f + expf(a[h] - dt[h]));
    float g = -expf(A_log[h]) * sp;
    float gamma = expf(g);
    
    printf("beta: %.4f, softplus: %.4f, g: %.4f, gamma: %.6f\n", beta, sp, g, gamma);
    
    // For first token, state is zero, so:
    // kv_mem = 0
    // delta = v * beta
    // state = k @ delta
    // out = state @ q
    
    // Since state starts at 0, after update:
    // state = outer(k, v * beta)
    // out = state @ q = (v * beta) * (k @ q)
    
    // k @ q
    float kq = 0;
    for (int i = 0; i < 128; i++) kq += k[i] * q[i];
    printf("k @ q: %.4f\n", kq);
    
    // Output for first position
    float out[128];
    for (int j = 0; j < 128; j++) {
        out[j] = v[j] * beta * kq;
    }
    printf("Output [0:4]: %.4f, %.4f, %.4f, %.4f\n", out[0], out[1], out[2], out[3]);
    
    // Apply gated RMSNorm
    float ss = 0;
    for (int j = 0; j < 128; j++) ss += out[j] * out[j];
    ss = 1.0f / sqrtf(ss / 128 + 1e-6f);
    for (int j = 0; j < 128; j++) out[j] = norm_w[j] * ss * out[j] * silu(zh[j]);
    printf("After gated norm [0:4]: %.4f, %.4f, %.4f, %.4f\n", out[0], out[1], out[2], out[3]);
    
    safetensors_close(sf);
    return 0;
}