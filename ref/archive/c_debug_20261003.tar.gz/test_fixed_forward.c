/*
 * Test forward with fixed Conv1D and decay formula
 * Key fixes to test:
 * 1. Conv1D: use w[0] at position 0 (not w[3])
 * 2. Decay: use softplus(-dt) instead of softplus(+dt)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { void *p = calloc(n, 1); if (!p) { fprintf(stderr, "malloc failed\n"); exit(1); } return p; }

float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) return NULL;
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

float silu(float x) { return x / (1.0f + expf(-x)); }

int main() {
    const char *path = "/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors";
    SafetensorsFile *sf = safetensors_open(path);
    
    printf("=== Loading weights ===\n");
    float *embed = load_tensor_f32(sf, "model.language_model.embed_tokens.weight");
    float *ln0 = load_tensor_f32(sf, "model.language_model.layers.0.input_layernorm.weight");
    float *gdn_qkv = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight");
    float *gdn_conv = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.conv1d.weight");
    float *gdn_z = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_z.weight");
    float *gdn_a = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_a.weight");
    float *gdn_b = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_b.weight");
    float *gdn_A = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.A_log");
    float *gdn_dt = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.dt_bias");
    float *gdn_norm = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.norm.weight");
    float *gdn_out = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.out_proj.weight");
    printf("Weights loaded.\n");
    
    int dim = 1024, nv = 16, kd = 128, vd = 128;
    
    // Token 248045 embedding
    float *x = embed + 248045 * dim;
    float *x1 = xmalloc(dim * sizeof(float));
    rmsnorm(x1, x, ln0, dim);
    
    printf("\n=== Embedding ===\n");
    printf("x[0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3], x[4]);
    printf("x1[0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n", x1[0], x1[1], x1[2], x1[3], x1[4]);
    
    // QKV projection
    float *qkv = xmalloc(6144 * sizeof(float));
    for (int i = 0; i < 6144; i++) {
        float sum = 0;
        for (int j = 0; j < dim; j++) sum += gdn_qkv[i * dim + j] * x1[j];
        qkv[i] = sum;
    }
    
    // Test both conv implementations
    printf("\n=== Conv1D Test ===\n");
    
    // Current (wrong): shift then store, use w[3]
    float *qkv_cur = xmalloc(6144 * sizeof(float));
    float state_cur[6144][4] = {0};
    for (int ch = 0; ch < 6144; ch++) {
        state_cur[ch][0] = state_cur[ch][1];
        state_cur[ch][1] = state_cur[ch][2];
        state_cur[ch][2] = state_cur[ch][3];
        state_cur[ch][3] = qkv[ch];
        float sum = 0;
        for (int k = 0; k < 4; k++) sum += state_cur[ch][k] * gdn_conv[ch * 4 + k];
        qkv_cur[ch] = sum;
    }
    printf("Current (w[3]): Q[0:5] = %.6f, %.6f, %.6f, %.6f, %.6f\n", 
           qkv_cur[0], qkv_cur[1], qkv_cur[2], qkv_cur[3], qkv_cur[4]);
    
    // Fixed: don't apply conv at position 0 (just use qkv directly)
    // This is equivalent to treating the initial state as identity
    printf("Fixed (no conv at pos 0): Q[0:5] = %.6f, %.6f, %.6f, %.6f, %.6f\n",
           qkv[0], qkv[1], qkv[2], qkv[3], qkv[4]);
    
    // Z projection
    float *z = xmalloc(nv * vd * sizeof(float));
    for (int i = 0; i < nv * vd; i++) {
        float sum = 0;
        for (int j = 0; j < dim; j++) sum += gdn_z[i * dim + j] * x1[j];
        z[i] = sum;
    }
    
    // A and B projections
    float *a_proj = xmalloc(nv * sizeof(float));
    float *b_proj = xmalloc(nv * sizeof(float));
    for (int i = 0; i < nv; i++) {
        float sum_a = 0, sum_b = 0;
        for (int j = 0; j < dim; j++) {
            sum_a += gdn_a[i * dim + j] * x1[j];
            sum_b += gdn_b[i * dim + j] * x1[j];
        }
        a_proj[i] = sum_a;
        b_proj[i] = 1.0f / (1.0f + expf(-sum_b));  // sigmoid
    }
    
    printf("\n=== GDN Processing ===\n");
    printf("Testing with current (small) QKV:\n");
    
    // Use current conv output
    float *out_cur = xmalloc(nv * vd * sizeof(float));
    float *state_cur_gdn = calloc(nv * kd * vd, sizeof(float));
    
    for (int h = 0; h < nv; h++) {
        float *q = qkv_cur + h * kd;
        float *k = qkv_cur + nv * kd + h * kd;
        float *v = qkv_cur + 2 * nv * kd + h * kd;
        float *zh = z + h * vd;
        float *sh = state_cur_gdn + h * kd * vd;
        
        // Normalize Q and K
        float q_norm = 0, k_norm = 0;
        for (int i = 0; i < kd; i++) { q_norm += q[i]*q[i]; k_norm += k[i]*k[i]; }
        q_norm = 1.0f / sqrtf(q_norm + 1e-6f);
        k_norm = 1.0f / sqrtf(k_norm + 1e-6f);
        for (int i = 0; i < kd; i++) { q[i] *= q_norm; k[i] *= k_norm; }
        
        // Scale Q
        for (int i = 0; i < kd; i++) q[i] /= sqrtf(kd);
        
        // Compute decay with CURRENT formula: softplus(a + dt)
        float A = gdn_A[h], dt = gdn_dt[h], a = a_proj[h], beta = b_proj[h];
        float sp = logf(1 + expf(a + dt));
        float gamma = expf(-expf(A) * sp);
        
        // Update state
        for (int i = 0; i < kd * vd; i++) sh[i] *= gamma;
        
        // kv_mem = state @ k
        float kv_mem[128] = {0};
        for (int j = 0; j < vd; j++) {
            for (int i = 0; i < kd; i++) kv_mem[j] += sh[i * vd + j] * k[i];
        }
        
        // delta = (v - kv_mem) * beta
        float delta[128];
        for (int j = 0; j < vd; j++) delta[j] = (v[j] - kv_mem[j]) * beta;
        
        // state += outer(k, delta)
        for (int i = 0; i < kd; i++) {
            for (int j = 0; j < vd; j++) sh[i * vd + j] += k[i] * delta[j];
        }
        
        // out = state @ q
        float *out_h = out_cur + h * vd;
        for (int j = 0; j < vd; j++) {
            for (int i = 0; i < kd; i++) out_h[j] += sh[i * vd + j] * q[i];
        }
        
        // Apply norm and silu
        float out_norm = 0;
        for (int j = 0; j < vd; j++) out_norm += out_h[j] * out_h[j];
        out_norm = 1.0f / sqrtf(out_norm / vd + 1e-6f);
        for (int j = 0; j < vd; j++) {
            out_h[j] = gdn_norm[h * vd + j] * out_norm * out_h[j] * silu(zh[j]);
        }
        
        if (h == 0) {
            printf("  Head 0: gamma=%.6f, beta=%.4f\n", gamma, beta);
            printf("  out_h[0:4]: %.6f, %.6f, %.6f, %.6f\n", out_h[0], out_h[1], out_h[2], out_h[3]);
        }
    }
    
    // Output projection
    float *out_final_cur = xmalloc(dim * sizeof(float));
    for (int i = 0; i < dim; i++) {
        float sum = 0;
        for (int j = 0; j < nv * vd; j++) sum += gdn_out[i * nv * vd + j] * out_cur[j];
        out_final_cur[i] = sum;
    }
    
    printf("\n=== After GDN (current) ===\n");
    printf("out[0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n", 
           out_final_cur[0], out_final_cur[1], out_final_cur[2], out_final_cur[3], out_final_cur[4]);
    printf("out norm: %.4f\n", sqrtf(out_final_cur[0]*out_final_cur[0] + out_final_cur[1]*out_final_cur[1] + out_final_cur[2]*out_final_cur[2]));
    
    // Now test with FIXED decay formula: softplus(a - dt)
    printf("\n=== Testing with FIXED decay: softplus(a - dt) ===\n");
    float *out_fixed = xmalloc(nv * vd * sizeof(float));
    float *state_fixed = calloc(nv * kd * vd, sizeof(float));
    
    // Copy qkv_cur again since we modified it
    for (int i = 0; i < 6144; i++) qkv_cur[i] = i < 2048 ? qkv[i] : qkv[i];  // Keep original for now
    // Actually let's reload from scratch with no conv
    for (int i = 0; i < 6144; i++) qkv_cur[i] = qkv[i];  // Skip conv entirely
    
    for (int h = 0; h < nv; h++) {
        float *q = qkv_cur + h * kd;
        float *k = qkv_cur + nv * kd + h * kd;
        float *v = qkv_cur + 2 * nv * kd + h * kd;
        float *zh = z + h * vd;
        float *sh = state_fixed + h * kd * vd;
        
        float q_norm = 0, k_norm = 0;
        for (int i = 0; i < kd; i++) { q_norm += q[i]*q[i]; k_norm += k[i]*k[i]; }
        q_norm = 1.0f / sqrtf(q_norm + 1e-6f);
        k_norm = 1.0f / sqrtf(k_norm + 1e-6f);
        for (int i = 0; i < kd; i++) { q[i] *= q_norm; k[i] *= k_norm; }
        for (int i = 0; i < kd; i++) q[i] /= sqrtf(kd);
        
        float A = gdn_A[h], dt = gdn_dt[h], a = a_proj[h], beta = b_proj[h];
        // FIXED: use a - dt instead of a + dt
        float sp = logf(1 + expf(a - dt));
        float gamma = expf(-expf(A) * sp);
        
        for (int i = 0; i < kd * vd; i++) sh[i] *= gamma;
        
        float kv_mem[128] = {0};
        for (int j = 0; j < vd; j++) {
            for (int i = 0; i < kd; i++) kv_mem[j] += sh[i * vd + j] * k[i];
        }
        
        float delta[128];
        for (int j = 0; j < vd; j++) delta[j] = (v[j] - kv_mem[j]) * beta;
        
        for (int i = 0; i < kd; i++) {
            for (int j = 0; j < vd; j++) sh[i * vd + j] += k[i] * delta[j];
        }
        
        float *out_h = out_fixed + h * vd;
        for (int j = 0; j < vd; j++) {
            for (int i = 0; i < kd; i++) out_h[j] += sh[i * vd + j] * q[i];
        }
        
        float out_norm = 0;
        for (int j = 0; j < vd; j++) out_norm += out_h[j] * out_h[j];
        out_norm = 1.0f / sqrtf(out_norm / vd + 1e-6f);
        for (int j = 0; j < vd; j++) {
            out_h[j] = gdn_norm[h * vd + j] * out_norm * out_h[j] * silu(zh[j]);
        }
        
        if (h == 0) {
            printf("  Head 0: gamma=%.6f (was %.6f), beta=%.4f\n", gamma, expf(-expf(A) * logf(1 + expf(a + dt))), beta);
            printf("  out_h[0:4]: %.6f, %.6f, %.6f, %.6f\n", out_h[0], out_h[1], out_h[2], out_h[3]);
        }
    }
    
    float *out_final_fixed = xmalloc(dim * sizeof(float));
    for (int i = 0; i < dim; i++) {
        float sum = 0;
        for (int j = 0; j < nv * vd; j++) sum += gdn_out[i * nv * vd + j] * out_fixed[j];
        out_final_fixed[i] = sum;
    }
    
    printf("\n=== After GDN (fixed decay, no conv) ===\n");
    printf("out[0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n", 
           out_final_fixed[0], out_final_fixed[1], out_final_fixed[2], out_final_fixed[3], out_final_fixed[4]);
    printf("out norm: %.4f\n", sqrtf(out_final_fixed[0]*out_final_fixed[0] + out_final_fixed[1]*out_final_fixed[1] + out_final_fixed[2]*out_final_fixed[2]));
    
    printf("\n=== Summary ===\n");
    printf("Original embedding norm: %.4f\n", sqrtf(x[0]*x[0] + x[1]*x[1] + x[2]*x[2] + x[3]*x[3] + x[4]*x[4]));
    printf("After layernorm norm: %.4f\n", sqrtf(x1[0]*x1[0] + x1[1]*x1[1] + x1[2]*x1[2] + x1[3]*x1[3] + x1[4]*x1[4]));
    printf("After GDN (current) norm: %.4f\n", sqrtf(out_final_cur[0]*out_final_cur[0] + out_final_cur[1]*out_final_cur[1] + out_final_cur[2]*out_final_cur[2]));
    printf("After GDN (fixed) norm: %.4f\n", sqrtf(out_final_fixed[0]*out_final_fixed[0] + out_final_fixed[1]*out_final_fixed[1] + out_final_fixed[2]*out_final_fixed[2]));
    
    safetensors_close(sf);
    return 0;
}