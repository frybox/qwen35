#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "safetensors.h"

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) {
        printf("Failed to open safetensors\n");
        return 1;
    }
    
    // Get q_norm tensor for layer 3
    TensorMeta *meta = safetensors_get_tensor(sf, "model.language_model.layers.3.self_attn.q_norm.weight");
    if (!meta) {
        printf("Failed to get q_norm tensor\n");
        return 1;
    }
    
    printf("q_norm tensor info:\n");
    printf("  dtype: %d\n", meta->dtype);
    printf("  ndim: %d\n", meta->ndim);
    printf("  shape: [%d]\n", meta->shape[0]);
    printf("  data_offset: %ld\n", (long)meta->data_offset);
    printf("  data_size: %ld\n", (long)meta->data_size);
    
    // Load as f32
    int count = meta->shape[0];
    float *data = malloc(count * sizeof(float));
    if (safetensors_load_tensor_as_f32(sf, meta, data) != 0) {
        printf("Failed to load tensor\n");
        return 1;
    }
    
    printf("\nFirst 8 values:\n");
    for (int i = 0; i < 8; i++) {
        printf("  data[%d] = %.4f\n", i, data[i]);
    }
    
    printf("\nMiddle 8 values (124-131):\n");
    for (int i = 124; i < 132 && i < count; i++) {
        printf("  data[%d] = %.4f\n", i, data[i]);
    }
    
    printf("\nLast 8 values:\n");
    for (int i = count - 8; i < count; i++) {
        printf("  data[%d] = %.4f\n", i, data[i]);
    }
    
    safetensors_close(sf);
    free(data);
    return 0;
}
