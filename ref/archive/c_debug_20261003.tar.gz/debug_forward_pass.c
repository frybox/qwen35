// Debug full forward pass with intermediate state inspection
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float silu(float x) { return x / (1.0f + expf(-x)); }

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

int main() {
    printf("=== Full Forward Pass Debug ===\n\n");
    
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) { printf("Failed to open model\n"); return 1; }
    
    // Load embeddings
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    float *final_norm = load_tensor(sf, "model.language_model.norm.weight", 1024);
    
    // Load ALL layer weights for first 4 layers
    #define MAX_LAYER 4
    float *ln1[MAX_LAYER], *ln2[MAX_LAYER];
    float *gate[MAX_LAYER], *up[MAX_LAYER], *down[MAX_LAYER];
    
    // Layer types: LLLFLLLF... (L=linear/GDN, F=full)
    int layer_types[24] = {0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1};
    
    // Load weights for first 4 layers
    for (int l = 0; l < MAX_LAYER; l++) {
        char name[256];
        sprintf(name, "model.language_model.layers.%d.input_layernorm.weight", l);
        ln1[l] = load_tensor(sf, name, 1024);
        
        sprintf(name, "model.language_model.layers.%d.post_attention_layernorm.weight", l);
        ln2[l] = load_tensor(sf, name, 1024);
        
        sprintf(name, "model.language_model.layers.%d.mlp.gate_proj.weight", l);
        gate[l] = load_tensor(sf, name, 3584 * 1024);
        
        sprintf(name, "model.language_model.layers.%d.mlp.up_proj.weight", l);
        up[l] = load_tensor(sf, name, 3584 * 1024);
        
        sprintf(name, "model.language_model.layers.%d.mlp.down_proj.weight", l);
        down[l] = load_tensor(sf, name, 1024 * 3584);
    }
    
    // GDN weights for layers 0-2
    float *gdn_qkv[3], *gdn_conv[3], *gdn_z[3], *gdn_a[3], *gdn_b[3];
    float *gdn_A[3], *gdn_dt[3], *gdn_norm[3], *gdn_out[3];
    
    for (int l = 0; l < 3; l++) {
        char name[256];
        sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_qkv.weight", l);
        gdn_qkv[l] = load_tensor(sf, name, 6144 * 1024);
        
        sprintf(name, "model.language_model.layers.%d.linear_attn.conv1d.weight", l);
        gdn_conv[l] = load_tensor(sf, name, 6144 * 4);
        
        sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_z.weight", l);
        gdn_z[l] = load_tensor(sf, name, 2048 * 1024);
        
        sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_a.weight", l);
        gdn_a[l] = load_tensor(sf, name, 16 * 1024);
        
        sprintf(name, "model.language_model.layers.%d.linear_attn.in_proj_b.weight", l);
        gdn_b[l] = load_tensor(sf, name, 16 * 1024);
        
        sprintf(name, "model.language_model.layers.%d.linear_attn.A_log", l);
        gdn_A[l] = load_tensor(sf, name, 16);
        
        sprintf(name, "model.language_model.layers.%d.linear_attn.dt_bias", l);
        gdn_dt[l] = load_tensor(sf, name, 16);
        
        sprintf(name, "model.language_model.layers.%d.linear_attn.norm.weight", l);
        gdn_norm[l] = load_tensor(sf, name, 128);
        
        sprintf(name, "model.language_model.layers.%d.linear_attn.out_proj.weight", l);
        gdn_out[l] = load_tensor(sf, name, 1024 * 2048);
    }
    
    // Full attention weights for layer 3
    float *fa_q = load_tensor(sf, "model.language_model.layers.3.self_attn.q_proj.weight", 4096 * 1024);
    float *fa_k = load_tensor(sf, "model.language_model.layers.3.self_attn.k_proj.weight", 512 * 1024);
    float *fa_v = load_tensor(sf, "model.language_model.layers.3.self_attn.v_proj.weight", 512 * 1024);
    float *fa_qn = load_tensor(sf, "model.language_model.layers.3.self_attn.q_norm.weight", 256);
    float *fa_kn = load_tensor(sf, "model.language_model.layers.3.self_attn.k_norm.weight", 256);
    float *fa_o = load_tensor(sf, "model.language_model.layers.3.self_attn.o_proj.weight", 1024 * 2048);
    
    printf("All weights loaded\n\n");
    
    // Process single token
    int token = 248045;  // <|im_start|>
    float x[1024];
    memcpy(x, embed + token * 1024, sizeof(x));
    
    printf("Processing token %d\n", token);
    printf("Initial embedding [0:4]: %.4f, %.4f, %.4f, %.4f\n\n", x[0], x[1], x[2], x[3]);
    
    // Process layers
    float gdn_state[3][16][128 * 128] = {0};  // State for each GDN layer
    float conv_state[3][6144 * 4] = {0};
    
    for (int l = 0; l < MAX_LAYER; l++) {
        printf("=== Layer %d (%s) ===\n", l, layer_types[l] == 0 ? "GDN" : "Full");
        
        float norm_L2 = 0;
        for (int i = 0; i < 1024; i++) norm_L2 += x[i] * x[i];
        printf("Input L2: %.4f\n", sqrtf(norm_L2));
        
        float x_norm[1024];
        rmsnorm(x_norm, x, ln1[l], 1024);
        
        norm_L2 = 0;
        for (int i = 0; i < 1024; i++) norm_L2 += x_norm[i] * x_norm[i];
        printf("After ln1, L2: %.4f\n", sqrtf(norm_L2));
        
        if (layer_types[l] == 0) {
            // GDN layer
            int gdn_idx = 0;
            for (int i = 0; i < l; i++) if (layer_types[i] == 0) gdn_idx++;
            
            // QKV projection
            float qkv[6144];
            matmul(qkv, gdn_qkv[gdn_idx], x_norm, 1024, 6144);
            
            // Conv1D
            for (int i = 0; i < 6144; i++) {
                float *cs = conv_state[gdn_idx] + i * 4;
                float *cw = gdn_conv[gdn_idx] + i * 4;
                cs[0] = cs[1]; cs[1] = cs[2]; cs[2] = cs[3]; cs[3] = qkv[i];
                float sum = 0;
                for (int k = 0; k < 4; k++) sum += cs[k] * cw[k];
                qkv[i] = sum;
            }
            
            // Z, A, B
            float z[2048], a[16], b[16];
            matmul(z, gdn_z[gdn_idx], x_norm, 1024, 2048);
            matmul(a, gdn_a[gdn_idx], x_norm, 1024, 16);
            matmul(b, gdn_b[gdn_idx], x_norm, 1024, 16);
            
            // Process heads
            float gdn_out_buf[2048];
            for (int h = 0; h < 16; h++) {
                float *q = qkv + h * 128;
                float *k = qkv + 2048 + h * 128;
                float *v = qkv + 4096 + h * 128;
                float *zh = z + h * 128;
                float *sh = gdn_state[gdn_idx][h];
                float *out = gdn_out_buf + h * 128;
                
                // L2 norm Q, K
                float qn = 0, kn = 0;
                for (int i = 0; i < 128; i++) { qn += q[i]*q[i]; kn += k[i]*k[i]; }
                qn = 1.0f / sqrtf(qn + 1e-6f);
                kn = 1.0f / sqrtf(kn + 1e-6f);
                for (int i = 0; i < 128; i++) { q[i] *= qn; k[i] *= kn; }
                
                // Scale Q
                float sc = 1.0f / sqrtf(128.0f);
                for (int i = 0; i < 128; i++) q[i] *= sc;
                
                // Decay and beta
                float beta = 1.0f / (1.0f + expf(-b[h]));
                float sp = logf(1.0f + expf(a[h] + gdn_dt[gdn_idx][h]));
                float g = -expf(gdn_A[gdn_idx][h]) * sp;
                float gamma = expf(g);
                
                // Decay state
                for (int i = 0; i < 128 * 128; i++) sh[i] *= gamma;
                
                // kv_mem
                float kv_mem[128] = {0};
                for (int j = 0; j < 128; j++) {
                    for (int i = 0; i < 128; i++) kv_mem[j] += sh[i*128 + j] * k[i];
                }
                
                // delta
                float delta[128];
                for (int j = 0; j < 128; j++) delta[j] = (v[j] - kv_mem[j]) * beta;
                
                // Update state
                for (int i = 0; i < 128; i++) {
                    for (int j = 0; j < 128; j++) sh[i*128 + j] += k[i] * delta[j];
                }
                
                // Output
                for (int j = 0; j < 128; j++) {
                    float sum = 0;
                    for (int i = 0; i < 128; i++) sum += sh[i*128 + j] * q[i];
                    out[j] = sum;
                }
                
                // Gated norm
                float ss = 0;
                for (int j = 0; j < 128; j++) ss += out[j] * out[j];
                ss = 1.0f / sqrtf(ss / 128 + 1e-6f);
                for (int j = 0; j < 128; j++) out[j] = gdn_norm[gdn_idx][j] * ss * out[j] * silu(zh[j]);
            }
            
            // Out projection
            float attn_out[1024];
            matmul(attn_out, gdn_out[gdn_idx], gdn_out_buf, 2048, 1024);
            
            // Residual
            for (int i = 0; i < 1024; i++) x[i] += attn_out[i];
            
            norm_L2 = 0;
            for (int i = 0; i < 1024; i++) norm_L2 += x[i] * x[i];
            printf("After GDN, L2: %.4f\n", sqrtf(norm_L2));
            
        } else {
            // Full attention layer
            float q_gate[4096];
            matmul(q_gate, fa_q, x_norm, 1024, 4096);
            
            float q[2048], gate[2048];
            memcpy(q, q_gate, 2048 * sizeof(float));
            memcpy(gate, q_gate + 2048, 2048 * sizeof(float));
            
            // Q norm
            for (int h = 0; h < 8; h++) {
                rmsnorm(q + h*256, q + h*256, fa_qn, 256);
            }
            
            // K projection
            float k[512];
            matmul(k, fa_k, x_norm, 1024, 512);
            
            // K norm
            for (int h = 0; h < 2; h++) {
                rmsnorm(k + h*256, k + h*256, fa_kn, 256);
            }
            
            // V projection
            float v[512];
            matmul(v, fa_v, x_norm, 1024, 512);
            
            // Single position attention (no KV cache needed for this test)
            float attn_out[2048] = {0};
            for (int h = 0; h < 8; h++) {
                float *qh = q + h * 256;
                int kvh = h / 4;
                float *kh = k + kvh * 256;
                float *vh = v + kvh * 256;
                
                // Score
                float score = 0;
                for (int i = 0; i < 256; i++) score += qh[i] * kh[i];
                score /= sqrtf(256.0f);
                
                // Single position: attention weight = 1.0 after softmax
                float *out = attn_out + h * 256;
                for (int i = 0; i < 256; i++) out[i] = vh[i];
            }
            
            // Apply gate
            for (int i = 0; i < 2048; i++) {
                float g = 1.0f / (1.0f + expf(-gate[i]));
                attn_out[i] *= g;
            }
            
            // Output projection
            float final_out[1024];
            matmul(final_out, fa_o, attn_out, 2048, 1024);
            
            // Residual
            for (int i = 0; i < 1024; i++) x[i] += final_out[i];
            
            norm_L2 = 0;
            for (int i = 0; i < 1024; i++) norm_L2 += x[i] * x[i];
            printf("After Full Attn, L2: %.4f\n", sqrtf(norm_L2));
        }
        
        // MLP
        float x_mlp[1024];
        rmsnorm(x_mlp, x, ln2[l], 1024);
        
        float g[3584], u[3584];
        matmul(g, gate[l], x_mlp, 1024, 3584);
        matmul(u, up[l], x_mlp, 1024, 3584);
        
        for (int i = 0; i < 3584; i++) g[i] = silu(g[i]) * u[i];
        
        float mlp_out[1024];
        matmul(mlp_out, down[l], g, 3584, 1024);
        
        // Residual
        for (int i = 0; i < 1024; i++) x[i] += mlp_out[i];
        
        norm_L2 = 0;
        for (int i = 0; i < 1024; i++) norm_L2 += x[i] * x[i];
        printf("After MLP, L2: %.4f\n", sqrtf(norm_L2));
        printf("x [0:4]: %.4f, %.4f, %.4f, %.4f\n\n", x[0], x[1], x[2], x[3]);
    }
    
    // Final norm
    printf("=== Final ===\n");
    rmsnorm(x, x, final_norm, 1024);
    
    float norm_L2 = 0;
    for (int i = 0; i < 1024; i++) norm_L2 += x[i] * x[i];
    printf("After final norm, L2: %.4f\n", sqrtf(norm_L2));
    printf("x [0:4]: %.4f, %.4f, %.4f, %.4f\n\n", x[0], x[1], x[2], x[3]);
    
    // Compute top logits
    printf("Top 10 logits:\n");
    float top_vals[10] = {-1e9};
    int top_ids[10] = {0};
    
    for (int i = 0; i < 248320; i++) {
        float dot = 0;
        for (int j = 0; j < 1024; j++) dot += embed[i * 1024 + j] * x[j];
        
        // Insert into top 10
        for (int k = 0; k < 10; k++) {
            if (dot > top_vals[k]) {
                for (int m = 9; m > k; m--) {
                    top_vals[m] = top_vals[m-1];
                    top_ids[m] = top_ids[m-1];
                }
                top_vals[k] = dot;
                top_ids[k] = i;
                break;
            }
        }
    }
    
    for (int i = 0; i < 10; i++) {
        printf("  token %d: logit=%.4f\n", top_ids[i], top_vals[i]);
    }
    
    safetensors_close(sf);
    return 0;
}