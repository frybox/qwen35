import numpy as np
import struct
import json

def load_tensor(path, name):
    with open(path, 'rb') as f:
        header_size = struct.unpack('<Q', f.read(8))[0]
        header = f.read(header_size).decode('utf-8')
        meta = json.loads(header)
        
        info = meta[name]
        start, end = info['data_offsets']
        f.seek(8 + header_size + start)
        data = f.read(end - start)
        
        if info['dtype'] == 'BF16':
            bf16 = np.frombuffer(data, dtype=np.uint16)
            fp32 = (bf16.astype(np.uint32) << 16).view(np.float32)
            return fp32.reshape(info['shape'])
        elif info['dtype'] == 'F32':
            return np.frombuffer(data, dtype=np.float32).reshape(info['shape'])
        return None

path = '/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors'

# Load GDN weights for layer 0
A_log = load_tensor(path, 'model.language_model.layers.0.linear_attn.A_log')
dt_bias = load_tensor(path, 'model.language_model.layers.0.linear_attn.dt_bias')

print("=== GDN Layer 0 Analysis ===")
print(f"A_log shape: {A_log.shape}")
print(f"dt_bias shape: {dt_bias.shape}")

# The key question: what is the correct decay formula?
# Looking at Mamba/S4 style: decay = exp(-exp(A_log) * softplus(dt + delta_param))
# But dt_bias might be already the delta_param, not added to anything

print("\n=== Possible decay formulas ===")

# Formula 1: softplus(a + dt_bias)
print("Formula 1: gamma = exp(-exp(A_log) * softplus(a + dt_bias))")
for h in range(4):
    A = A_log[h]
    dt = dt_bias[h]
    a = 0.0  # neutral
    sp = np.log(1 + np.exp(a + dt))
    g = -np.exp(A) * sp
    gamma = np.exp(g)
    print(f"  Head {h}: A_log={A:.4f}, dt={dt:.4f}, gamma={gamma:.6f}")

# Formula 2: dt_bias is the delta, not added to a
print("\nFormula 2: gamma = exp(-exp(A_log) * dt_bias)")
for h in range(4):
    A = A_log[h]
    dt = dt_bias[h]
    g = -np.exp(A) * dt if dt > 0 else -np.exp(A) * np.log(1 + np.exp(dt))
    gamma = np.exp(g) if dt > 0 else np.exp(-np.exp(A) * np.log(1 + np.exp(dt)))
    print(f"  Head {h}: A_log={A:.4f}, dt={dt:.4f}, gamma={gamma:.6f}")

# Formula 3: exp(-dt_bias) as the base decay
print("\nFormula 3: gamma = exp(-exp(A_log + dt_bias))")
for h in range(4):
    A = A_log[h]
    dt = dt_bias[h]
    gamma = np.exp(-np.exp(A + dt))
    print(f"  Head {h}: A_log={A:.4f}, dt={dt:.4f}, gamma={gamma:.6f}")

# Formula 4: Sigmoid-based
print("\nFormula 4: gamma = sigmoid(-exp(A_log) * softplus(dt_bias))")
for h in range(4):
    A = A_log[h]
    dt = dt_bias[h]
    sp = np.log(1 + np.exp(dt))
    gamma = 1 / (1 + np.exp(np.exp(A) * sp))
    print(f"  Head {h}: A_log={A:.4f}, dt={dt:.4f}, gamma={gamma:.6f}")
