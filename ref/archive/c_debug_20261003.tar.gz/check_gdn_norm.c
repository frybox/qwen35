/*
 * Check GDN norm weight loading
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "safetensors.h"

void *xmalloc(size_t n) { void *p = calloc(n, 1); if (!p) { fprintf(stderr, "malloc failed\n"); exit(1); } return p; }

float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) { fprintf(stderr, "Tensor '%s' not found\n", name); return NULL; }
    
    printf("Tensor '%s': shape=[", name);
    for (int i = 0; i < meta->ndim; i++) printf("%ld%s", (long)meta->shape[i], i < meta->ndim-1 ? ", " : "");
    printf("], dtype=%d, offset=%ld, size=%ld\n", meta->dtype, (long)meta->data_offset, (long)meta->data_size);
    
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    
    if (safetensors_load_tensor_as_f32(sf, meta, data) != 0) {
        fprintf(stderr, "Failed to load tensor '%s'\n", name);
        free(data);
        return NULL;
    }
    
    return data;
}

int main() {
    const char *path = "/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors";
    SafetensorsFile *sf = safetensors_open(path);
    
    float *gdn_norm = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.norm.weight");
    
    if (gdn_norm) {
        printf("\ngdn_norm first 16 values:\n");
        for (int i = 0; i < 16; i++) {
            printf("  [%d] = %.6f\n", i, gdn_norm[i]);
        }
        
        printf("\ngdn_norm values for heads 9, 13, 14, 15:\n");
        int vd = 128;
        int heads[] = {9, 13, 14, 15};
        for (int idx = 0; idx < 4; idx++) {
            int h = heads[idx];
            printf("  Head %d: ", h);
            for (int i = 0; i < 4; i++) {
                printf("%.4f ", gdn_norm[h * vd + i]);
            }
            printf("...\n");
        }
    }
    
    // Also check if there's a different norm weight
    printf("\n=== Checking other norm tensors ===\n");
    float *ln1 = load_tensor_f32(sf, "model.language_model.layers.0.input_layernorm.weight");
    if (ln1) {
        printf("input_layernorm first 8: ");
        for (int i = 0; i < 8; i++) printf("%.4f ", ln1[i]);
        printf("\n");
    }
    
    safetensors_close(sf);
    return 0;
}