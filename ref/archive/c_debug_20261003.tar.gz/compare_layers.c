// Compare layer-by-layer output between two implementations
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    if (!m) return NULL;
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

int main() {
    printf("=== Layer Comparison ===\n\n");
    
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    
    // Load layer 0 weights
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    float *ln1 = load_tensor(sf, "model.language_model.layers.0.input_layernorm.weight", 1024);
    float *gdn_qkv = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight", 6144 * 1024);
    float *gdn_z = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_z.weight", 2048 * 1024);
    float *gdn_a = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_a.weight", 16 * 1024);
    float *gdn_b = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_b.weight", 16 * 1024);
    float *gdn_A = load_tensor(sf, "model.language_model.layers.0.linear_attn.A_log", 16);
    float *gdn_dt = load_tensor(sf, "model.language_model.layers.0.linear_attn.dt_bias", 16);
    float *gdn_norm = load_tensor(sf, "model.language_model.layers.0.linear_attn.norm.weight", 128);
    float *gdn_out = load_tensor(sf, "model.language_model.layers.0.linear_attn.out_proj.weight", 1024 * 2048);
    float *gdn_conv = load_tensor(sf, "model.language_model.layers.0.linear_attn.conv1d.weight", 6144 * 4);
    
    // Process 3 tokens through layer 0
    int tokens[] = {248045, 846, 198};
    float state[16][128*128] = {0};
    float conv_s[6144*4] = {0};
    
    for (int pos = 0; pos < 3; pos++) {
        float x[1024], x_norm[1024];
        memcpy(x, embed + tokens[pos] * 1024, sizeof(x));
        rmsnorm(x_norm, x, ln1, 1024);
        
        float qkv[6144];
        matmul(qkv, gdn_qkv, x_norm, 1024, 6144);
        
        // Conv1D
        for (int i = 0; i < 6144; i++) {
            float *cs = conv_s + i * 4;
            float *cw = gdn_conv + i * 4;
            cs[0] = cs[1]; cs[1] = cs[2]; cs[2] = cs[3]; cs[3] = qkv[i];
            float sum = 0;
            for (int k = 0; k < 4; k++) sum += cs[k] * cw[k];
            qkv[i] = sum;
        }
        
        float z[2048], a[16], b[16];
        matmul(z, gdn_z, x_norm, 1024, 2048);
        matmul(a, gdn_a, x_norm, 1024, 16);
        matmul(b, gdn_b, x_norm, 1024, 16);
        
        float gdn_out_buf[2048];
        for (int h = 0; h < 16; h++) {
            float *q = qkv + h * 128;
            float *k = qkv + 2048 + h * 128;
            float *v = qkv + 4096 + h * 128;
            float *zh = z + h * 128;
            float *sh = state[h];
            float *out = gdn_out_buf + h * 128;
            
            float qn = 0, kn = 0;
            for (int i = 0; i < 128; i++) { qn += q[i]*q[i]; kn += k[i]*k[i]; }
            qn = 1.0f / sqrtf(qn + 1e-6f);
            kn = 1.0f / sqrtf(kn + 1e-6f);
            for (int i = 0; i < 128; i++) { q[i] *= qn; k[i] *= kn; }
            
            for (int i = 0; i < 128; i++) q[i] /= sqrtf(128.0f);
            
            float beta = 1.0f / (1.0f + expf(-b[h]));
            float sp = logf(1.0f + expf(a[h] + gdn_dt[h]));
            float g = -expf(gdn_A[h]) * sp;
            float gamma = expf(g);
            
            for (int i = 0; i < 128 * 128; i++) sh[i] *= gamma;
            
            float kv_mem[128] = {0};
            for (int j = 0; j < 128; j++) {
                for (int i = 0; i < 128; i++) kv_mem[j] += sh[i*128 + j] * k[i];
            }
            
            float delta[128];
            for (int j = 0; j < 128; j++) delta[j] = (v[j] - kv_mem[j]) * beta;
            
            for (int i = 0; i < 128; i++) {
                for (int j = 0; j < 128; j++) sh[i*128 + j] += k[i] * delta[j];
            }
            
            for (int j = 0; j < 128; j++) {
                float sum = 0;
                for (int i = 0; i < 128; i++) sum += sh[i*128 + j] * q[i];
                out[j] = sum;
            }
            
            float ss = 0;
            for (int j = 0; j < 128; j++) ss += out[j] * out[j];
            ss = 1.0f / sqrtf(ss / 128 + 1e-6f);
            for (int j = 0; j < 128; j++) out[j] = gdn_norm[j] * ss * out[j] * (z[h*128+j] / (1.0f + expf(-z[h*128+j])));
        }
        
        float attn_out[1024];
        matmul(attn_out, gdn_out, gdn_out_buf, 2048, 1024);
        
        for (int i = 0; i < 1024; i++) x[i] += attn_out[i];
        
        printf("Pos %d, token %d:\n", pos, tokens[pos]);
        printf("  x [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
        printf("  x L2: %.4f\n", sqrtf(x[0]*x[0] + x[1]*x[1] + x[2]*x[2] + x[3]*x[3] + x[4]*x[4]));
    }
    
    safetensors_close(sf);
    return 0;
}
