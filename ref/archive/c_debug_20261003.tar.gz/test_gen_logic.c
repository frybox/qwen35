#include <stdio.h>

int main() {
    int prompt_ids[] = {
        248045,  // <|im_start|>
        846,     // "user"
        198,     // "\n"
        12162, 5028, 264, 854,  // "Once upon a time"
        248046,  // <|im_end|>
        198,     // "\n"
        248045,  // <|im_start|>
        74455,   // "assistant"
        198,     // "\n"
    };
    int n_prompt_ids = 12;
    
    printf("Prompt tokens: %d\n\n", n_prompt_ids);
    
    // Simulate generation loop
    int token = prompt_ids[0];
    printf("Before loop: forward(token=%d, pos=0)\n", token);
    
    for (int pos = 0; pos < 15; pos++) {
        printf("pos=%d: ", pos);
        
        if (pos > 0) {
            printf("forward(token=%d, pos=%d), ", token, pos);
        }
        
        int next;
        if (pos < n_prompt_ids - 1) {
            next = prompt_ids[pos + 1];
            printf("next = prompt_ids[%d] = %d (prompt)\n", pos+1, next);
        } else {
            printf("next = sample_argmax(logits) (generate)\n");
        }
        
        token = next;
    }
    
    return 0;
}
