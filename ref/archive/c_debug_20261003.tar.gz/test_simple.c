// Test with simpler prompt - just a number
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    if (!m) return NULL;
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

int main() {
    printf("=== Simple Prompt Test ===\n\n");
    
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    float *final_norm = load_tensor(sf, "model.language_model.norm.weight", 1024);
    
    // Load all layer weights (simplified)
    float *ln1[24], *ln2[24], *gate[24], *up[24], *down[24];
    char name[256];
    for (int l = 0; l < 24; l++) {
        sprintf(name, "model.language_model.layers.%d.input_layernorm.weight", l);
        ln1[l] = load_tensor(sf, name, 1024);
        sprintf(name, "model.language_model.layers.%d.post_attention_layernorm.weight", l);
        ln2[l] = load_tensor(sf, name, 1024);
        sprintf(name, "model.language_model.layers.%d.mlp.gate_proj.weight", l);
        gate[l] = load_tensor(sf, name, 3584 * 1024);
        sprintf(name, "model.language_model.layers.%d.mlp.up_proj.weight", l);
        up[l] = load_tensor(sf, name, 3584 * 1024);
        sprintf(name, "model.language_model.layers.%d.mlp.down_proj.weight", l);
        down[l] = load_tensor(sf, name, 1024 * 3584);
    }
    
    printf("Weights loaded\n");
    
    // Test: single token "1" (token 16)
    float x[1024];
    memcpy(x, embed + 16, sizeof(x));  // Token 16 = "1"
    
    printf("\nInput: token 16 (\"1\")\n");
    printf("Embedding [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
    
    // Apply layer norms and MLP only (skip attention for now)
    for (int l = 0; l < 24; l++) {
        float x_norm[1024];
        rmsnorm(x_norm, x, ln1[l], 1024);
        // Skip attention - just use x_norm directly
        
        // Apply post-attention norm (use x as residual)
        float x_mlp[1024];
        rmsnorm(x_mlp, x, ln2[l], 1024);
        
        // MLP
        float g[3584], u[3584];
        matmul(g, gate[l], x_mlp, 1024, 3584);
        matmul(u, up[l], x_mlp, 1024, 3584);
        for (int i = 0; i < 3584; i++) g[i] = (g[i] / (1.0f + expf(-g[i]))) * u[i];
        
        float mlp_out[1024];
        matmul(mlp_out, down[l], g, 3584, 1024);
        
        // Residual
        for (int i = 0; i < 1024; i++) x[i] += mlp_out[i];
    }
    
    printf("\nAfter all layers (MLP only):\n");
    printf("x [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
    
    // Final norm
    rmsnorm(x, x, final_norm, 1024);
    printf("After final norm: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
    
    // Top logits
    float top_vals[5] = {-1e9};
    int top_ids[5] = {0};
    for (int i = 0; i < 248320; i++) {
        float dot = 0;
        for (int j = 0; j < 1024; j++) dot += embed[i * 1024 + j] * x[j];
        for (int k = 0; k < 5; k++) {
            if (dot > top_vals[k]) {
                for (int m = 4; m > k; m--) { top_vals[m] = top_vals[m-1]; top_ids[m] = top_ids[m-1]; }
                top_vals[k] = dot; top_ids[k] = i;
                break;
            }
        }
    }
    
    printf("\nTop 5 tokens:\n");
    for (int i = 0; i < 5; i++) printf("  token %d: logit=%.4f\n", top_ids[i], top_vals[i]);
    
    safetensors_close(sf);
    return 0;
}
