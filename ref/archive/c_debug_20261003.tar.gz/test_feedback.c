// Test if token 198 creates positive feedback
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

// Minimal safetensors reader
float *load_embed(SafetensorsFile *sf, int token, int dim) {
    TensorMeta *embed = safetensors_get_tensor(sf, "model.language_model.embed_tokens.weight");
    float *data = malloc(dim * sizeof(float));
    
    // Read BF16 data for this token
    long offset = embed->data_offset + token * dim * 2;
    fseek(sf->fp, 8 + sf->metadata_len + offset, SEEK_SET);
    uint16_t *tmp = malloc(dim * 2);
    fread(tmp, 1, dim * 2, sf->fp);
    
    // Convert BF16 to FP32
    for (int i = 0; i < dim; i++) {
        uint32_t val = ((uint32_t)tmp[i]) << 16;
        memcpy(&data[i], &val, sizeof(float));
    }
    free(tmp);
    return data;
}

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    int dim = 1024;
    
    // Check self-similarity of embedding with its logits
    // For tied weights, logits = embed @ hidden
    // So if hidden is similar to embed[token], logits[token] will be high
    
    float *embed_198 = load_embed(sf, 198, dim);
    float *embed_assistant = load_embed(sf, 74455, dim);
    float *embed_once = load_embed(sf, 12162, dim);
    
    // Simulate what happens if hidden state is similar to embed_198
    // logits[198] = embed_198 @ hidden
    // If hidden ≈ embed_198, then logits[198] = ||embed_198||^2
    
    float self_dot_198 = 0;
    for (int i = 0; i < dim; i++) self_dot_198 += embed_198[i] * embed_198[i];
    printf("Self-similarity of embed_198: %.4f\n", self_dot_198);
    printf("If hidden = embed_198, logits[198] = %.4f\n", self_dot_198);
    
    float self_dot_assistant = 0;
    for (int i = 0; i < dim; i++) self_dot_assistant += embed_assistant[i] * embed_assistant[i];
    printf("Self-similarity of embed_assistant: %.4f\n", self_dot_assistant);
    
    float self_dot_once = 0;
    for (int i = 0; i < dim; i++) self_dot_once += embed_once[i] * embed_once[i];
    printf("Self-similarity of embed_once: %.4f\n", self_dot_once);
    
    // Check if embed_198 has unusual properties
    printf("\n=== Embedding 198 analysis ===\n");
    float mean = 0, std = 0;
    for (int i = 0; i < dim; i++) mean += embed_198[i];
    mean /= dim;
    for (int i = 0; i < dim; i++) std += (embed_198[i] - mean) * (embed_198[i] - mean);
    std = sqrtf(std / dim);
    printf("Mean: %.6f, Std: %.6f\n", mean, std);
    
    safetensors_close(sf);
    free(embed_198);
    free(embed_assistant);
    free(embed_once);
    return 0;
}
