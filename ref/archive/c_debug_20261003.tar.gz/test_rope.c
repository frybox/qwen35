#include <stdio.h>
#include <math.h>

// Test RoPE implementation
void apply_rope_correct(float *q, int head_dim, int pos) {
    // Qwen3.5: partial_rotary_factor=0.25, rope_theta=10000000
    int rotary_dim = head_dim / 4;  // Only rotate first 64 dims (25%)
    float theta = 10000000.0f;
    
    printf("RoPE: head_dim=%d, rotary_dim=%d, theta=%.0f\n", head_dim, rotary_dim, theta);
    
    for (int i = 0; i < rotary_dim; i += 2) {
        // Correct formula: freq = 1 / theta^(2i/d_rotary)
        // where d_rotary = rotary_dim (NOT head_dim)
        float freq = 1.0f / powf(theta, (float)(2*i) / rotary_dim);
        float val = pos * freq;
        float cr = cosf(val), ci = sinf(val);
        printf("  i=%d: freq=%.6e, angle=%.4f, cos=%.4f, sin=%.4f\n", i, freq, val, cr, ci);
    }
}

int main() {
    float q[256] = {1.0f, 0.5f};  // Test values
    printf("=== Testing RoPE ===\n");
    apply_rope_correct(q, 256, 0);
    printf("\n");
    apply_rope_correct(q, 256, 1);
    printf("\n");
    apply_rope_correct(q, 256, 10);
    return 0;
}
