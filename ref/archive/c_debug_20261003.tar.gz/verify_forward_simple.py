#!/usr/bin/env python3
"""
Simplified verification - only load the tensors we need.
Compare with C engine step by step.
"""
import numpy as np
import json
import struct

def load_tensor_bf16(path, name):
    """Load a BF16 tensor from safetensors, convert to float32"""
    with open(path, 'rb') as f:
        # Read header
        header_size = struct.unpack('<Q', f.read(8))[0]
        header = f.read(header_size).decode('utf-8')
        meta = json.loads(header)
        
        if name not in meta:
            print(f"Tensor '{name}' not found")
            return None
        
        info = meta[name]
        start, end = info['data_offsets']
        
        # Seek to data
        f.seek(8 + header_size + start)
        data = f.read(end - start)
        
        # Convert BF16 to FP32
        bf16 = np.frombuffer(data, dtype=np.uint16)
        fp32 = (bf16.astype(np.uint32) << 16).view(np.float32)
        return fp32.reshape(info['shape'])

path = '/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors'

print("=== Loading key tensors ===")

# Load embedding
embed = load_tensor_bf16(path, 'model.language_model.embed_tokens.weight')
print(f"embed: {embed.shape}, dtype: {embed.dtype}")

# Load layer 0 layernorm
ln0 = load_tensor_bf16(path, 'model.language_model.layers.0.input_layernorm.weight')
print(f"ln0: {ln0.shape}")

# Get token 248045 embedding
token_id = 248045
x = embed[token_id].copy()
print(f"\n=== Token {token_id} Embedding ===")
print(f"Norm: {np.linalg.norm(x):.6f}")
print(f"First 8: {x[:8]}")
print(f"Last 8: {x[-8:]}")

# Apply RMSNorm
def rmsnorm(x, w, eps=1e-6):
    variance = np.mean(x ** 2)
    return w * x / np.sqrt(variance + eps)

x1 = rmsnorm(x, ln0)
print(f"\n=== After LayerNorm ===")
print(f"Norm: {np.linalg.norm(x1):.6f}")
print(f"First 8: {x1[:8]}")

# Load QKV weight
gdn_qkv = load_tensor_bf16(path, 'model.language_model.layers.0.linear_attn.in_proj_qkv.weight')
print(f"\ngdn_qkv: {gdn_qkv.shape}")

# QKV projection
qkv = gdn_qkv @ x1
print(f"\n=== QKV Projection ===")
print(f"QKV norm: {np.linalg.norm(qkv):.6f}")
print(f"QKV first 8: {qkv[:8]}")

# Split Q, K, V
q = qkv[:2048]
k = qkv[2048:4096]
v = qkv[4096:]
print(f"\nQ first 4: {q[:4]}")
print(f"K first 4: {k[:4]}")
print(f"V first 4: {v[:4]}")

# Load A_log and dt
A_log = load_tensor_bf16(path, 'model.language_model.layers.0.linear_attn.A_log')
dt_bias = load_tensor_bf16(path, 'model.language_model.layers.0.linear_attn.dt_bias')
print(f"\nA_log: {A_log.shape}, values: {A_log[:4]}")
print(f"dt_bias: {dt_bias.shape}, values: {dt_bias[:4]}")

# Load conv weight
conv = load_tensor_bf16(path, 'model.language_model.layers.0.linear_attn.conv1d.weight')
print(f"conv1d: {conv.shape}")
print(f"conv1d[0]: {conv[0]}")

# Compute gamma for first head
print("\n=== Decay Formula ===")
a_val = 0.5  # placeholder, need actual projection
A0 = A_log[0]
dt0 = dt_bias[0]
print(f"A_log[0] = {A0:.6f}")
print(f"dt_bias[0] = {dt0:.6f}")
print(f"exp(A_log[0]) = {np.exp(A0):.6f}")

# Test different interpretations
print("\nInterpretation 1: softplus(0 + dt_bias)")
sp1 = np.log(1 + np.exp(dt0))
g1 = -np.exp(A0) * sp1
gamma1 = np.exp(g1)
print(f"  softplus({dt0:.4f}) = {sp1:.4f}")
print(f"  g = {g1:.4f}")
print(f"  gamma = {gamma1:.6f}")

print("\nInterpretation 2: softplus(0 - dt_bias)")
sp2 = np.log(1 + np.exp(-dt0))
g2 = -np.exp(A0) * sp2
gamma2 = np.exp(g2)
print(f"  softplus({-dt0:.4f}) = {sp2:.4f}")
print(f"  g = {g2:.4f}")
print(f"  gamma = {gamma2:.6f}")

print("\n=== Summary for C comparison ===")
print(f"Embedding[248045] first 8: {x[:8]}")
print(f"Layernorm output first 8: {x1[:8]}")
print(f"Q first 4: {q[:4]}")
print(f"K first 4: {k[:4]}")