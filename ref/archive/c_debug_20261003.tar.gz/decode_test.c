#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tokenizer.h"

int main() {
    BPETokenizer tok;
    tokenizer_init(&tok);
    tokenizer_load_vocab(&tok, "/mnt/Qwen3.5-0.8B/tokenizer.json");
    
    // Decode specific tokens
    int tokens[] = {13266, 140193, 175862, 164034, 107756, 846, 198};
    char buf[256];
    
    printf("Testing token decoding:\n\n");
    for (int i = 0; i < 7; i++) {
        int t = tokens[i];
        const char *s = tokenizer_get_token(&tok, t);
        printf("Token %d: %s\n", t, s ? s : "(null)");
    }
    
    tokenizer_free(&tok);
    return 0;
}
