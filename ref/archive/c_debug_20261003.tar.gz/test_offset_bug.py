#!/usr/bin/env python3
"""Verify the double-offset bug in check_embed.c."""
import numpy as np
import struct
import json

path = '/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors'
token_id = 248045

with open(path, 'rb') as f:
    header_size = struct.unpack('<Q', f.read(8))[0]
    header = f.read(header_size).decode('utf-8')
    meta = json.loads(header)
    
    embed_info = meta['model.language_model.embed_tokens.weight']
    start, end = embed_info['data_offsets']
    shape = embed_info['shape']
    dim = shape[1]
    
    # Correct offset (what Python does)
    correct_offset = 8 + header_size + start + token_id * dim * 2
    
    # What check_embed.c does (double offset bug)
    # Line 27: meta.data_offset = embed->data_offset + tokens[t] * dim * 2
    # where embed->data_offset = data_base + start = 8 + header_size + start
    # Line 32: fseek(fp, 8 + metadata_len + meta.data_offset, ...)
    # = 8 + header_size + (8 + header_size + start + token_id * dim * 2)
    buggy_offset = 8 + header_size + (8 + header_size + start + token_id * dim * 2)
    
    print(f"Header size: {header_size}")
    print(f"Embedding start offset in safetensors: {start}")
    print(f"Token {token_id} offset within embedding: {token_id * dim * 2}")
    print()
    print(f"Correct absolute offset: {correct_offset}")
    print(f"Buggy offset (double header): {buggy_offset}")
    print(f"Difference: {buggy_offset - correct_offset} bytes")
    print()
    
    # Read at correct offset
    f.seek(correct_offset)
    raw_correct = f.read(dim * 2)
    bf16_correct = np.frombuffer(raw_correct, dtype=np.uint16)
    fp32_correct = (bf16_correct.astype(np.uint32) << 16).view(np.float32)
    
    # Read at buggy offset
    f.seek(buggy_offset)
    raw_buggy = f.read(dim * 2)
    bf16_buggy = np.frombuffer(raw_buggy, dtype=np.uint16)
    fp32_buggy = (bf16_buggy.astype(np.uint32) << 16).view(np.float32)
    
    print("Correct (Python) first 4:", fp32_correct[:4])
    print("Buggy (C check_embed) first 4:", fp32_buggy[:4])
    print()
    print("C engine reported first 4: [0.0066, 0.0081, -0.0011, 0.0001]")
    
    # Check if buggy matches what C reported
    print()
    print("Does buggy offset match C output?")
    for i in range(4):
        print(f"  [{i}] Buggy={fp32_buggy[i]:.4f}, C reported=... (checking)")

    # Actually, let's see what's at that buggy offset
    print(f"\nWhat data is at buggy offset? First 16 bytes: {raw_buggy[:16].hex()}")