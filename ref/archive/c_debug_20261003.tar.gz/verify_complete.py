#!/usr/bin/env python3
"""
Complete verification of GDN forward pass with Python reference.
This script verifies the key findings and compares with C engine output.
"""
import numpy as np
import struct
import json

def load_tensor(path, name):
    """Load a tensor from safetensors file"""
    with open(path, 'rb') as f:
        header_size = struct.unpack('<Q', f.read(8))[0]
        header = f.read(header_size).decode('utf-8')
        meta = json.loads(header)
        
        if name not in meta:
            return None
        info = meta[name]
        start, end = info['data_offsets']
        f.seek(8 + header_size + start)
        data = f.read(end - start)
        
        if info['dtype'] == 'BF16':
            bf16 = np.frombuffer(data, dtype=np.uint16)
            fp32 = (bf16.astype(np.uint32) << 16).view(np.float32)
            return fp32.reshape(info['shape'])
        elif info['dtype'] == 'F32':
            return np.frombuffer(data, dtype=np.float32).reshape(info['shape'])
        return None

def rmsnorm(x, w, eps=1e-6):
    variance = np.mean(x ** 2)
    return w * x / np.sqrt(variance + eps)

def silu(x):
    return x / (1.0 + np.exp(-x))

# Load model
path = '/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors'

print("=" * 60)
print("GDN Forward Pass Verification")
print("=" * 60)

# Load weights
embed = load_tensor(path, 'model.language_model.embed_tokens.weight')
ln0 = load_tensor(path, 'model.language_model.layers.0.input_layernorm.weight')
gdn_qkv = load_tensor(path, 'model.language_model.layers.0.linear_attn.in_proj_qkv.weight')
gdn_z = load_tensor(path, 'model.language_model.layers.0.linear_attn.in_proj_z.weight')
gdn_a = load_tensor(path, 'model.language_model.layers.0.linear_attn.in_proj_a.weight')
gdn_b = load_tensor(path, 'model.language_model.layers.0.linear_attn.in_proj_b.weight')
gdn_A = load_tensor(path, 'model.language_model.layers.0.linear_attn.A_log')
gdn_dt = load_tensor(path, 'model.language_model.layers.0.linear_attn.dt_bias')
gdn_norm = load_tensor(path, 'model.language_model.layers.0.linear_attn.norm.weight')
gdn_out = load_tensor(path, 'model.language_model.layers.0.linear_attn.out_proj.weight')

print(f"\n=== Weight Shapes ===")
print(f"embed: {embed.shape}")
print(f"ln0: {ln0.shape}")
print(f"gdn_qkv: {gdn_qkv.shape}")
print(f"gdn_z: {gdn_z.shape}")
print(f"gdn_a: {gdn_a.shape}")
print(f"gdn_b: {gdn_b.shape}")
print(f"gdn_A: {gdn_A.shape} (A_log)")
print(f"gdn_dt: {gdn_dt.shape} (dt_bias)")
print(f"gdn_norm: {gdn_norm.shape} <-- CRITICAL: This is [128], not [2048]!")
print(f"gdn_out: {gdn_out.shape}")

# Token embedding
token_id = 248045
x = embed[token_id].copy()

print(f"\n=== Step 1: Embedding (token {token_id}) ===")
print(f"x[0:5]: {x[:5]}")
print(f"Norm: {np.linalg.norm(x):.6f}")

# RMSNorm
x1 = rmsnorm(x, ln0)
print(f"\n=== Step 2: After RMSNorm ===")
print(f"x1[0:5]: {x1[:5]}")
print(f"Norm: {np.linalg.norm(x1):.6f}")

# QKV projection
qkv = gdn_qkv @ x1
print(f"\n=== Step 3: QKV Projection ===")
print(f"QKV shape: {qkv.shape}")
print(f"QKV[0:5]: {qkv[:5]}")
print(f"Q[0:5]: {qkv[:5]}")
print(f"K[0:5]: {qkv[2048:2053]}")
print(f"V[0:5]: {qkv[4096:4101]}")

# GDN parameters
print(f"\n=== GDN Parameters ===")
print(f"A_log: {gdn_A}")
print(f"dt_bias: {gdn_dt}")
print(f"exp(A_log): {np.exp(gdn_A)}")

# Z, A, B projections
z = gdn_z @ x1
a_proj = gdn_a @ x1
b_proj = 1.0 / (1.0 + np.exp(-gdn_b @ x1))

print(f"\n=== Projections ===")
print(f"z shape: {z.shape}")
print(f"a_proj: {a_proj}")
print(f"b_proj: {b_proj}")

# Process GDN
nv = 16
kd = 128
vd = 128

all_out = np.zeros((nv, vd))

print(f"\n=== GDN Processing (Fixed Implementation) ===")
for h in range(nv):
    q = qkv[h*kd:(h+1)*kd].copy()
    k = qkv[nv*kd + h*kd:nv*kd + (h+1)*kd].copy()
    v = qkv[2*nv*kd + h*kd:2*nv*kd + (h+1)*kd].copy()
    zh = z[h*vd:(h+1)*vd]
    
    # Normalize Q and K
    q = q / np.sqrt(np.sum(q**2) + 1e-6)
    k = k / np.sqrt(np.sum(k**2) + 1e-6)
    q = q / np.sqrt(kd)
    
    # Decay - using FIXED formula: softplus(a - dt)
    A = gdn_A[h]
    dt = gdn_dt[h]
    a = a_proj[h]
    beta = b_proj[h]
    sp = np.log(1 + np.exp(a - dt))
    gamma = np.exp(-np.exp(A) * sp)
    
    # At position 0, state = 0
    # delta = v * beta
    delta = v * beta
    
    # state = outer(k, delta)
    state = np.outer(k, delta)
    
    # out = state @ q
    out = state @ q
    
    # Apply output norm and silu
    # CRITICAL: gdn_norm is [128], shared by all heads!
    out_norm = 1.0 / np.sqrt(np.sum(out**2) / vd + 1e-6)
    out = gdn_norm * out_norm * out * silu(zh)  # FIXED: gdn_norm, not gdn_norm[h*vd:]
    
    all_out[h] = out
    
    if h < 4:
        print(f"Head {h}: gamma={gamma:.4f}, beta={beta:.4f}, out_norm={np.linalg.norm(out):.4f}")

# Output projection
final_out = gdn_out @ all_out.flatten()
print(f"\n=== Output Projection ===")
print(f"Output shape: {final_out.shape}")
print(f"Norm: {np.linalg.norm(final_out):.4f}")
print(f"final_out[0:5]: {final_out[:5]}")

# Add residual
output = final_out + x1
print(f"\n=== After Residual ===")
print(f"Norm: {np.linalg.norm(output):.4f}")
print(f"output[0:5]: {output[:5]}")

# Compare with C engine
print(f"\n{'='*60}")
print("COMPARISON WITH C ENGINE")
print(f"{'='*60}")

print(f"\n| Metric | Python | C (Fixed) | Match |")
print(f"|--------|--------|-----------|-------|")
print(f"| Embedding[0] | {x[0]:.6f} | 0.014282 | {'✓' if abs(x[0] - 0.014282) < 1e-4 else '✗'} |")
print(f"| LN output[0] | {x1[0]:.6f} | 0.864328 | {'✓' if abs(x1[0] - 0.864328) < 1e-4 else '✗'} |")
print(f"| Q[0] before conv | {qkv[0]:.6f} | -0.089683 | {'✓' if abs(qkv[0] + 0.089683) < 1e-4 else '✗'} |")
print(f"| gdn_norm[0] | {gdn_norm[0]:.6f} | 0.963135 | {'✓' if abs(gdn_norm[0] - 0.963135) < 1e-4 else '✗'} |")
print(f"| GDN output norm | {np.linalg.norm(final_out):.4f} | 0.8806 | {'✓' if abs(np.linalg.norm(final_out) - 0.8806) < 0.1 else '✗'} |")

print(f"\n{'='*60}")
print("KEY FINDINGS")
print(f"{'='*60}")
print("""
1. BUG FOUND: gdn_norm weight shape is [128], not [16*128]
   - All 16 heads share the same norm weights
   - C code incorrectly used gdn_norm[h * vd + j], causing buffer overflow
   - For heads 9, 13, 14, 15, this accessed garbage values

2. DECAY FORMULA: Using softplus(a - dt) gives gamma ≈ 0.9 instead of 0.03
   - This preserves more information at position 0

3. NEXT STEPS: Need to verify with PyTorch/HuggingFace implementation
""")

print(f"\n{'='*60}")
print("C CODE FIX NEEDED")
print(f"{'='*60}")
print("""
In test_minimal.c line 378:
  OLD: out[j] = w->gdn_norm[layer][j + h*vd] * ss * out[j] * silu(zh[j]);
  NEW: out[j] = w->gdn_norm[layer][j] * ss * out[j] * silu(zh[j]);

Also need to verify decay formula in line 353.
""")