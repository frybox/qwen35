/*
 * Check why some heads explode
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { void *p = calloc(n, 1); if (!p) { fprintf(stderr, "malloc failed\n"); exit(1); } return p; }

float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) return NULL;
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

float silu(float x) { return x / (1.0f + expf(-x)); }

int main() {
    const char *path = "/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors";
    SafetensorsFile *sf = safetensors_open(path);
    
    float *embed = load_tensor_f32(sf, "model.language_model.embed_tokens.weight");
    float *ln0 = load_tensor_f32(sf, "model.language_model.layers.0.input_layernorm.weight");
    float *gdn_qkv = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight");
    float *gdn_z = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_z.weight");
    float *gdn_b = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_b.weight");
    float *gdn_norm = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.norm.weight");
    
    int dim = 1024, nv = 16, kd = 128, vd = 128;
    
    float *x = embed + 248045 * dim;
    float *x1 = xmalloc(dim * sizeof(float));
    rmsnorm(x1, x, ln0, dim);
    
    float *qkv = xmalloc(6144 * sizeof(float));
    for (int i = 0; i < 6144; i++) {
        float sum = 0;
        for (int j = 0; j < dim; j++) sum += gdn_qkv[i * dim + j] * x1[j];
        qkv[i] = sum;
    }
    
    float *z = xmalloc(nv * vd * sizeof(float));
    for (int i = 0; i < nv * vd; i++) {
        float sum = 0;
        for (int j = 0; j < dim; j++) sum += gdn_z[i * dim + j] * x1[j];
        z[i] = sum;
    }
    
    float *b_proj = xmalloc(nv * sizeof(float));
    for (int i = 0; i < nv; i++) {
        float sum_b = 0;
        for (int j = 0; j < dim; j++) sum_b += gdn_b[i * dim + j] * x1[j];
        b_proj[i] = 1.0f / (1.0f + expf(-sum_b));
    }
    
    // Check problematic heads
    int bad_heads[] = {9, 13, 14, 15};
    for (int idx = 0; idx < 4; idx++) {
        int h = bad_heads[idx];
        printf("\n=== Head %d ===\n", h);
        
        float *q = qkv + h * kd;
        float *k = qkv + nv * kd + h * kd;
        float *v = qkv + 2 * nv * kd + h * kd;
        float *zh = z + h * vd;
        
        printf("Q[0:4]: %.6f, %.6f, %.6f, %.6f\n", q[0], q[1], q[2], q[3]);
        printf("K[0:4]: %.6f, %.6f, %.6f, %.6f\n", k[0], k[1], k[2], k[3]);
        printf("V[0:4]: %.6f, %.6f, %.6f, %.6f\n", v[0], v[1], v[2], v[3]);
        printf("Z[0:4]: %.6f, %.6f, %.6f, %.6f\n", zh[0], zh[1], zh[2], zh[3]);
        
        float qn = 0, kn = 0, vn = 0, zn = 0;
        for (int i = 0; i < kd; i++) { qn += q[i]*q[i]; kn += k[i]*k[i]; vn += v[i]*v[i]; }
        for (int i = 0; i < vd; i++) zn += zh[i]*zh[i];
        printf("Q norm: %.6f, K norm: %.6f, V norm: %.6f, Z norm: %.6f\n", sqrtf(qn), sqrtf(kn), sqrtf(vn), sqrtf(zn));
        
        printf("beta: %.4f\n", b_proj[h]);
        
        // Normalize
        qn = 1.0f / sqrtf(qn + 1e-6f);
        kn = 1.0f / sqrtf(kn + 1e-6f);
        for (int i = 0; i < kd; i++) { q[i] *= qn; k[i] *= kn; }
        for (int i = 0; i < kd; i++) q[i] /= sqrtf(kd);
        
        // Compute
        float delta[128];
        for (int j = 0; j < vd; j++) delta[j] = v[j] * b_proj[h];
        
        float state[128*128] = {0};
        for (int i = 0; i < kd; i++) {
            for (int j = 0; j < vd; j++) {
                state[i * vd + j] = k[i] * delta[j];
            }
        }
        
        float out[128] = {0};
        for (int j = 0; j < vd; j++) {
            for (int i = 0; i < kd; i++) {
                out[j] += state[i * vd + j] * q[i];
            }
        }
        
        float on = 0;
        for (int j = 0; j < vd; j++) on += out[j] * out[j];
        printf("out norm before final norm: %.6f\n", sqrtf(on));
        
        printf("out[0:4]: %.6f, %.6f, %.6f, %.6f\n", out[0], out[1], out[2], out[3]);
        
        // Check for NaN or inf
        int has_nan = 0, has_inf = 0;
        for (int j = 0; j < vd; j++) {
            if (isnan(out[j])) has_nan = 1;
            if (isinf(out[j])) has_inf = 1;
        }
        if (has_nan) printf("WARNING: out has NaN!\n");
        if (has_inf) printf("WARNING: out has Inf!\n");
        
        // Apply norm and silu
        on = 1.0f / sqrtf(on / vd + 1e-6f);
        for (int j = 0; j < vd; j++) {
            float silu_val = silu(zh[j]);
            if (isnan(silu_val) || isinf(silu_val)) {
                printf("Bad silu at j=%d: zh=%.6f, silu=%.6f\n", j, zh[j], silu_val);
            }
            out[j] = gdn_norm[h * vd + j] * on * out[j] * silu_val;
        }
        
        on = 0;
        for (int j = 0; j < vd; j++) on += out[j] * out[j];
        printf("Final out norm: %.6f\n", sqrtf(on));
        
        // Check gdn_norm
        printf("gdn_norm[%d][0:4]: %.4f, %.4f, %.4f, %.4f\n", h,
               gdn_norm[h * vd], gdn_norm[h * vd + 1], gdn_norm[h * vd + 2], gdn_norm[h * vd + 3]);
    }
    
    safetensors_close(sf);
    return 0;
}