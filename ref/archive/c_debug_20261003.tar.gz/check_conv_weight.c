/*
 * Check Conv1D weight values and compute the output at position 0
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { void *p = calloc(n, 1); if (!p) { fprintf(stderr, "malloc failed\n"); exit(1); } return p; }

float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) { fprintf(stderr, "Tensor '%s' not found\n", name); return NULL; }
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}

int main() {
    const char *path = "/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors";
    SafetensorsFile *sf = safetensors_open(path);
    if (!sf) { fprintf(stderr, "Failed to open model\n"); return 1; }

    float *gdn_conv = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.conv1d.weight");
    printf("Conv1D weight shape: [6144, 4]\n");
    
    // Check first few channels
    printf("\n=== Conv1D weight values ===\n");
    printf("Channel 0 weights: [%.6f, %.6f, %.6f, %.6f]\n", 
           gdn_conv[0], gdn_conv[1], gdn_conv[2], gdn_conv[3]);
    printf("Channel 1 weights: [%.6f, %.6f, %.6f, %.6f]\n", 
           gdn_conv[4], gdn_conv[5], gdn_conv[6], gdn_conv[7]);
    printf("Channel 2 weights: [%.6f, %.6f, %.6f, %.6f]\n", 
           gdn_conv[8], gdn_conv[9], gdn_conv[10], gdn_conv[11]);
    
    // At position 0:
    // conv_state = [0, 0, 0, qkv[ch]]
    // output = 0*w[0] + 0*w[1] + 0*w[2] + qkv[ch]*w[3] = qkv[ch] * w[3]
    
    printf("\n=== At position 0, conv1d output = qkv[ch] * w[ch*4+3] ===\n");
    printf("w[3] for channel 0: %.6f\n", gdn_conv[3]);
    printf("w[3] for channel 1: %.6f\n", gdn_conv[7]);
    printf("w[3] for channel 2: %.6f\n", gdn_conv[11]);
    
    // If w[3] is very small, output will be very small!
    // Check the distribution of w[3]
    float w3_sum = 0, w3_min = 1e9, w3_max = -1e9;
    for (int ch = 0; ch < 6144; ch++) {
        float w3 = gdn_conv[ch * 4 + 3];
        w3_sum += w3;
        if (w3 < w3_min) w3_min = w3;
        if (w3 > w3_max) w3_max = w3;
    }
    printf("\nw[3] statistics: mean=%.6f, min=%.6f, max=%.6f\n", w3_sum/6144, w3_min, w3_max);
    
    // What if the weight layout is wrong?
    // Maybe it's [4, 6144] instead of [6144, 4]?
    printf("\n=== Alternative layout: [4, 6144] ===\n");
    // Then w[3][ch] would be at offset 3*6144 + ch
    printf("If layout is [4, 6144], then for channel 0:\n");
    printf("  w[0][0]=%.6f, w[1][0]=%.6f, w[2][0]=%.6f, w[3][0]=%.6f\n",
           gdn_conv[0*6144 + 0], gdn_conv[1*6144 + 0], gdn_conv[2*6144 + 0], gdn_conv[3*6144 + 0]);
    
    // Check if this interpretation makes more sense
    float alt_sum = 0, alt_min = 1e9, alt_max = -1e9;
    for (int ch = 0; ch < 6144; ch++) {
        float w3 = gdn_conv[3 * 6144 + ch];
        alt_sum += w3;
        if (w3 < alt_min) alt_min = w3;
        if (w3 > alt_max) alt_max = w3;
    }
    printf("w[3][ch] statistics: mean=%.6f, min=%.6f, max=%.6f\n", alt_sum/6144, alt_min, alt_max);
    
    // Let's also check if the weights are causal (should be lower triangular or similar)
    printf("\n=== Weight pattern check ===\n");
    printf("First channel weights: [%.4f, %.4f, %.4f, %.4f]\n", 
           gdn_conv[0], gdn_conv[1], gdn_conv[2], gdn_conv[3]);
    printf("This looks like the weights for a 1D convolution with kernel size 4.\n");
    printf("For causal conv, the last weight (w[3]) should be the main one.\n");
    
    // Check if the issue is that w[3] is indeed very small
    // In a causal conv, position 0 would use w[0], not w[3]
    // Let's think about this more carefully...
    
    printf("\n=== What if causal conv uses w[0] at position 0? ===\n");
    printf("If the convolution is: out[t] = sum_k(w[k] * x[t-k])\n");
    printf("At t=0 with x[-3..-1]=0, x[0]=qkv:\n");
    printf("  out = w[0]*x[0] + w[1]*x[-1] + w[2]*x[-2] + w[3]*x[-3]\n");
    printf("  out = w[0]*qkv (since x[-1], x[-2], x[-3] are 0 or padded)\n");
    printf("\nw[0] for channel 0: %.6f\n", gdn_conv[0]);
    printf("w[0] for channel 1: %.6f\n", gdn_conv[4]);
    
    safetensors_close(sf);
    return 0;
}