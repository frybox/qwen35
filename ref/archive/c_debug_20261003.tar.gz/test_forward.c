#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

// Minimal test of forward pass components

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) { printf("Failed to open\n"); return 1; }
    
    // Load embed_norm
    float *embed_norm = malloc(1024 * sizeof(float));
    safetensors_load_tensor_as_f32(sf,
        safetensors_get_tensor(sf, "model.language_model.norm.weight"),
        embed_norm);
    
    printf("embed_norm [0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n",
           embed_norm[0], embed_norm[1], embed_norm[2], embed_norm[3], embed_norm[4]);
    
    // Test RMS norm with some random hidden state
    float x[1024];
    for (int i = 0; i < 1024; i++) x[i] = 0.1f * (i % 10 - 5);  // Values from -0.4 to 0.5
    
    float o[1024];
    rmsnorm(o, x, embed_norm, 1024);
    
    printf("\nInput x [0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n",
           x[0], x[1], x[2], x[3], x[4]);
    printf("Output o [0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n",
           o[0], o[1], o[2], o[3], o[4]);
    
    // Check L2 norms
    float nx = 0, no = 0;
    for (int i = 0; i < 1024; i++) {
        nx += x[i]*x[i];
        no += o[i]*o[i];
    }
    printf("Input L2: %.4f, Output L2: %.4f\n", sqrtf(nx), sqrtf(no));
    
    safetensors_close(sf);
    return 0;
}
