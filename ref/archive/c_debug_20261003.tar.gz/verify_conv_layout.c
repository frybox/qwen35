// Verify the correct Conv1D implementation based on PyTorch's behavior
#include <stdio.h>
#include <math.h>

int main() {
    // PyTorch's causal_conv1d_update does:
    // 1. hidden_states_new = [conv_state, hidden_states]
    // 2. out = F.conv1d(hidden_states_new, weight, ...)
    // 
    // At position 0:
    // - conv_state = [0, 0, 0, 0] (initially zeros)
    // - hidden_states = [x0]
    // - hidden_states_new = [0, 0, 0, 0, x0]
    //
    // F.conv1d with kernel_size=4:
    // For output at position 0 (from input [0, 0, 0, 0, x0]):
    // - The kernel sees input window: [0, 0, 0, x0] (last 4 elements)
    // - out = w[0]*0 + w[1]*0 + w[2]*0 + w[3]*x0 = w[3]*x0
    //
    // So at position 0, w[3] applies to the newest value!
    
    printf("=== PyTorch Conv1D behavior at position 0 ===\n\n");
    
    float w[4] = {-0.000161, 0.000404, -0.003387, -0.074219};
    float x0 = -0.089683;
    
    // PyTorch's behavior
    float pytorch_out = w[3] * x0;
    printf("PyTorch style: w[3] * x0 = %.6f * %.6f = %.6f\n", w[3], x0, pytorch_out);
    
    // C code current (after my fix)
    float c_current = w[0] * x0;  // Using cw[3-k] with k=3 for newest
    printf("C code (after fix): w[0] * x0 = %.6f * %.6f = %.6f\n", w[0], x0, c_current);
    
    // C code original (before my fix)
    float c_original = w[3] * x0;  // Using cw[k] with k=3 for newest
    printf("C code (original): w[3] * x0 = %.6f * %.6f = %.6f\n", w[3], x0, c_original);
    
    printf("\n=== CONCLUSION ===\n");
    printf("Original C code (w[3]) matches PyTorch behavior!\n");
    printf("My fix to use cw[3-k] was WRONG!\n");
    printf("The original code was correct.\n");
    
    return 0;
}
