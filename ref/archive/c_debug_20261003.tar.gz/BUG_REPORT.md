# GDN Forward Pass Bug Analysis

## Summary

C引擎对token 248045 (`<|im_start|>`) forward后，top-1预测是token 234967，这与预期的token 846 ("user")不符。经过分析，发现以下关键问题：

## Bug 1: gdn_norm 权重越界访问

**文件**: `test_minimal.c` (以及 `qwen35_engine.c`)

**问题描述**:
```c
// 错误代码 (第378行):
out[j] = w->gdn_norm[layer][j] * ss * out[j] * silu(zh[j]);
```

**根本原因**:
- `gdn_norm` 的shape是 `[128]`，不是 `[16*128]`
- 所有16个head共享同一个norm权重
- 代码中使用了错误的索引 `gdn_norm[h * vd + j]` 导致越界访问
- 对于 head 9、13、14、15，越界访问到了垃圾值（如 `67422187560263187693568.0000`）

**修复**:
```c
// 正确代码:
out[j] = w->gdn_norm[layer][j] * ss * out[j] * silu(zh[j]);  // j 范围 0-127
```

## Bug 2: Conv1D 权重应用问题

**问题描述**:
- Conv1D 权重很小（约 0.01-0.1 级别）
- 当前实现在位置0时将QKV值缩小了约10-100倍
- 导致信号过弱

**当前行为**:
```
QKV before conv: Q[0] = -0.089683
QKV after conv:  Q[0] = 0.006656  (缩小了~13倍)
```

**可能原因**:
1. Conv1D权重顺序错误（w[3]应该是w[0]）
2. 或者在位置0应该跳过conv

## Bug 3: Decay公式问题

**当前实现**:
```c
float sp = logf(1.0f + expf(a + dt_bias[h]));  // softplus(a + dt)
float g = -expf(A_log[h]) * sp;
float gamma = expf(g);
```

**问题**:
- 对于head 0: `gamma = 0.033591`，这意味着97%的状态被遗忘
- 这对于语言模型来说太激进了

**修复建议**:
```c
float sp = logf(1.0f + expf(a - dt_bias[h]));  // softplus(a - dt)
```
- 修复后: `gamma = 0.907023`，更合理

## 验证结果

### C引擎输出（原始）:
```
Top-5 token predictions:
  #1: token_id=234967, logit=9.4084
  #2: token_id=63890, logit=9.3505
```

### 修复后的GDN输出:
```
Final output norm: 0.8806
After residual: norm=8.5478
```

## 中间值对比

| 步骤 | Python参考值 | C引擎值 | 状态 |
|------|-------------|---------|------|
| Embedding[248045][0:4] | [0.0143, 0.0088, -0.0082, -0.0056] | 相同 | ✓ |
| Layernorm[0:4] | [0.8643, 0.1569, -0.2649, -0.2535] | 相同 | ✓ |
| QKV[0:4] (before conv) | [-0.0897, -0.0819, 0.1539, -0.3008] | 相同 | ✓ |
| QKV[0:4] (after conv) | [0.0067, 0.0005, 0.0006, -0.0693] | 问题 | ✗ |
| gdn_norm[0:4] | [0.9631, 0.9902, 0.9277, 0.9243] | 正确加载 | ✓ |
| gdn_norm[14*128+0] | 垃圾值 | 访问越界 | ✗ |

## 修复优先级

1. **高优先级**: 修复 `gdn_norm` 越界访问（这是导致head爆炸的直接原因）
2. **中优先级**: 检查 Conv1D 实现是否正确
3. **需验证**: Decay公式的正确性（需要与PyTorch参考对比）

## 下一步建议

1. 用PyTorch加载模型，验证decay公式的正确性
2. 检查HuggingFace Transformers中Qwen3.5的GDN实现
3. 对比完整的forward pass输出