#!/usr/bin/env python3
"""Minimal verification - embedding and layernorm only, no large loads."""
import numpy as np
import struct
import json

def load_single_tensor_range(path, name):
    """Load just one tensor from safetensors using memory mapping."""
    with open(path, 'rb') as f:
        header_size = struct.unpack('<Q', f.read(8))[0]
        header = f.read(header_size).decode('utf-8')
        meta = json.loads(header)
        
        if name not in meta:
            return None, meta
        
        info = meta[name]
        start, end = info['data_offsets']
        f.seek(8 + header_size + start)
        data = f.read(end - start)
        
        if info['dtype'] == 'BF16':
            bf16 = np.frombuffer(data, dtype=np.uint16)
            fp32 = (bf16.astype(np.uint32) << 16).view(np.float32)
            return fp32.reshape(info['shape']), meta
        elif info['dtype'] == 'F32':
            return np.frombuffer(data, dtype=np.float32).reshape(info['shape']), meta
        return None, meta

path = '/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors'

# Load embedding for token 248045
print("Loading embedding tensor...")
embed, meta = load_single_tensor_range(path, 'model.language_model.embed_tokens.weight')
print(f"Embed shape: {embed.shape}")

token_id = 248045
x = embed[token_id].copy()
print(f"\n=== Token {token_id} Embedding ===")
print(f"Norm: {np.linalg.norm(x):.6f}")
print(f"First 10: {x[:10]}")
print(f"Last 10: {x[-10:]}")
print(f"Mean: {np.mean(x):.6f}, Std: {np.std(x):.6f}, Min: {np.min(x):.6f}, Max: {np.max(x):.6f}")

# Load layer 0 layernorm
ln0, _ = load_single_tensor_range(path, 'model.language_model.layers.0.input_layernorm.weight')
print(f"\nLN0 shape: {ln0.shape}")
print(f"LN0 first 10: {ln0[:10]}")
print(f"LN0 mean: {np.mean(ln0):.6f}")

# Apply RMSNorm
def rmsnorm(x, w, eps=1e-6):
    variance = np.mean(x ** 2)
    return w * x / np.sqrt(variance + eps)

x1 = rmsnorm(x, ln0)
print(f"\n=== After RMSNorm ===")
print(f"Norm: {np.linalg.norm(x1):.6f}")
print(f"First 10: {x1[:10]}")
print(f"Last 10: {x1[-10:]}")
print(f"Mean: {np.mean(x1):.6f}, Std: {np.std(x1):.6f}")

# Verify formula step by step
variance = np.mean(x ** 2)
rms = np.sqrt(variance + 1e-6)
x_normed = x / rms
print(f"\n=== RMSNorm Verification ===")
print(f"Input variance: {variance:.6f}")
print(f"RMS: {rms:.6f}")
print(f"1/RMS: {1/rms:.6f}")
print(f"x_normed first 10: {x_normed[:10]}")

# Load QKV weight
qkv_w, _ = load_single_tensor_range(path, 'model.language_model.layers.0.linear_attn.in_proj_qkv.weight')
print(f"\nQKV weight shape: {qkv_w.shape}")
print(f"QKV weight first row: {qkv_w[0, :5]}")

# QKV projection
qkv = qkv_w @ x1
print(f"\n=== QKV Projection ===")
print(f"QKV shape: {qkv.shape}")
print(f"QKV norm: {np.linalg.norm(qkv):.6f}")
print(f"QKV first 10: {qkv[:10]}")

# Split
q = qkv[:2048]
k = qkv[2048:4096]
v = qkv[4096:]
print(f"\nQ first 5: {q[:5]}")
print(f"K first 5: {k[:5]}")
print(f"V first 5: {v[:5]}")
print(f"Q norm: {np.linalg.norm(q):.6f}")
print(f"K norm: {np.linalg.norm(k):.6f}")
print(f"V norm: {np.linalg.norm(v):.6f}")

# Load A_log and dt_bias
A_log, _ = load_single_tensor_range(path, 'model.language_model.layers.0.linear_attn.A_log')
dt_bias, _ = load_single_tensor_range(path, 'model.language_model.layers.0.linear_attn.dt_bias')
print(f"\n=== GDN Parameters ===")
print(f"A_log: {A_log}")
print(f"dt_bias: {dt_bias}")
print(f"exp(A_log): {np.exp(A_log)}")

# Compute gamma with formula from C code
print(f"\n=== Decay Computation (from C code) ===")
for h in range(4):
    A = A_log[h]
    dt = dt_bias[h]
    # Assume a=0 for first test
    a = 0.0
    sp = np.log(1 + np.exp(a + dt))
    g = -np.exp(A) * sp
    gamma = np.exp(g)
    print(f"Head {h}: A_log={A:.4f}, dt={dt:.4f}, softplus={sp:.4f}, g={g:.4f}, gamma={gamma:.6f}")

# Try alternative formula
print(f"\n=== Alternative: softplus(a - dt_bias) ===")
for h in range(4):
    A = A_log[h]
    dt = dt_bias[h]
    a = 0.0
    sp = np.log(1 + np.exp(a - dt))
    g = -np.exp(A) * sp
    gamma = np.exp(g)
    print(f"Head {h}: A_log={A:.4f}, dt={dt:.4f}, softplus={sp:.4f}, g={g:.4f}, gamma={gamma:.6f}")

print("\n=== Summary for C comparison ===")
print(f"Python embedding[248045][:10] = {x[:10]}")
print(f"Python layernorm output[:10] = {x1[:10]}")
print(f"Python Q[:5] = {q[:5]}")
print(f"Python K[:5] = {k[:5]}")
print(f"Python V[:5] = {v[:5]}")