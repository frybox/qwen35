#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "safetensors.h"

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <safetensors_file>\n", argv[0]);
        return 1;
    }
    
    SafetensorsFile *sf = safetensors_open(argv[1]);
    if (!sf) {
        fprintf(stderr, "Failed to open safetensors file\n");
        return 1;
    }
    
    printf("Data start offset: %ld\n", sf->data_start);
    
    // Find A_log tensor
    TensorMeta *tm = safetensors_get_tensor(sf, "model.language_model.layers.0.linear_attn.A_log");
    if (tm) {
        printf("Found: %s\n", tm->name);
        printf("  dtype: %d, ndim: %d\n", tm->dtype, tm->ndim);
        printf("  data_offset: %ld, data_size: %ld\n", tm->data_offset, tm->data_size);
        
        // Read and print values
        float *data = malloc(tm->data_size);
        fseek(sf->fp, tm->data_offset, SEEK_SET);
        fread(data, 1, tm->data_size, sf->fp);
        
        printf("  values: ");
        int n = tm->data_size / sizeof(float);
        for (int i = 0; i < n && i < 16; i++) {
            printf("%.6f ", data[i]);
        }
        printf("\n");
        free(data);
    }
    
    safetensors_close(sf);
    return 0;
}
