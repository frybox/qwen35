// Test layer by layer to find where output goes wrong
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { return calloc(n, 1); }
float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) return NULL;
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}
void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    float *embed = load_tensor_f32(sf, "model.language_model.embed_tokens.weight");
    float *ln0 = load_tensor_f32(sf, "model.language_model.layers.0.input_layernorm.weight");
    
    float *x = embed + 248045 * 1024;
    printf("Input embedding norm: %.4f\n", sqrtf(x[0]*x[0] + x[1]*x[1] + x[2]*x[2] + x[3]*x[3]));
    
    float *x1 = xmalloc(1024 * sizeof(float));
    rmsnorm(x1, x, ln0, 1024);
    printf("After LN0 norm (first 4): %.4f\n", sqrtf(x1[0]*x1[0] + x1[1]*x1[1] + x1[2]*x1[2] + x1[3]*x1[3]));
    printf("x1[0:4]: %.4f %.4f %.4f %.4f\n", x1[0], x1[1], x1[2], x1[3]);
    
    // Compute logits directly from x (skip all layers)
    printf("\nDirect logits from embedding (no layers):\n");
    float logits[5] = {0};
    for (int t = 0; t < 5; t++) {
        for (int i = 0; i < 1024; i++) logits[t] += embed[t * 1024 + i] * x[i];
    }
    printf("Logits for tokens 0-4: %.4f %.4f %.4f %.4f %.4f\n", logits[0], logits[1], logits[2], logits[3], logits[4]);
    
    // Check token 846 ("user")
    float logit_846 = 0;
    for (int i = 0; i < 1024; i++) logit_846 += embed[846 * 1024 + i] * x[i];
    printf("Logit for token 846 (\"user\"): %.4f\n", logit_846);
    
    safetensors_close(sf);
    return 0;
}
