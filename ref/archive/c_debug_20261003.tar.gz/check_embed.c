#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "safetensors.h"

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) { printf("Failed to open\n"); return 1; }
    
    // Get embedding tensor
    TensorMeta *embed = safetensors_get_tensor(sf, "model.language_model.embed_tokens.weight");
    if (!embed) { printf("Failed to get embed\n"); return 1; }
    
    printf("Embedding shape: [%ld, %ld]\n", (long)embed->shape[0], (long)embed->shape[1]);
    printf("Embedding dtype: %d\n", embed->dtype);
    
    // Load embeddings for tokens 198, 74455 (assistant), 248045 (<|im_start|>)
    int tokens[] = {198, 74455, 248045, 12162};  // \n, assistant, <|im_start|>, Once
    int n_tokens = 4;
    int dim = embed->shape[1];  // 1024
    
    float *data = malloc(n_tokens * dim * sizeof(float));
    
    // Load each token's embedding
    for (int t = 0; t < n_tokens; t++) {
        TensorMeta meta = *embed;
        meta.data_offset = embed->data_offset + tokens[t] * dim * 2;  // BF16 = 2 bytes
        meta.data_size = dim * 2;
        
        // Read as BF16 and convert
        uint16_t *tmp = malloc(dim * 2);
        fseek(sf->fp, 8 + sf->metadata_len + meta.data_offset, SEEK_SET);
        fread(tmp, 1, dim * 2, sf->fp);
        
        // BF16 to FP32
        for (int i = 0; i < dim; i++) {
            uint32_t val = ((uint32_t)tmp[i]) << 16;
            memcpy(&data[t * dim + i], &val, sizeof(float));
        }
        free(tmp);
    }
    
    // Compare embeddings
    printf("\n=== Token Embedding Comparison ===\n");
    for (int t = 0; t < n_tokens; t++) {
        float norm = 0;
        for (int i = 0; i < dim; i++) norm += data[t*dim + i] * data[t*dim + i];
        printf("Token %d: L2 norm = %.4f, first 4 = [%.4f, %.4f, %.4f, %.4f]\n",
               tokens[t], sqrtf(norm), 
               data[t*dim], data[t*dim+1], data[t*dim+2], data[t*dim+3]);
    }
    
    // Check cosine similarity between tokens
    printf("\n=== Cosine Similarity ===\n");
    for (int i = 0; i < n_tokens; i++) {
        for (int j = i+1; j < n_tokens; j++) {
            float dot = 0, ni = 0, nj = 0;
            for (int k = 0; k < dim; k++) {
                dot += data[i*dim + k] * data[j*dim + k];
                ni += data[i*dim + k] * data[i*dim + k];
                nj += data[j*dim + k] * data[j*dim + k];
            }
            float cos = dot / (sqrtf(ni) * sqrtf(nj));
            printf("token %d vs %d: cos = %.4f\n", tokens[i], tokens[j], cos);
        }
    }
    
    safetensors_close(sf);
    free(data);
    return 0;
}
