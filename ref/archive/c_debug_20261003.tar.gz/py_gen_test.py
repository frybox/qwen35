import torch
import json
from transformers import AutoModelForCausalLM, AutoTokenizer

# 直接使用 safetensors 加载
from safetensors import safe_open

print("Loading model...")
model = AutoModelForCausalLM.from_pretrained(
    '/mnt/Qwen3.5-0.8B', 
    torch_dtype=torch.float32,
    device_map='cpu',
    trust_remote_code=True
)
tokenizer = AutoTokenizer.from_pretrained('/mnt/Qwen3.5-0.8B', trust_remote_code=True)

prompt = '<|im_start|>user\nWhat is 2+2?<|im_end|>\n<|im_start|>assistant\n'
inputs = tokenizer(prompt, return_tensors='pt')
print(f"Input IDs: {inputs['input_ids'][0].tolist()}")

with torch.no_grad():
    outputs = model.generate(
        inputs['input_ids'],
        max_new_tokens=20,
        do_sample=False,
        pad_token_id=tokenizer.eos_token_id
    )

print(f"\nGenerated tokens: {outputs[0].tolist()}")
print(f"\nGenerated text:\n{tokenizer.decode(outputs[0])}")
