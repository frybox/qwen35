/*
 * Fixed GDN forward with correct norm weight usage
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { void *p = calloc(n, 1); if (!p) { fprintf(stderr, "malloc failed\n"); exit(1); } return p; }

float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) return NULL;
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

float silu(float x) { return x / (1.0f + expf(-x)); }

int main() {
    const char *path = "/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors";
    SafetensorsFile *sf = safetensors_open(path);
    
    printf("=== Loading weights ===\n");
    float *embed = load_tensor_f32(sf, "model.language_model.embed_tokens.weight");
    float *ln0 = load_tensor_f32(sf, "model.language_model.layers.0.input_layernorm.weight");
    float *gdn_qkv = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight");
    float *gdn_z = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_z.weight");
    float *gdn_a = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_a.weight");
    float *gdn_b = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_b.weight");
    float *gdn_A = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.A_log");
    float *gdn_dt = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.dt_bias");
    float *gdn_norm = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.norm.weight");
    float *gdn_out = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.out_proj.weight");
    
    printf("gdn_norm shape: [128], NOT [2048] - all heads share the same norm!\n");
    printf("gdn_norm[0:8]: %.4f, %.4f, %.4f, %.4f, %.4f, %.4f, %.4f, %.4f\n",
           gdn_norm[0], gdn_norm[1], gdn_norm[2], gdn_norm[3],
           gdn_norm[4], gdn_norm[5], gdn_norm[6], gdn_norm[7]);
    
    int dim = 1024, nv = 16, kd = 128, vd = 128;
    
    float *x = embed + 248045 * dim;
    float *x1 = xmalloc(dim * sizeof(float));
    rmsnorm(x1, x, ln0, dim);
    
    // QKV projection (no conv)
    float *qkv = xmalloc(6144 * sizeof(float));
    for (int i = 0; i < 6144; i++) {
        float sum = 0;
        for (int j = 0; j < dim; j++) sum += gdn_qkv[i * dim + j] * x1[j];
        qkv[i] = sum;
    }
    
    // Z projection
    float *z = xmalloc(nv * vd * sizeof(float));
    for (int i = 0; i < nv * vd; i++) {
        float sum = 0;
        for (int j = 0; j < dim; j++) sum += gdn_z[i * dim + j] * x1[j];
        z[i] = sum;
    }
    
    // A and B projections
    float *a_proj = xmalloc(nv * sizeof(float));
    float *b_proj = xmalloc(nv * sizeof(float));
    for (int i = 0; i < nv; i++) {
        float sum_a = 0, sum_b = 0;
        for (int j = 0; j < dim; j++) {
            sum_a += gdn_a[i * dim + j] * x1[j];
            sum_b += gdn_b[i * dim + j] * x1[j];
        }
        a_proj[i] = sum_a;
        b_proj[i] = 1.0f / (1.0f + expf(-sum_b));
    }
    
    printf("\n=== GDN Forward (fixed) ===\n");
    
    float *all_out = xmalloc(nv * vd * sizeof(float));
    float *state = calloc(kd * vd, sizeof(float));
    
    for (int h = 0; h < nv; h++) {
        float *q = qkv + h * kd;
        float *k = qkv + nv * kd + h * kd;
        float *v = qkv + 2 * nv * kd + h * kd;
        float *zh = z + h * vd;
        
        // Normalize Q and K
        float qn = 0, kn = 0;
        for (int i = 0; i < kd; i++) { qn += q[i]*q[i]; kn += k[i]*k[i]; }
        qn = 1.0f / sqrtf(qn + 1e-6f);
        kn = 1.0f / sqrtf(kn + 1e-6f);
        for (int i = 0; i < kd; i++) { q[i] *= qn; k[i] *= kn; }
        for (int i = 0; i < kd; i++) q[i] /= sqrtf(kd);
        
        // Decay (using fixed formula: softplus(a - dt))
        float A = gdn_A[h], dt = gdn_dt[h], a = a_proj[h], beta = b_proj[h];
        float sp = logf(1 + expf(a - dt));
        float gamma = expf(-expf(A) * sp);
        
        // At pos 0, state is zero, so:
        // state = outer(k, v * beta)
        // out = state @ q
        
        // delta = v * beta
        float delta[128];
        for (int j = 0; j < vd; j++) delta[j] = v[j] * beta;
        
        // state = outer(k, delta)
        for (int i = 0; i < kd; i++) {
            for (int j = 0; j < vd; j++) {
                state[i * vd + j] = k[i] * delta[j];
            }
        }
        
        // out = state @ q
        float *out_h = all_out + h * vd;
        for (int j = 0; j < vd; j++) {
            for (int i = 0; i < kd; i++) {
                out_h[j] += state[i * vd + j] * q[i];
            }
        }
        
        // Apply output norm and silu
        // FIXED: Use gdn_norm[j], not gdn_norm[h * vd + j]
        float on = 0;
        for (int j = 0; j < vd; j++) on += out_h[j] * out_h[j];
        on = 1.0f / sqrtf(on / vd + 1e-6f);
        for (int j = 0; j < vd; j++) {
            out_h[j] = gdn_norm[j] * on * out_h[j] * silu(zh[j]);  // FIXED: gdn_norm[j] not gdn_norm[h * vd + j]
        }
        
        on = 0;
        for (int j = 0; j < vd; j++) on += out_h[j] * out_h[j];
        printf("Head %d: gamma=%.4f, beta=%.4f, out_norm=%.4f\n", h, gamma, beta, sqrtf(on));
    }
    
    // Output projection
    printf("\n=== Output projection ===\n");
    float *final_out = xmalloc(dim * sizeof(float));
    for (int i = 0; i < dim; i++) {
        float sum = 0;
        for (int j = 0; j < nv * vd; j++) {
            sum += gdn_out[i * nv * vd + j] * all_out[j];
        }
        final_out[i] = sum;
    }
    
    float fn = 0;
    for (int i = 0; i < dim; i++) fn += final_out[i] * final_out[i];
    printf("Final output norm: %.4f\n", sqrtf(fn));
    printf("final_out[0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n",
           final_out[0], final_out[1], final_out[2], final_out[3], final_out[4]);
    
    // Add residual
    printf("\n=== After residual connection ===\n");
    for (int i = 0; i < dim; i++) final_out[i] += x1[i];
    
    fn = 0;
    for (int i = 0; i < dim; i++) fn += final_out[i] * final_out[i];
    printf("Output norm after residual: %.4f\n", sqrtf(fn));
    printf("output[0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n",
           final_out[0], final_out[1], final_out[2], final_out[3], final_out[4]);
    
    printf("\n=== Summary ===\n");
    printf("Key fixes:\n");
    printf("1. gdn_norm shape is [128], shared by all 16 heads\n");
    printf("2. Use gdn_norm[j] not gdn_norm[h * vd + j]\n");
    printf("3. Decay formula: gamma = exp(-exp(A) * softplus(a - dt)) gives better values\n");
    
    safetensors_close(sf);
    return 0;
}