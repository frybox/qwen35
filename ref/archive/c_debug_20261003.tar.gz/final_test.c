#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

float *load_tensor_f32(SafetensorsFile *sf, const char *name, int64_t expected_elems) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) return NULL;
    float *data = calloc(expected_elems, sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}

int main() {
    printf("=== 质量验证测试 ===\n\n");
    
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    float *embed = load_tensor_f32(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    
    // Token 248045 embedding
    float *x = embed + 248045 * 1024;
    
    // 找前5个最高分的token
    printf("无层时前5个token:\n");
    float max_logits[5] = {-1e10, -1e10, -1e10, -1e10, -1e10};
    int max_tokens[5] = {0};
    
    for (int t = 0; t < 5000; t++) {
        float logit = 0;
        for (int i = 0; i < 1024; i++) logit += embed[t * 1024 + i] * x[i];
        
        for (int j = 0; j < 5; j++) {
            if (logit > max_logits[j]) {
                for (int k = 4; k > j; k--) {
                    max_logits[k] = max_logits[k-1];
                    max_tokens[k] = max_tokens[k-1];
                }
                max_logits[j] = logit;
                max_tokens[j] = t;
                break;
            }
        }
    }
    
    for (int j = 0; j < 5; j++) {
        printf("  #%d: token %d, logit=%.4f\n", j+1, max_tokens[j], max_logits[j]);
    }
    
    safetensors_close(sf);
    return 0;
}
