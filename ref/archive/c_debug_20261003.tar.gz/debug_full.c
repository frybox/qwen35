#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { return calloc(n, 1); }
float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) return NULL;
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}
void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}
float silu(float x) { return x / (1.0f + expf(-x)); }

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    float *embed = load_tensor_f32(sf, "model.language_model.embed_tokens.weight");
    float *ln0 = load_tensor_f32(sf, "model.language_model.layers.0.input_layernorm.weight");
    float *gdn_qkv = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight");
    float *gdn_z = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_z.weight");
    float *gdn_a = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_a.weight");
    float *gdn_b = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_b.weight");
    float *gdn_A = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.A_log");
    float *gdn_dt = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.dt_bias");
    float *gdn_norm = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.norm.weight");
    float *gdn_out = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.out_proj.weight");
    
    int dim = 1024, nv = 16, kd = 128, vd = 128;
    
    float *x = embed + 248045 * dim;
    printf("Embedding norm: %.4f\n", sqrtf(dim > 0 ? x[0]*x[0] : 0));
    
    float *x1 = xmalloc(dim * sizeof(float));
    rmsnorm(x1, x, ln0, dim);
    printf("After LN0 norm: %.4f\n", sqrtf(x1[0]*x1[0] + x1[1]*x1[1]));
    
    // Compute QKV
    float *qkv = xmalloc(6144 * sizeof(float));
    for (int i = 0; i < 6144; i++) {
        float sum = 0;
        for (int j = 0; j < dim; j++) sum += gdn_qkv[i * dim + j] * x1[j];
        qkv[i] = sum;
    }
    printf("QKV norm: %.4f\n", sqrtf(qkv[0]*qkv[0] + qkv[1]*qkv[1]));
    
    // Compute Z
    float *z = xmalloc(nv * vd * sizeof(float));
    for (int i = 0; i < nv * vd; i++) {
        float sum = 0;
        for (int j = 0; j < dim; j++) sum += gdn_z[i * dim + j] * x1[j];
        z[i] = sum;
    }
    printf("Z norm: %.4f\n", sqrtf(z[0]*z[0] + z[1]*z[1]));
    
    // Process each head
    float *out_all = xmalloc(nv * vd * sizeof(float));
    for (int h = 0; h < nv; h++) {
        float *q = qkv + h * kd;
        float *k = qkv + nv * kd + h * kd;
        float *v = qkv + 2 * nv * kd + h * kd;
        float *zh = z + h * vd;
        
        // Norm Q and K
        float qn = 0, kn = 0;
        for (int i = 0; i < kd; i++) { qn += q[i]*q[i]; kn += k[i]*k[i]; }
        qn = 1.0f / sqrtf(qn + 1e-6f);
        kn = 1.0f / sqrtf(kn + 1e-6f);
        for (int i = 0; i < kd; i++) { q[i] *= qn; k[i] *= kn; }
        for (int i = 0; i < kd; i++) q[i] /= sqrtf(kd);
        
        // Get a, b
        float a = 0, b = 0;
        for (int j = 0; j < dim; j++) {
            a += gdn_a[h * dim + j] * x1[j];
            b += gdn_b[h * dim + j] * x1[j];
        }
        b = 1.0f / (1.0f + expf(-b));
        
        // Gamma with FIX: softplus(a - dt)
        float sp = logf(1.0f + expf(a - gdn_dt[h]));
        float g = -expf(gdn_A[h]) * sp;
        float gamma = expf(g);
        
        // Simple state update
        float state[128*128] = {0};
        for (int i = 0; i < kd * vd; i++) state[i] *= gamma;
        
        float kv_mem[128] = {0};
        for (int j = 0; j < vd; j++) {
            for (int i = 0; i < kd; i++) kv_mem[j] += state[i*vd + j] * k[i];
        }
        
        float delta[128];
        for (int j = 0; j < vd; j++) delta[j] = (v[j] - kv_mem[j]) * b;
        
        for (int i = 0; i < kd; i++) {
            for (int j = 0; j < vd; j++) state[i*vd + j] += k[i] * delta[j];
        }
        
        float *out = out_all + h * vd;
        for (int j = 0; j < vd; j++) {
            for (int i = 0; i < kd; i++) out[j] += state[i*vd + j] * q[i];
        }
        
        // Apply norm and silu - FIXED: all heads share same gdn_norm
        float ss = 0;
        for (int j = 0; j < vd; j++) ss += out[j] * out[j];
        ss = 1.0f / sqrtf(ss / vd + 1e-6f);
        for (int j = 0; j < vd; j++) {
            out[j] = gdn_norm[j] * ss * out[j] * silu(zh[j]);
        }
        
        printf("Head %d: gamma=%.4f, beta=%.4f, out[0]=%.4f\n", h, gamma, b, out[0]);
    }
    
    // Output projection
    float final[1024] = {0};
    for (int i = 0; i < dim; i++) {
        for (int j = 0; j < nv * vd; j++) final[i] += gdn_out[i * nv * vd + j] * out_all[j];
    }
    
    float fn = 0;
    for (int i = 0; i < 10; i++) fn += final[i] * final[i];
    printf("\nFinal output[0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n", final[0], final[1], final[2], final[3], final[4]);
    printf("Final output norm (first 10): %.4f\n", sqrtf(fn));
    
    safetensors_close(sf);
    return 0;
}
