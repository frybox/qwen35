#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

int main() {
    // Simulate the final hidden state before logits
    // The problem: hidden[2] = 4.2636 which is unusual
    
    // Let's check what the RMS norm does to typical values
    float hidden[1024];
    float norm_w[1024];
    float output[1024];
    
    // Initialize hidden state with reasonable values
    for (int i = 0; i < 1024; i++) {
        hidden[i] = 0.1f * ((i % 20) - 10);  // Values from -1.0 to 1.0
    }
    
    // Initialize norm weights with typical values (close to 1.0)
    for (int i = 0; i < 1024; i++) {
        norm_w[i] = 1.0f;
    }
    
    rmsnorm(output, hidden, norm_w, 1024);
    
    // Check output
    float norm_in = 0, norm_out = 0;
    for (int i = 0; i < 1024; i++) {
        norm_in += hidden[i] * hidden[i];
        norm_out += output[i] * output[i];
    }
    
    printf("Input L2: %.4f, Output L2: %.4f\n", sqrtf(norm_in), sqrtf(norm_out));
    printf("Input [0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n",
           hidden[0], hidden[1], hidden[2], hidden[3], hidden[4]);
    printf("Output [0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n",
           output[0], output[1], output[2], output[3], output[4]);
    
    // Now check with the actual model's norm weights
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (sf) {
        float *model_norm = malloc(1024 * sizeof(float));
        safetensors_load_tensor_as_f32(sf,
            safetensors_get_tensor(sf, "model.language_model.norm.weight"),
            model_norm);
        
        printf("\nWith model's actual norm weights:\n");
        printf("Norm weights [0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n",
               model_norm[0], model_norm[1], model_norm[2], model_norm[3], model_norm[4]);
        
        rmsnorm(output, hidden, model_norm, 1024);
        printf("Output [0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n",
               output[0], output[1], output[2], output[3], output[4]);
        
        norm_out = 0;
        for (int i = 0; i < 1024; i++) norm_out += output[i] * output[i];
        printf("Output L2: %.4f\n", sqrtf(norm_out));
        
        safetensors_close(sf);
    }
    
    return 0;
}
