/*
 * Test correct Conv1D implementation for causal convolution
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { void *p = calloc(n, 1); if (!p) { fprintf(stderr, "malloc failed\n"); exit(1); } return p; }

float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) return NULL;
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

int main() {
    const char *path = "/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors";
    SafetensorsFile *sf = safetensors_open(path);
    
    float *embed = load_tensor_f32(sf, "model.language_model.embed_tokens.weight");
    float *ln0 = load_tensor_f32(sf, "model.language_model.layers.0.input_layernorm.weight");
    float *gdn_qkv = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight");
    float *gdn_conv = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.conv1d.weight");
    float *gdn_A = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.A_log");
    float *gdn_dt = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.dt_bias");
    
    int dim = 1024;
    float *x = embed + 248045 * dim;
    float *x1 = xmalloc(dim * sizeof(float));
    rmsnorm(x1, x, ln0, dim);
    
    float *qkv = xmalloc(6144 * sizeof(float));
    for (int i = 0; i < 6144; i++) {
        float sum = 0;
        for (int j = 0; j < dim; j++) sum += gdn_qkv[i * dim + j] * x1[j];
        qkv[i] = sum;
    }
    
    printf("=== QKV before conv ===\n");
    printf("Q[0:5]: %.6f, %.6f, %.6f, %.6f, %.6f\n", qkv[0], qkv[1], qkv[2], qkv[3], qkv[4]);
    
    // WRONG: Current C implementation
    printf("\n=== WRONG: Current C (shift then store) ===\n");
    float state_wrong[6144][4] = {0};
    float *qkv_wrong = xmalloc(6144 * sizeof(float));
    for (int ch = 0; ch < 6144; ch++) {
        state_wrong[ch][0] = state_wrong[ch][1];
        state_wrong[ch][1] = state_wrong[ch][2];
        state_wrong[ch][2] = state_wrong[ch][3];
        state_wrong[ch][3] = qkv[ch];
        float sum = 0;
        for (int k = 0; k < 4; k++) sum += state_wrong[ch][k] * gdn_conv[ch * 4 + k];
        qkv_wrong[ch] = sum;
    }
    printf("Q after wrong conv[0:5]: %.6f, %.6f, %.6f, %.6f, %.6f\n",
           qkv_wrong[0], qkv_wrong[1], qkv_wrong[2], qkv_wrong[3], qkv_wrong[4]);
    printf("Q norm: %.6f\n", sqrtf(qkv_wrong[0]*qkv_wrong[0] + qkv_wrong[1]*qkv_wrong[1] + qkv_wrong[2]*qkv_wrong[2]));
    
    // CORRECT: Causal conv with proper ordering
    // For causal conv: out[t] = w[0]*x[t] + w[1]*x[t-1] + w[2]*x[t-2] + w[3]*x[t-3]
    // At position 0: out = w[0]*x[0] (rest are padded with 0)
    // The key insight: the weight order might be reversed in the file!
    printf("\n=== Test: Reversed weight order ===\n");
    float *qkv_fixed = xmalloc(6144 * sizeof(float));
    for (int ch = 0; ch < 6144; ch++) {
        // Use reversed weight: w[3], w[2], w[1], w[0]
        // At pos 0, state = [0, 0, 0, qkv], so out = w[3]*qkv
        // But we want out = w_original[0]*qkv
        // If w_stored[k] = w_original[3-k], then w_stored[3] = w_original[0]
        // So the current code using w[3] is correct if weights are stored reversed!
        
        // Let's check both possibilities
        float out_normal = qkv[ch] * gdn_conv[ch * 4 + 0];  // w[0]
        float out_reversed = qkv[ch] * gdn_conv[ch * 4 + 3];  // w[3]
        qkv_fixed[ch] = out_reversed;  // Current implementation
    }
    printf("Q with current (w[3]) [0:5]: %.6f, %.6f, %.6f, %.6f, %.6f\n",
           qkv_fixed[0], qkv_fixed[1], qkv_fixed[2], qkv_fixed[3], qkv_fixed[4]);
    
    // Test with w[0]
    for (int ch = 0; ch < 6144; ch++) {
        qkv_fixed[ch] = qkv[ch] * gdn_conv[ch * 4 + 0];
    }
    printf("Q with w[0] [0:5]: %.6f, %.6f, %.6f, %.6f, %.6f\n",
           qkv_fixed[0], qkv_fixed[1], qkv_fixed[2], qkv_fixed[3], qkv_fixed[4]);
    printf("Q norm: %.6f\n", sqrtf(qkv_fixed[0]*qkv_fixed[0] + qkv_fixed[1]*qkv_fixed[1] + qkv_fixed[2]*qkv_fixed[2]));
    
    // Test: Don't use conv at all at position 0
    printf("\n=== Test: Skip conv at position 0 ===\n");
    printf("Q without conv [0:5]: %.6f, %.6f, %.6f, %.6f, %.6f\n",
           qkv[0], qkv[1], qkv[2], qkv[3], qkv[4]);
    printf("Q norm: %.6f\n", sqrtf(qkv[0]*qkv[0] + qkv[1]*qkv[1] + qkv[2]*qkv[2]));
    
    // Let's also check the decay formula
    printf("\n=== Decay formula test ===\n");
    printf("If we use the WRONG small QKV values:\n");
    float A = gdn_A[0];
    float dt = gdn_dt[0];
    float gamma = expf(-expf(A) * logf(1 + expf(0 + dt)));
    printf("gamma with a=0: %.6f (very small decay!)\n", gamma);
    
    printf("\n=== The core problem ===\n");
    printf("1. Conv1D is attenuating QKV by ~10-100x\n");
    printf("2. This makes the signal very weak\n");
    printf("3. The gamma decay is also very aggressive (gamma~0.03)\n");
    printf("4. Combined, this destroys information at position 0\n");
    
    printf("\n=== Possible fixes ===\n");
    printf("A. Fix Conv1D weight ordering\n");
    printf("B. Fix Conv1D state initialization\n");
    printf("C. Fix decay formula (dt_bias sign?)\n");
    
    safetensors_close(sf);
    return 0;
}