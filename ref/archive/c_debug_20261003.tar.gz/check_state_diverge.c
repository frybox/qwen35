// Check if GDN state diverges
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    if (!m) return NULL;
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

int layer_types[24] = {0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1};

int main() {
    printf("=== GDN State Divergence Check ===\n\n");
    
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    
    // Load layer 0 GDN weights
    float *ln1 = load_tensor(sf, "model.language_model.layers.0.input_layernorm.weight", 1024);
    float *gdn_A = load_tensor(sf, "model.language_model.layers.0.linear_attn.A_log", 16);
    float *gdn_dt = load_tensor(sf, "model.language_model.layers.0.linear_attn.dt_bias", 16);
    
    // Check decay parameters
    printf("GDN Head decay analysis:\n");
    for (int h = 0; h < 16; h++) {
        float A = gdn_A[h];
        float dt = gdn_dt[h];
        
        // At different positions, compute gamma
        for (int pos = 0; pos < 10; pos++) {
            float a = 0;  // Simplified
            float sp = logf(1.0f + expf(a + dt));
            float g = -expf(A) * sp;
            float gamma = expf(g);
            
            if (h < 4 && pos < 5) {
                printf("  Head %d, pos %d: A=%.4f, gamma=%.6f\n", h, pos, A, gamma);
            }
        }
    }
    
    // Test state growth
    printf("\nState growth test:\n");
    float state[16][128*128] = {0};
    
    // Initialize state with small random values
    for (int h = 0; h < 16; h++) {
        for (int i = 0; i < 128*128; i++) {
            state[h][i] = 0.01f;  // Small initial state
        }
    }
    
    // Simulate multiple updates
    float x_norm[1024] = {0.1f};  // Simple input
    for (int step = 0; step < 20; step++) {
        for (int h = 0; h < 16; h++) {
            float *sh = state[h];
            float gamma = expf(-expf(gdn_A[h]) * logf(1.0f + expf(gdn_dt[h])));
            
            // Decay
            for (int i = 0; i < 128*128; i++) sh[i] *= gamma;
            
            // Simulate update with small k, v
            for (int i = 0; i < 128; i++) {
                for (int j = 0; j < 128; j++) {
                    sh[i*128 + j] += 0.01f * 0.01f;  // k * v
                }
            }
            
            if (h == 0) {
                float norm = 0;
                for (int i = 0; i < 128*128; i++) norm += sh[i] * sh[i];
                printf("  Step %d, Head 0 state L2: %.4f\n", step, sqrtf(norm));
            }
        }
    }
    
    safetensors_close(sf);
    return 0;
}
