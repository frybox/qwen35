/*
 * Test different decay formulas to find the correct one
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { void *p = calloc(n, 1); if (!p) { fprintf(stderr, "malloc failed\n"); exit(1); } return p; }

float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) return NULL;
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}

int main() {
    const char *path = "/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors";
    SafetensorsFile *sf = safetensors_open(path);
    
    float *gdn_A = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.A_log");
    float *gdn_dt = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.dt_bias");
    
    printf("=== GDN Layer 0 Parameters ===\n");
    printf("A_log: ");
    for (int i = 0; i < 16; i++) printf("%.4f ", gdn_A[i]);
    printf("\n");
    printf("dt_bias: ");
    for (int i = 0; i < 16; i++) printf("%.4f ", gdn_dt[i]);
    printf("\n");
    
    printf("\n=== Testing decay formulas for all 16 heads ===\n");
    
    // Formula 1: gamma = exp(-exp(A) * softplus(a + dt))
    printf("\nFormula 1: gamma = exp(-exp(A) * softplus(a + dt))\n");
    printf("With a=0:\n");
    for (int h = 0; h < 16; h++) {
        float A = gdn_A[h];
        float dt = gdn_dt[h];
        float sp = logf(1 + expf(0 + dt));
        float gamma = expf(-expf(A) * sp);
        printf("  h%d: gamma=%.6f\n", h, gamma);
    }
    
    // Formula 2: gamma = exp(-exp(A) * softplus(a - dt))
    printf("\nFormula 2: gamma = exp(-exp(A) * softplus(a - dt))\n");
    printf("With a=0:\n");
    for (int h = 0; h < 16; h++) {
        float A = gdn_A[h];
        float dt = gdn_dt[h];
        float sp = logf(1 + expf(0 - dt));
        float gamma = expf(-expf(A) * sp);
        printf("  h%d: gamma=%.6f\n", h, gamma);
    }
    
    // Formula 3: gamma = exp(-exp(A) * dt) (direct dt, no softplus)
    printf("\nFormula 3: gamma = exp(-exp(A) * dt)\n");
    for (int h = 0; h < 16; h++) {
        float A = gdn_A[h];
        float dt = gdn_dt[h];
        float gamma = expf(-expf(A) * dt);
        printf("  h%d: gamma=%.6f\n", h, gamma);
    }
    
    // Formula 4: gamma = exp(-exp(A - dt))
    printf("\nFormula 4: gamma = exp(-exp(A - dt))\n");
    for (int h = 0; h < 16; h++) {
        float A = gdn_A[h];
        float dt = gdn_dt[h];
        float gamma = expf(-expf(A - dt));
        printf("  h%d: gamma=%.6f\n", h, gamma);
    }
    
    // Formula 5: gamma = exp(-exp(A) * softplus(dt))
    printf("\nFormula 5: gamma = exp(-exp(A) * softplus(dt)) (from Mamba paper)\n");
    for (int h = 0; h < 16; h++) {
        float A = gdn_A[h];
        float dt = gdn_dt[h];
        float sp = logf(1 + expf(dt));
        float gamma = expf(-expf(A) * sp);
        printf("  h%d: gamma=%.6f\n", h, gamma);
    }
    
    // Formula 6: Using negative dt
    printf("\nFormula 6: gamma = exp(-exp(A) * softplus(-dt))\n");
    for (int h = 0; h < 16; h++) {
        float A = gdn_A[h];
        float dt = gdn_dt[h];
        float sp = logf(1 + expf(-dt));
        float gamma = expf(-expf(A) * sp);
        printf("  h%d: gamma=%.6f\n", h, gamma);
    }
    
    printf("\n=== Looking for gamma close to 1.0 ===\n");
    printf("For language modeling at position 0, we want minimal decay.\n");
    printf("gamma close to 1.0 means state is preserved.\n");
    printf("gamma close to 0.0 means state is forgotten.\n");
    
    // Calculate mean gamma for each formula
    float mean1 = 0, mean2 = 0, mean5 = 0, mean6 = 0;
    for (int h = 0; h < 16; h++) {
        float A = gdn_A[h], dt = gdn_dt[h];
        mean1 += expf(-expf(A) * logf(1 + expf(dt)));
        mean2 += expf(-expf(A) * logf(1 + expf(-dt)));
        mean5 += expf(-expf(A) * logf(1 + expf(dt)));
        mean6 += expf(-expf(A) * logf(1 + expf(-dt)));
    }
    printf("Mean gamma: formula1=%.4f, formula2=%.4f, formula6=%.4f\n", mean1/16, mean2/16, mean6/16);
    
    safetensors_close(sf);
    return 0;
}