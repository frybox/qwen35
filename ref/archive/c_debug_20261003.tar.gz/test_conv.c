// Test Conv1D behavior with repeated tokens
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    if (!m) return NULL;
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

int main() {
    printf("=== Conv1D Test ===\n\n");
    
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    float *ln1 = load_tensor(sf, "model.language_model.layers.0.input_layernorm.weight", 1024);
    float *gdn_qkv = load_tensor(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight", 6144 * 1024);
    float *gdn_conv = load_tensor(sf, "model.language_model.layers.0.linear_attn.conv1d.weight", 6144 * 4);
    
    // Initialize conv state
    float conv_state[6144*4] = {0};
    
    // Process same token 3 times
    for (int pos = 0; pos < 3; pos++) {
        float x_norm[1024];
        // Use embedding of token 198
        int token = 198;
        // Apply simple norm (approximation)
        float *emb = embed + token * 1024;
        float ss = 0;
        for (int i = 0; i < 1024; i++) ss += emb[i] * emb[i];
        ss = 1.0f / sqrtf(ss / 1024 + 1e-6f);
        for (int i = 0; i < 1024; i++) x_norm[i] = ln1[i] * ss * emb[i];
        
        float qkv[6144];
        matmul(qkv, gdn_qkv, x_norm, 1024, 6144);
        
        printf("Pos %d:\n", pos);
        printf("  Before conv, qkv[0:4]: %.4f, %.4f, %.4f, %.4f\n", qkv[0], qkv[1], qkv[2], qkv[3]);
        
        // Conv1D
        for (int i = 0; i < 6144; i++) {
            float *cs = conv_state + i * 4;
            float *cw = gdn_conv + i * 4;
            cs[0] = cs[1]; cs[1] = cs[2]; cs[2] = cs[3]; cs[3] = qkv[i];
            float sum = 0;
            for (int k = 0; k < 4; k++) sum += cs[k] * cw[k];
            qkv[i] = sum;
        }
        
        printf("  After conv, qkv[0:4]: %.4f, %.4f, %.4f, %.4f\n", qkv[0], qkv[1], qkv[2], qkv[3]);
    }
    
    safetensors_close(sf);
    return 0;
}
