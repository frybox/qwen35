// Debug forward: check values at each step
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"
#include "tokenizer.h"

#define DIM 1024

extern float *load_tensor_f32(SafetensorsFile *sf, const char *name, int expected_size);

int main() {
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    if (!sf) return 1;
    
    float *embed = load_tensor_f32(sf, "model.language_model.embed_tokens.weight", 248320 * DIM);
    float *ln1_0 = load_tensor_f32(sf, "model.language_model.layers.0.input_layernorm.weight", DIM);
    
    float x[DIM];
    memcpy(x, embed + 248045 * DIM, DIM * sizeof(float));
    
    printf("Embedding[:5]: %.6f %.6f %.6f %.6f %.6f\n", x[0], x[1], x[2], x[3], x[4]);
    
    // RMSNorm
    float ss = 0;
    for (int i = 0; i < DIM; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / DIM + 1e-6f);
    for (int i = 0; i < DIM; i++) x[i] = ln1_0[i] * ss * x[i];
    
    printf("After LN1[:5]: %.6f %.6f %.6f %.6f %.6f\n", x[0], x[1], x[2], x[3], x[4]);
    printf("LN1 norm: %.4f\n", sqrtf(ss));
    
    // Load GDN QKV weights
    float *qkv_w = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight", 6144 * DIM);
    
    // Matmul: [6144] = [6144, DIM] @ [DIM]
    float qkv[6144] = {0};
    for (int i = 0; i < 6144; i++) {
        for (int j = 0; j < DIM; j++) {
            qkv[i] += qkv_w[i * DIM + j] * x[j];
        }
    }
    
    printf("QKV[:5]: %.6f %.6f %.6f %.6f %.6f\n", qkv[0], qkv[1], qkv[2], qkv[3], qkv[4]);
    printf("QKV range: %.4f to %.4f\n", 
           -1.0f, 1.0f);  // TODO: compute min/max
    
    safetensors_close(sf);
    return 0;
}
