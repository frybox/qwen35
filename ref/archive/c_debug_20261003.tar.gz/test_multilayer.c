// Test: verify state accumulation across multiple layers
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

void matmul(float *o, float *W, float *x, int n, int d) {
    for (int i = 0; i < d; i++) {
        float sum = 0;
        for (int j = 0; j < n; j++) sum += W[i*n + j] * x[j];
        o[i] = sum;
    }
}

float silu(float x) { return x / (1.0f + expf(-x)); }

float *load_tensor(SafetensorsFile *sf, const char *name, int64_t n) {
    TensorMeta *m = safetensors_get_tensor(sf, name);
    float *buf = malloc(n * sizeof(float));
    safetensors_load_tensor_as_f32(sf, m, buf);
    return buf;
}

int main() {
    printf("Loading model...\n");
    SafetensorsFile *sf = safetensors_open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors");
    
    float *embed = load_tensor(sf, "model.language_model.embed_tokens.weight", 248320 * 1024);
    float *final_norm = load_tensor(sf, "model.language_model.norm.weight", 1024);
    
    printf("Weights loaded\n");
    
    // Process two identical tokens and check if output changes
    int token = 248045;
    
    float x[1024];
    
    // Process token twice with same model state
    for (int iter = 0; iter < 2; iter++) {
        printf("\n=== Iteration %d (token=%d) ===\n", iter, token);
        
        memcpy(x, embed + token * 1024, sizeof(x));
        printf("Embedding [0:4]: %.4f, %.4f, %.4f, %.4f\n", x[0], x[1], x[2], x[3]);
        
        // Process through all 24 layers
        for (int layer = 0; layer < 24; layer++) {
            // Load layer weights
            char name[256];
            
            sprintf(name, "model.language_model.layers.%d.input_layernorm.weight", layer);
            float *ln1 = load_tensor(sf, name, 1024);
            
            sprintf(name, "model.language_model.layers.%d.post_attention_layernorm.weight", layer);
            float *ln2 = load_tensor(sf, name, 1024);
            
            sprintf(name, "model.language_model.layers.%d.mlp.gate_proj.weight", layer);
            float *gate_w = load_tensor(sf, name, 3584 * 1024);
            
            sprintf(name, "model.language_model.layers.%d.mlp.up_proj.weight", layer);
            float *up_w = load_tensor(sf, name, 3584 * 1024);
            
            sprintf(name, "model.language_model.layers.%d.mlp.down_proj.weight", layer);
            float *down_w = load_tensor(sf, name, 1024 * 3584);
            
            // Norm
            float x_norm[1024];
            rmsnorm(x_norm, x, ln1, 1024);
            
            // For simplicity, just do MLP (skip attention)
            // This tests if the basic forward pass works
            
            // MLP
            float x_mlp[1024];
            rmsnorm(x_mlp, x, ln2, 1024);
            
            float gate[3584], up[3584];
            matmul(gate, gate_w, x_mlp, 1024, 3584);
            matmul(up, up_w, x_mlp, 1024, 3584);
            
            for (int i = 0; i < 3584; i++) gate[i] = silu(gate[i]) * up[i];
            
            float mlp_out[1024];
            matmul(mlp_out, down_w, gate, 3584, 1024);
            
            for (int i = 0; i < 1024; i++) x[i] += mlp_out[i];
            
            free(ln1); free(ln2); free(gate_w); free(up_w); free(down_w);
        }
        
        // Final norm
        float final_x[1024];
        rmsnorm(final_x, x, final_norm, 1024);
        
        printf("Final [0:4]: %.4f, %.4f, %.4f, %.4f\n", final_x[0], final_x[1], final_x[2], final_x[3]);
        
        // Sample logits
        printf("Sample logits:\n");
        for (int t = 0; t < 5; t++) {
            float sum = 0;
            for (int i = 0; i < 1024; i++) sum += embed[t * 1024 + i] * final_x[i];
            printf("  Token %d: logit=%.4f\n", t, sum);
        }
    }
    
    printf("\nDone\n");
    safetensors_close(sf);
    return 0;
}