/*
 * Step-by-step debug of GDN with careful overflow checking
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "safetensors.h"

void *xmalloc(size_t n) { void *p = calloc(n, 1); if (!p) { fprintf(stderr, "malloc failed\n"); exit(1); } return p; }

float *load_tensor_f32(SafetensorsFile *sf, const char *name) {
    TensorMeta *meta = safetensors_get_tensor(sf, name);
    if (!meta) return NULL;
    int64_t elems = 1;
    for (int i = 0; i < meta->ndim; i++) elems *= meta->shape[i];
    float *data = xmalloc(elems * sizeof(float));
    safetensors_load_tensor_as_f32(sf, meta, data);
    return data;
}

void rmsnorm(float *o, float *x, float *w, int n) {
    float ss = 0;
    for (int i = 0; i < n; i++) ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / n + 1e-6f);
    for (int i = 0; i < n; i++) o[i] = w[i] * ss * x[i];
}

float silu(float x) { return x / (1.0f + expf(-x)); }

int main() {
    const char *path = "/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors";
    SafetensorsFile *sf = safetensors_open(path);
    
    float *embed = load_tensor_f32(sf, "model.language_model.embed_tokens.weight");
    float *ln0 = load_tensor_f32(sf, "model.language_model.layers.0.input_layernorm.weight");
    float *gdn_qkv = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_qkv.weight");
    float *gdn_z = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_z.weight");
    float *gdn_a = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_a.weight");
    float *gdn_b = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.in_proj_b.weight");
    float *gdn_A = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.A_log");
    float *gdn_dt = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.dt_bias");
    float *gdn_norm = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.norm.weight");
    float *gdn_out = load_tensor_f32(sf, "model.language_model.layers.0.linear_attn.out_proj.weight");
    
    int dim = 1024, nv = 16, kd = 128, vd = 128;
    
    float *x = embed + 248045 * dim;
    float *x1 = xmalloc(dim * sizeof(float));
    rmsnorm(x1, x, ln0, dim);
    
    // QKV projection (no conv for now)
    float *qkv = xmalloc(6144 * sizeof(float));
    for (int i = 0; i < 6144; i++) {
        float sum = 0;
        for (int j = 0; j < dim; j++) sum += gdn_qkv[i * dim + j] * x1[j];
        qkv[i] = sum;
    }
    
    // Z projection
    float *z = xmalloc(nv * vd * sizeof(float));
    for (int i = 0; i < nv * vd; i++) {
        float sum = 0;
        for (int j = 0; j < dim; j++) sum += gdn_z[i * dim + j] * x1[j];
        z[i] = sum;
    }
    
    // A and B projections
    float *a_proj = xmalloc(nv * sizeof(float));
    float *b_proj = xmalloc(nv * sizeof(float));
    for (int i = 0; i < nv; i++) {
        float sum_a = 0, sum_b = 0;
        for (int j = 0; j < dim; j++) {
            sum_a += gdn_a[i * dim + j] * x1[j];
            sum_b += gdn_b[i * dim + j] * x1[j];
        }
        a_proj[i] = sum_a;
        b_proj[i] = 1.0f / (1.0f + expf(-sum_b));
    }
    
    printf("=== A and B projections ===\n");
    printf("a_proj: ");
    for (int i = 0; i < 4; i++) printf("%.4f ", a_proj[i]);
    printf("...\n");
    printf("b_proj: ");
    for (int i = 0; i < 4; i++) printf("%.4f ", b_proj[i]);
    printf("...\n");
    
    // Process head 0 in detail
    printf("\n=== Processing Head 0 ===\n");
    int h = 0;
    float *q = qkv + h * kd;
    float *k = qkv + nv * kd + h * kd;
    float *v = qkv + 2 * nv * kd + h * kd;
    float *zh = z + h * vd;
    
    printf("Q before norm [0:4]: %.6f, %.6f, %.6f, %.6f\n", q[0], q[1], q[2], q[3]);
    printf("K before norm [0:4]: %.6f, %.6f, %.6f, %.6f\n", k[0], k[1], k[2], k[3]);
    printf("V [0:4]: %.6f, %.6f, %.6f, %.6f\n", v[0], v[1], v[2], v[3]);
    printf("Z [0:4]: %.6f, %.6f, %.6f, %.6f\n", zh[0], zh[1], zh[2], zh[3]);
    
    // Normalize Q and K
    float q_norm = 0, k_norm = 0;
    for (int i = 0; i < kd; i++) { q_norm += q[i]*q[i]; k_norm += k[i]*k[i]; }
    printf("Q norm before: %.6f, K norm before: %.6f\n", sqrtf(q_norm), sqrtf(k_norm));
    
    q_norm = 1.0f / sqrtf(q_norm + 1e-6f);
    k_norm = 1.0f / sqrtf(k_norm + 1e-6f);
    for (int i = 0; i < kd; i++) { q[i] *= q_norm; k[i] *= k_norm; }
    
    printf("Q after norm [0:4]: %.6f, %.6f, %.6f, %.6f\n", q[0], q[1], q[2], q[3]);
    printf("K after norm [0:4]: %.6f, %.6f, %.6f, %.6f\n", k[0], k[1], k[2], k[3]);
    
    // Scale Q
    for (int i = 0; i < kd; i++) q[i] /= sqrtf(kd);
    printf("Q after scale [0:4]: %.6f, %.6f, %.6f, %.6f\n", q[0], q[1], q[2], q[3]);
    
    // Decay parameters
    float A = gdn_A[h], dt = gdn_dt[h], a = a_proj[h], beta = b_proj[h];
    printf("\nDecay params: A=%.4f, dt=%.4f, a=%.4f, beta=%.4f\n", A, dt, a, beta);
    
    // Current formula: softplus(a + dt)
    float sp1 = logf(1 + expf(a + dt));
    float gamma1 = expf(-expf(A) * sp1);
    printf("Formula 1: softplus(a+dt)=%.4f, gamma=%.6f\n", sp1, gamma1);
    
    // Fixed formula: softplus(a - dt)
    float sp2 = logf(1 + expf(a - dt));
    float gamma2 = expf(-expf(A) * sp2);
    printf("Formula 2: softplus(a-dt)=%.4f, gamma=%.6f\n", sp2, gamma2);
    
    // State is initially zero at position 0
    float *state = calloc(kd * vd, sizeof(float));
    
    // At pos 0, state is zero, so:
    // kv_mem = 0
    // delta = v * beta
    // state += outer(k, v * beta)
    // out = state @ q
    
    printf("\nAt position 0:\n");
    printf("  kv_mem = 0 (state is zero)\n");
    printf("  delta = v * beta\n");
    printf("  state = outer(k, v * beta)\n");
    printf("  out = state @ q\n");
    
    // delta = v * beta
    float delta[128];
    for (int j = 0; j < vd; j++) delta[j] = v[j] * beta;
    printf("delta[0:4]: %.6f, %.6f, %.6f, %.6f\n", delta[0], delta[1], delta[2], delta[3]);
    
    // state = outer(k, delta)
    for (int i = 0; i < kd; i++) {
        for (int j = 0; j < vd; j++) {
            state[i * vd + j] = k[i] * delta[j];
        }
    }
    printf("state[0:4] (first row): %.6f, %.6f, %.6f, %.6f\n", state[0], state[1], state[2], state[3]);
    
    // out = state @ q
    float out[128] = {0};
    for (int j = 0; j < vd; j++) {
        for (int i = 0; i < kd; i++) {
            out[j] += state[i * vd + j] * q[i];
        }
    }
    printf("out[0:4]: %.6f, %.6f, %.6f, %.6f\n", out[0], out[1], out[2], out[3]);
    
    // Check norm
    float out_norm = 0;
    for (int j = 0; j < vd; j++) out_norm += out[j] * out[j];
    printf("out norm: %.6f\n", sqrtf(out_norm));
    
    // Apply output norm and silu
    out_norm = 1.0f / sqrtf(out_norm / vd + 1e-6f);
    for (int j = 0; j < vd; j++) {
        out[j] = gdn_norm[h * vd + j] * out_norm * out[j] * silu(zh[j]);
    }
    printf("After norm and silu[0:4]: %.6f, %.6f, %.6f, %.6f\n", out[0], out[1], out[2], out[3]);
    
    // Check final norm
    out_norm = 0;
    for (int j = 0; j < vd; j++) out_norm += out[j] * out[j];
    printf("Final out norm: %.6f\n", sqrtf(out_norm));
    
    // Now process all heads
    printf("\n=== All heads output norm ===\n");
    float *all_out = xmalloc(nv * vd * sizeof(float));
    for (h = 0; h < nv; h++) {
        float *q = qkv + h * kd;
        float *k = qkv + nv * kd + h * kd;
        float *v = qkv + 2 * nv * kd + h * kd;
        float *zh = z + h * vd;
        
        float qn = 0, kn = 0;
        for (int i = 0; i < kd; i++) { qn += q[i]*q[i]; kn += k[i]*k[i]; }
        qn = 1.0f / sqrtf(qn + 1e-6f);
        kn = 1.0f / sqrtf(kn + 1e-6f);
        for (int i = 0; i < kd; i++) { q[i] *= qn; k[i] *= kn; }
        for (int i = 0; i < kd; i++) q[i] /= sqrtf(kd);
        
        float *state = calloc(kd * vd, sizeof(float));
        float delta[128];
        for (int j = 0; j < vd; j++) delta[j] = v[j] * b_proj[h];
        for (int i = 0; i < kd; i++) {
            for (int j = 0; j < vd; j++) state[i * vd + j] = k[i] * delta[j];
        }
        
        float *out_h = all_out + h * vd;
        for (int j = 0; j < vd; j++) {
            for (int i = 0; i < kd; i++) out_h[j] += state[i * vd + j] * q[i];
        }
        
        float on = 0;
        for (int j = 0; j < vd; j++) on += out_h[j] * out_h[j];
        on = 1.0f / sqrtf(on / vd + 1e-6f);
        for (int j = 0; j < vd; j++) {
            out_h[j] = gdn_norm[h * vd + j] * on * out_h[j] * silu(zh[j]);
        }
        
        on = 0;
        for (int j = 0; j < vd; j++) on += out_h[j] * out_h[j];
        printf("Head %d: out_norm=%.4f\n", h, sqrtf(on));
        
        free(state);
    }
    
    // Output projection
    printf("\n=== Output projection ===\n");
    float *final_out = xmalloc(dim * sizeof(float));
    for (int i = 0; i < dim; i++) {
        float sum = 0;
        for (int j = 0; j < nv * vd; j++) {
            sum += gdn_out[i * nv * vd + j] * all_out[j];
        }
        final_out[i] = sum;
    }
    
    float fn = 0;
    for (int i = 0; i < dim; i++) fn += final_out[i] * final_out[i];
    printf("Final output norm: %.4f\n", sqrtf(fn));
    printf("final_out[0:5]: %.4f, %.4f, %.4f, %.4f, %.4f\n",
           final_out[0], final_out[1], final_out[2], final_out[3], final_out[4]);
    
    safetensors_close(sf);
    return 0;
}