#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tokenizer.h"

int main() {
    BPETokenizer tok;
    if (tokenizer_init(&tok) != 0) {
        printf("Failed to init tokenizer\n");
        return 1;
    }
    
    if (tokenizer_load_vocab(&tok, "/mnt/Qwen3.5-0.8B/tokenizer.json") != 0) {
        printf("Failed to load vocab\n");
        return 1;
    }
    
    // Decode specific tokens
    const char *s;
    printf("Token 846: %s\n", tokenizer_get_token(&tok, 846) ? : "(null)");
    printf("Token 234967: %s\n", tokenizer_get_token(&tok, 234967) ? : "(null)");
    printf("Token 1279: %s\n", tokenizer_get_token(&tok, 1279) ? : "(null)");
    printf("Token 198: %s\n", tokenizer_get_token(&tok, 198) ? : "(null)");
    printf("Token 248045: %s\n", tokenizer_get_token(&tok, 248045) ? : "(null)");
    
    tokenizer_free(&tok);
    return 0;
}
