import struct
import json
import math

def bf16_to_f32(data, offset, count):
    """Read bfloat16 values and convert to float32"""
    result = []
    for i in range(count):
        bf16 = struct.unpack('<H', data[offset + i*2:offset + i*2 + 2])[0]
        f32 = (bf16 << 16) & 0xFFFFFFFF
        packed = struct.pack('<I', f32)
        result.append(struct.unpack('<f', packed)[0])
    return result

# Load weights
with open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors", "rb") as f:
    header_size = struct.unpack("<Q", f.read(8))[0]
    header = f.read(header_size).decode("utf-8")
    metadata = json.loads(header)
    data_start = 8 + header_size
    
    # Read entire file into memory
    f.seek(0)
    all_data = f.read()

def get_tensor(name):
    meta = metadata[name]
    offset_start, offset_end = meta['data_offsets']
    shape = meta['shape']
    dtype = meta['dtype']
    total = 1
    for s in shape: total *= s
    data = all_data[data_start + offset_start:data_start + offset_end]
    if dtype == 'BF16':
        return bf16_to_f32(data, 0, total), shape
    return None, None

# Get embedding for token 248045
emb, emb_shape = get_tensor("model.language_model.embed_tokens.weight")
vocab, dim = emb_shape
token_id = 248045
x = emb[token_id * dim:(token_id + 1) * dim]

print(f"Embedding for token {token_id}: {x[:4]}")

# Apply layer 0 input norm
ln1, ln1_shape = get_tensor("model.language_model.layers.0.input_layernorm.weight")
print(f"LN1 weight shape: {ln1_shape}")

# RMSNorm
ss = sum(xi * xi for xi in x) / dim
ss = 1.0 / math.sqrt(ss + 1e-6)
x_norm = [ln1[i] * ss * x[i] for i in range(dim)]
print(f"After norm: {x_norm[:4]}")

# Linear attention QKV projection
qkv_w, qkv_shape = get_tensor("model.language_model.layers.0.linear_attn.in_proj_qkv.weight")
print(f"QKV weight shape: {qkv_shape}")  # [6144, 1024]

# Matmul: [6144] = [6144, 1024] @ [1024]
qkv = [0] * 6144
for i in range(6144):
    for j in range(dim):
        qkv[i] += qkv_w[i * dim + j] * x_norm[j]

print(f"QKV output: {qkv[:4]}")
print(f"QKV range: min={min(qkv):.4f}, max={max(qkv):.4f}")
