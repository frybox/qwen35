import json
import struct
import math

# Load model weights
with open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors", "rb") as f:
    header_size = struct.unpack("<Q", f.read(8))[0]
    header = f.read(header_size).decode("utf-8")
    metadata = json.loads(header)
    f.seek(0)
    all_data = f.read()

def bf16_to_f32(data, offset, count):
    result = []
    for i in range(count):
        bf16 = struct.unpack('<H', data[offset + i*2:offset + i*2 + 2])[0]
        f32 = (bf16 << 16) & 0xFFFFFFFF
        packed = struct.pack('<I', f32)
        result.append(struct.unpack('<f', packed)[0])
    return result

def get_tensor(name):
    meta = metadata[name]
    offset_start, offset_end = meta['data_offsets']
    shape = meta['shape']
    total = 1
    for s in shape: total *= s
    data = all_data[8 + header_size + offset_start:8 + header_size + offset_end]
    if meta['dtype'] == 'BF16':
        return bf16_to_f32(data, 0, total), shape
    return None, None

# Get embedding for token 248045
emb, emb_shape = get_tensor("model.language_model.embed_tokens.weight")
vocab, dim = emb_shape
token_id = 248045
x = emb[token_id * dim:(token_id + 1) * dim]

print(f"Embedding for token {token_id}")
print(f"x[0:4]: {[f'{v:.6f}' for v in x[:4]]}")

# Final norm
final_norm, _ = get_tensor("model.language_model.norm.weight")

# RMSNorm (Qwen3.5 style: 1 + weight)
ss = sum(xi * xi for xi in x) / dim
ss = 1.0 / math.sqrt(ss + 1e-6)
x_normed = [(1.0 + final_norm[i]) * ss * x[i] for i in range(dim)]

# Compute logits for a few tokens
print("\nLogits after final norm (direct from embedding):")
for t in [846, 12, 198, 13266]:
    logit = sum(emb[t * dim + i] * x_normed[i] for i in range(dim))
    print(f"  Token {t}: {logit:.4f}")

# Check what the top tokens would be
print("\nFinding top-10 tokens...")
token_logits = []
for t in range(1000):  # Check first 1000 tokens
    logit = sum(emb[t * dim + i] * x_normed[i] for i in range(dim))
    token_logits.append((t, logit))
token_logits.sort(key=lambda x: -x[1])
print("Top-10 (from first 1000):")
for t, l in token_logits[:10]:
    print(f"  Token {t}: {l:.4f}")
