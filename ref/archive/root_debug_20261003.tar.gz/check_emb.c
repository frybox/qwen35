#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

int main() {
    FILE *f = fopen("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors", "rb");
    
    // Read header
    uint64_t header_size;
    fread(&header_size, 8, 1, f);
    char *header = malloc(header_size + 1);
    fread(header, 1, header_size, f);
    header[header_size] = 0;
    
    uint64_t data_start = 8 + header_size;
    
    // Find embed_tokens data_offsets
    char *pos = strstr(header, "\"model.language_model.embed_tokens.weight\"");
    if (!pos) { printf("Not found\n"); return 1; }
    
    // Parse data_offsets
    char *offsets_str = strstr(pos, "\"data_offsets\"");
    if (!offsets_str) { printf("offsets not found\n"); return 1; }
    offsets_str = strstr(offsets_str, "[");
    
    uint64_t offset_start, offset_end;
    sscanf(offsets_str, "[%lu, %lu]", &offset_start, &offset_end);
    
    printf("Embedding offsets: [%lu, %lu]\n", offset_start, offset_end);
    printf("Expected size: 248320 * 1024 * 2 = %lu bytes\n", 248320UL * 1024 * 2);
    printf("Actual size: %lu bytes\n", offset_end - offset_start);
    
    // Read token 248045 embedding (bf16)
    uint64_t target_offset = data_start + offset_start + 248045 * 1024 * 2;
    printf("Seeking to offset %lu for token 248045\n", target_offset);
    
    fseek(f, target_offset, SEEK_SET);
    uint16_t bf16_vals[8];
    fread(bf16_vals, 2, 8, f);
    
    printf("Raw BF16 values: ");
    for (int i = 0; i < 8; i++) {
        printf("0x%04x ", bf16_vals[i]);
    }
    printf("\n");
    
    // Convert to f32
    printf("As float32: ");
    for (int i = 0; i < 8; i++) {
        uint32_t val = ((uint32_t)bf16_vals[i]) << 16;
        float f;
        memcpy(&f, &val, 4);
        printf("%.8f ", f);
    }
    printf("\n");
    
    fclose(f);
    return 0;
}
