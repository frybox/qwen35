#include <stdio.h>
#include <math.h>

int main() {
    // Test RoPE with partial_rotary_factor = 0.25, theta = 10000000
    int dim = 256;
    int rotary_dim = 64;  // 256 * 0.25
    
    // Test values
    float q[256];
    for (int i = 0; i < 256; i++) q[i] = 0.01f * i;
    
    float theta = 10000000.0f;
    int pos = 10;
    
    printf("Before RoPE: q[0:4] = %.4f, %.4f, %.4f, %.4f\n", q[0], q[1], q[2], q[3]);
    
    // Apply RoPE
    for (int i = 0; i < rotary_dim; i += 2) {
        float freq = 1.0f / powf(theta, (float)i / dim);
        float val = pos * freq;
        float fcr = cosf(val);
        float fci = sinf(val);
        
        float v0 = q[i];
        float v1 = q[i + 1];
        q[i] = v0 * fcr - v1 * fci;
        q[i + 1] = v0 * fci + v1 * fcr;
    }
    
    printf("After RoPE: q[0:4] = %.4f, %.4f, %.4f, %.4f\n", q[0], q[1], q[2], q[3]);
    
    return 0;
}
