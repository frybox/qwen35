# Check layer norm and embedding values
import struct
import json
import math

def bf16_to_f32(bf16_bytes):
    """Convert bfloat16 bytes to float32"""
    result = []
    for i in range(0, len(bf16_bytes), 2):
        bf16 = struct.unpack('<H', bf16_bytes[i:i+2])[0]
        # bfloat16: 1 bit sign, 8 bits exponent, 7 bits mantissa
        sign = (bf16 >> 15) & 1
        exp = (bf16 >> 7) & 0xFF
        mant = bf16 & 0x7F
        # Convert to float32
        if exp == 0:
            f32 = sign << 31
        else:
            f32 = (sign << 31) | ((exp + 127 - 128) << 23) | (mant << 16)
        result.append(struct.unpack('<f', struct.pack('<I', f32))[0])
    return result

with open("/mnt/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors", "rb") as f:
    header_size = struct.unpack("<Q", f.read(8))[0]
    header = f.read(header_size).decode("utf-8")
    metadata = json.loads(header)
    data_start = 8 + header_size
    
    # Get embedding for token 248045 (<|im_start|>)
    emb_meta = metadata['model.language_model.embed_tokens.weight']
    vocab, dim = emb_meta['shape']
    offset_start, offset_end = emb_meta['data_offsets']
    
    f.seek(data_start + offset_start + 248045 * dim * 2)  # bf16 = 2 bytes
    raw = f.read(16)
    emb_vals = bf16_to_f32(raw)
    print(f"Token 248045 embedding (first 8): {emb_vals}")
    
    # Get ln1 weight for layer 0
    ln1_meta = metadata['model.language_model.layers.0.input_layernorm.weight']
    f.seek(data_start + ln1_meta['data_offsets'][0])
    raw = f.read(16)
    ln1_vals = bf16_to_f32(raw)
    print(f"Layer 0 ln1 weight (first 8): {ln1_vals}")
    
    # Check qkv projection weight shape and first values
    qkv_meta = metadata['model.language_model.layers.0.linear_attn.in_proj_qkv.weight']
    print(f"QKV weight shape: {qkv_meta['shape']}")
    f.seek(data_start + qkv_meta['data_offsets'][0])
    raw = f.read(32)
    qkv_vals = bf16_to_f32(raw)
    print(f"QKV weight [0:8] (first row): {qkv_vals[:8]}")
    
    # Check first output projection
    out_meta = metadata['model.language_model.layers.0.linear_attn.out_proj.weight']
    print(f"Out proj shape: {out_meta['shape']}")
